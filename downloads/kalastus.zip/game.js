// =========================================================
// Audio (Web Audio API — proseduraalinen musa & efektit)
// =========================================================
const AC = window.AudioContext || window.webkitAudioContext;
let audioCtx = null;
let musicGain = null;
let sfxGain = null;
let musicEnabled = true;
let musicStep = 0;
let nextNoteTime = 0;
let musicTimer = null;
let reelSfxCounter = 0;

function initAudio() {
  if (audioCtx) return;
  audioCtx = new AC();
  musicGain = audioCtx.createGain();
  musicGain.gain.value = musicEnabled ? 0.10 : 0;
  musicGain.connect(audioCtx.destination);
  sfxGain = audioCtx.createGain();
  sfxGain.gain.value = 0.28;
  sfxGain.connect(audioCtx.destination);
  startMusic();
}
function ensureAudioOnGesture() {
  if (!audioCtx) initAudio();
  else if (audioCtx.state === "suspended") audioCtx.resume();
}
function toggleMusic() {
  if (!audioCtx) { initAudio(); musicEnabled = true; updateMusicIndicator(); return; }
  musicEnabled = !musicEnabled;
  musicGain.gain.linearRampToValueAtTime(musicEnabled ? 0.10 : 0, audioCtx.currentTime + 0.25);
  updateMusicIndicator();
}
function updateMusicIndicator() {
  const el = document.getElementById("musicBtn");
  if (el) el.textContent = musicEnabled ? "🎵" : "🔇";
}

const CHORDS = [
  { bass: 55.00,  pad: [220.00, 261.63, 329.63] }, // Am
  { bass: 43.65,  pad: [174.61, 220.00, 261.63] }, // F
  { bass: 65.41,  pad: [196.00, 261.63, 329.63] }, // C
  { bass: 49.00,  pad: [196.00, 246.94, 293.66] }, // G
];
const MELODY_NOTES = [220.00, 261.63, 293.66, 329.63, 392.00, 440.00, 523.25, 587.33];

function startMusic() {
  if (!audioCtx) return;
  nextNoteTime = audioCtx.currentTime + 0.15;
  scheduleMusic();
}
function scheduleMusic() {
  if (!audioCtx) return;
  const horizon = audioCtx.currentTime + 0.6;
  while (nextNoteTime < horizon) {
    playMusicStep(nextNoteTime);
    nextNoteTime += 0.4;
    musicStep++;
  }
  musicTimer = setTimeout(scheduleMusic, 120);
}
function playMusicStep(when) {
  if (!musicEnabled) return;
  const beat = musicStep % 16;
  const chordIdx = Math.floor(musicStep / 16) % CHORDS.length;
  const chord = CHORDS[chordIdx];
  if (beat === 0) {
    playSynthNote(chord.bass, when, 1.8, "triangle", 0.55);
    for (const p of chord.pad) playSynthNote(p, when, 1.8, "sine", 0.16);
  }
  if (beat === 4 || beat === 9 || beat === 12 || beat === 14) {
    if (Math.random() < 0.7) {
      const noteIdx = Math.floor(Math.random() * MELODY_NOTES.length);
      playSynthNote(MELODY_NOTES[noteIdx], when, 0.4, "sine", 0.22);
    }
  }
}
function playSynthNote(freq, when, duration, type, volume) {
  if (!audioCtx) return;
  const o = audioCtx.createOscillator();
  const g = audioCtx.createGain();
  o.type = type;
  o.frequency.value = freq;
  g.gain.setValueAtTime(0, when);
  g.gain.linearRampToValueAtTime(volume, when + 0.04);
  g.gain.exponentialRampToValueAtTime(0.001, when + duration);
  o.connect(g);
  g.connect(musicGain);
  o.start(when);
  o.stop(when + duration + 0.05);
}
function makeNoiseBuffer(duration) {
  const len = Math.floor(audioCtx.sampleRate * duration);
  const buf = audioCtx.createBuffer(1, len, audioCtx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
  return buf;
}
function sfxSplash() {
  if (!audioCtx) return;
  const src = audioCtx.createBufferSource();
  src.buffer = makeNoiseBuffer(0.3);
  const f = audioCtx.createBiquadFilter();
  f.type = "lowpass"; f.frequency.value = 900;
  const g = audioCtx.createGain();
  g.gain.setValueAtTime(0.45, audioCtx.currentTime);
  g.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.28);
  src.connect(f); f.connect(g); g.connect(sfxGain);
  src.start(); src.stop(audioCtx.currentTime + 0.3);
}
function sfxReel() {
  if (!audioCtx) return;
  if ((reelSfxCounter++ % 2) !== 0) return;
  const when = audioCtx.currentTime;
  const o = audioCtx.createOscillator();
  const g = audioCtx.createGain();
  o.type = "square";
  o.frequency.setValueAtTime(180, when);
  o.frequency.exponentialRampToValueAtTime(360, when + 0.05);
  g.gain.setValueAtTime(0.08, when);
  g.gain.exponentialRampToValueAtTime(0.001, when + 0.07);
  o.connect(g); g.connect(sfxGain);
  o.start(when); o.stop(when + 0.08);
}
function sfxCatch() {
  if (!audioCtx) return;
  const notes = [523.25, 659.25, 783.99, 1046.5];
  notes.forEach((freq, i) => {
    const when = audioCtx.currentTime + i * 0.08;
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.type = "triangle";
    o.frequency.value = freq;
    g.gain.setValueAtTime(0, when);
    g.gain.linearRampToValueAtTime(0.22, when + 0.015);
    g.gain.exponentialRampToValueAtTime(0.001, when + 0.3);
    o.connect(g); g.connect(sfxGain);
    o.start(when); o.stop(when + 0.32);
  });
}
function sfxBite() {
  if (!audioCtx) return;
  const when = audioCtx.currentTime;
  const o = audioCtx.createOscillator();
  const g = audioCtx.createGain();
  o.type = "sine";
  o.frequency.setValueAtTime(660, when);
  o.frequency.exponentialRampToValueAtTime(440, when + 0.1);
  g.gain.setValueAtTime(0.18, when);
  g.gain.exponentialRampToValueAtTime(0.001, when + 0.12);
  o.connect(g); g.connect(sfxGain);
  o.start(when); o.stop(when + 0.14);
}
function sfxEscape() {
  if (!audioCtx) return;
  const when = audioCtx.currentTime;
  const o = audioCtx.createOscillator();
  const g = audioCtx.createGain();
  o.type = "sawtooth";
  o.frequency.setValueAtTime(320, when);
  o.frequency.exponentialRampToValueAtTime(70, when + 0.4);
  g.gain.setValueAtTime(0.18, when);
  g.gain.exponentialRampToValueAtTime(0.001, when + 0.42);
  o.connect(g); g.connect(sfxGain);
  o.start(when); o.stop(when + 0.44);
}
function sfxPlastic() {
  if (!audioCtx) return;
  for (let i = 0; i < 3; i++) {
    const t = audioCtx.currentTime + i * 0.18;
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.type = "square";
    o.frequency.value = 220 + (i % 2) * 240;
    g.gain.setValueAtTime(0.18, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
    o.connect(g); g.connect(sfxGain);
    o.start(t); o.stop(t + 0.15);
  }
}
function sfxAuction() {
  if (!audioCtx) return;
  const when = audioCtx.currentTime;
  const src = audioCtx.createBufferSource();
  src.buffer = makeNoiseBuffer(0.12);
  const f = audioCtx.createBiquadFilter();
  f.type = "lowpass"; f.frequency.value = 180;
  const g = audioCtx.createGain();
  g.gain.setValueAtTime(0.5, when);
  g.gain.exponentialRampToValueAtTime(0.001, when + 0.12);
  src.connect(f); f.connect(g); g.connect(sfxGain);
  src.start(when); src.stop(when + 0.14);
  setTimeout(() => sfxCatch(), 180);
}
function sfxSnap() {
  // dramatic line snap
  if (!audioCtx) return;
  const when = audioCtx.currentTime;
  const src = audioCtx.createBufferSource();
  src.buffer = makeNoiseBuffer(0.2);
  const f = audioCtx.createBiquadFilter();
  f.type = "highpass"; f.frequency.value = 1200;
  const g = audioCtx.createGain();
  g.gain.setValueAtTime(0.45, when);
  g.gain.exponentialRampToValueAtTime(0.001, when + 0.22);
  src.connect(f); f.connect(g); g.connect(sfxGain);
  src.start(when); src.stop(when + 0.24);
  // descending tone
  const o = audioCtx.createOscillator();
  const og = audioCtx.createGain();
  o.type = "sawtooth";
  o.frequency.setValueAtTime(500, when);
  o.frequency.exponentialRampToValueAtTime(60, when + 0.6);
  og.gain.setValueAtTime(0.18, when);
  og.gain.exponentialRampToValueAtTime(0.001, when + 0.6);
  o.connect(og); og.connect(sfxGain);
  o.start(when); o.stop(when + 0.62);
}

// =========================================================
// Canvas / DOM
// =========================================================
const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");
const W = canvas.width;
const H = canvas.height;
const WATER_Y = 150;
const MAX_CATCHES = 3;
const DEAD_TIME = 7;
const REEL_PER_TAP_BASE = 95;
const REEL_DECAY = 95;
const LINECUT_TIME = 3.0; // seconds before linecutter creature snaps line

const moneyEl = document.getElementById("money");
const bucketEl = document.getElementById("bucket");
const bestEl = document.getElementById("best");
const struggleStat = document.getElementById("struggleStat");
const struggleFill = document.getElementById("struggleFill");
const overlay = document.getElementById("overlay");
const overlayTitle = document.getElementById("overlayTitle");
const overlaySub = document.getElementById("overlaySub");
const startBtn = document.getElementById("startBtn");

const shop = document.getElementById("shop");
const bucketListEl = document.getElementById("bucketList");
const shopBucketCount = document.getElementById("shopBucketCount");
const auctionBtn = document.getElementById("auctionBtn");
const auctionResult = document.getElementById("auctionResult");
const upgradeListEl = document.getElementById("upgradeList");
const shopMoneyEl = document.getElementById("shopMoney");
const closeShopBtn = document.getElementById("closeShop");

const mapEl = document.getElementById("map");
const mapCanvas = document.getElementById("mapCanvas");
const mapCtx = mapCanvas.getContext("2d");
const MAPW = mapCanvas.width;
const MAPH = mapCanvas.height;
const mapDetailEl = document.getElementById("mapDetail");
const mapMoneyEl = document.getElementById("mapMoney");
const closeMapBtn = document.getElementById("closeMap");
const locationNameEl = document.getElementById("locationName");
const vehicleRowEl = document.getElementById("vehicleRow");
const netRowEl = document.getElementById("netRow");
const wormRowEl = document.getElementById("wormRow");
const vehTbtnEl = document.getElementById("vehTbtn");

const authDiv = document.getElementById("auth");
const authUser = document.getElementById("authUser");
const authPass = document.getElementById("authPass");
const authMsg = document.getElementById("authMsg");
const userBadge = document.getElementById("userBadge");
const userNameEl = document.getElementById("userName");

let best = 0;

// =========================================================
// Fish types
// =========================================================
const FISH_TYPES = [
  // Pintakalat
  { name: "small",    display: "Pikkukala",  color: "#c2d8e6", w: 22, h: 10, speed: 1.6, weight: 28, minDepth: 30,  maxDepth: 220, struggle: 30,  priceMin: 1,  priceMax: 3 },
  { name: "muikku",   display: "Muikku",     color: "#d8e9f0", w: 20, h: 8,  speed: 2.0, weight: 25, minDepth: 30,  maxDepth: 180, struggle: 18,  priceMin: 1,  priceMax: 2 },
  { name: "silakka",  display: "Silakka",    color: "#a8c0d8", w: 22, h: 9,  speed: 1.8, weight: 22, minDepth: 30,  maxDepth: 200, struggle: 22,  priceMin: 1,  priceMax: 3 },
  { name: "sardiini", display: "Sardiini",   color: "#b0c8d6", w: 26, h: 11, speed: 1.7, weight: 18, minDepth: 40,  maxDepth: 220, struggle: 28,  priceMin: 2,  priceMax: 4 },
  // Keskikoko
  { name: "med",      display: "Ahven",      color: "#6cbf6c", w: 32, h: 14, speed: 1.2, weight: 22, minDepth: 90,  maxDepth: 320, struggle: 55,  priceMin: 3,  priceMax: 7 },
  { name: "sayne",    display: "Säyne",      color: "#9aa86e", w: 30, h: 13, speed: 1.3, weight: 16, minDepth: 80,  maxDepth: 260, struggle: 40,  priceMin: 3,  priceMax: 6 },
  { name: "siika",    display: "Siika",      color: "#cfd9c8", w: 36, h: 14, speed: 1.2, weight: 14, minDepth: 100, maxDepth: 300, struggle: 50,  priceMin: 5,  priceMax: 10 },
  { name: "lahna",    display: "Lahna",      color: "#b89a5a", w: 36, h: 22, speed: 0.9, weight: 12, minDepth: 120, maxDepth: 320, struggle: 60,  priceMin: 6,  priceMax: 12 },
  // Isot
  { name: "big",      display: "Hauki",      color: "#2f6b3a", w: 52, h: 22, speed: 0.9, weight: 11, minDepth: 180, maxDepth: 420, struggle: 85,  priceMin: 8,  priceMax: 15 },
  { name: "kuha",     display: "Kuha",       color: "#7a8a6a", w: 48, h: 18, speed: 1.0, weight: 9,  minDepth: 200, maxDepth: 380, struggle: 80,  priceMin: 10, priceMax: 18 },
  { name: "made",     display: "Made",       color: "#6a5a35", w: 52, h: 12, speed: 0.7, weight: 8,  minDepth: 250, maxDepth: 420, struggle: 70,  priceMin: 8,  priceMax: 16 },
  { name: "taimen",   display: "Taimen",     color: "#c47878", w: 40, h: 16, speed: 1.4, weight: 7,  minDepth: 100, maxDepth: 280, struggle: 90,  priceMin: 12, priceMax: 22 },
  { name: "lohi",     display: "Lohi",       color: "#e09a8a", w: 58, h: 22, speed: 1.1, weight: 5,  minDepth: 180, maxDepth: 360, struggle: 110, priceMin: 18, priceMax: 35 },
  { name: "turska",   display: "Turska",     color: "#a89a6a", w: 56, h: 24, speed: 0.8, weight: 5,  minDepth: 280, maxDepth: 430, struggle: 100, priceMin: 14, priceMax: 28 },
  { name: "ankerias", display: "Ankerias",   color: "#3a2a25", w: 64, h: 8,  speed: 1.0, weight: 5,  minDepth: 300, maxDepth: 430, struggle: 75,  priceMin: 10, priceMax: 20 },
  // Harvinaiset arvokkaat
  { name: "giant",    display: "Monni",      color: "#6a4a2a", w: 70, h: 30, speed: 0.55, weight: 4, minDepth: 280, maxDepth: 430, struggle: 130, priceMin: 20, priceMax: 45 },
  { name: "gold",     display: "Kultakala",  color: "#f5c542", w: 26, h: 12, speed: 2.2, weight: 4, minDepth: 250, maxDepth: 430, struggle: 110, priceMin: 30, priceMax: 60 },
  { name: "hopea",    display: "Hopeakala",  color: "#dde8f0", w: 32, h: 14, speed: 1.6, weight: 3, minDepth: 200, maxDepth: 380, struggle: 90,  priceMin: 25, priceMax: 50 },
  { name: "sampi",    display: "Sampi",      color: "#3a4250", w: 78, h: 28, speed: 0.5, weight: 2, minDepth: 350, maxDepth: 430, struggle: 150, priceMin: 35, priceMax: 70 },
  { name: "hai",      display: "Hai",        color: "#5a6878", w: 86, h: 26, speed: 0.7, weight: 1, minDepth: 320, maxDepth: 430, struggle: 180, priceMin: 60, priceMax: 120 },
  { name: "kraken",   display: "Kraken",     color: "#5a2a4a", w: 124, h: 78, speed: 0.6, weight: 1.4, minDepth: 360, maxDepth: 446, struggle: 280, priceMin: 380, priceMax: 750, deepOnly: true },
  // Jättiläiset jotka katkaisevat siiman jos ei MAX vapa+siima
  { name: "mursu",    display: "Mursu",      color: "#9a7a5a", w: 84, h: 56, speed: 0.45, weight: 1.0, minDepth: 50,  maxDepth: 220, struggle: 200, priceMin: 80,  priceMax: 150, linecutter: true },
  { name: "delfiini", display: "Delfiini",   color: "#6a8aa8", w: 96, h: 30, speed: 1.5,  weight: 1.4, minDepth: 60,  maxDepth: 280, struggle: 170, priceMin: 60,  priceMax: 120, linecutter: true },
  { name: "valas",    display: "Valas",      color: "#3a4858", w: 130, h: 56, speed: 0.45, weight: 0.7, minDepth: 280, maxDepth: 430, struggle: 250, priceMin: 200, priceMax: 350, linecutter: true },
  // Roskat ja vaarat
  { name: "boot",     display: "Saapas",     color: "#5a3a25", w: 28, h: 16, speed: 0,   weight: 4, minDepth: 200, maxDepth: 430, struggle: 0,   priceMin: 0, priceMax: 0, junk: true },
  { name: "jelly",    display: "Meduusa",    color: "#d27ce0", w: 24, h: 28, speed: 0.5, weight: 6, minDepth: 80,  maxDepth: 380, struggle: 40,  priceMin: 0, priceMax: 0, hazard: true },
  { name: "plastic",  display: "Muovipussi", color: "#dde8ff", w: 30, h: 24, speed: 0.2, weight: 4, minDepth: 60,  maxDepth: 350, struggle: 8,   priceMin: 0, priceMax: 0, junk: true, plastic: true },
];
// Kalapaikan rareBoost suosii arvokkaampia lajeja; matalassa vedessä
// syvänveden kalat eivät esiinny lainkaan.
function randType() {
  const rb = currentLoc ? currentLoc.rareBoost : 0;
  const maxFishDepth = locDepth() - 25;
  let total = 0;
  const ws = [];
  const deepOk = state.subMode;
  for (const t of FISH_TYPES) {
    if (t.minDepth > maxFishDepth) { ws.push(0); continue; }
    if (t.deepOnly && !deepOk) { ws.push(0); continue; }
    const valueScore = Math.min(2, (t.priceMax || 0) / 30);
    const w = t.weight * (1 + rb * valueScore);
    ws.push(w);
    total += w;
  }
  let r = Math.random() * total;
  for (let i = 0; i < FISH_TYPES.length; i++) {
    r -= ws[i];
    if (r <= 0) return FISH_TYPES[i];
  }
  return FISH_TYPES[0];
}

// =========================================================
// Kalojen kokoluokat — mitä isompi, sitä harvinaisempi ja arvokkaampi
// =========================================================
const SIZE_CLASSES = [
  { name: "small",  label: "Pieni",         scale: 0.68, valueMult: 0.55, struggleMult: 0.8, weight: 50 },
  { name: "medium", label: "Keskikokoinen", scale: 1.0,  valueMult: 1.0,  struggleMult: 1.0, weight: 34 },
  { name: "large",  label: "Iso",           scale: 1.45, valueMult: 1.8,  struggleMult: 1.3, weight: 16 },
];
const SIZE_MEDIUM = SIZE_CLASSES[1];

// Kalapaikan sizeBoost suosii isompia kokoluokkia.
function randSize() {
  const sb = currentLoc ? currentLoc.sizeBoost : 0;
  let total = 0;
  const ws = [];
  for (const c of SIZE_CLASSES) {
    let w = c.weight;
    if (c.name === "large") w *= (1 + sb * 1.6);
    else if (c.name === "small") w /= (1 + sb * 0.8);
    ws.push(w);
    total += w;
  }
  let r = Math.random() * total;
  for (let i = 0; i < SIZE_CLASSES.length; i++) {
    r -= ws[i];
    if (r <= 0) return SIZE_CLASSES[i];
  }
  return SIZE_MEDIUM;
}
function sizeByName(n) {
  return SIZE_CLASSES.find(c => c.name === n) || SIZE_MEDIUM;
}

// =========================================================
// Kalapaikat — kartasta voi ostaa lisää järviä ja meriä
// =========================================================
// depth = pohjan syvyys (px vedenpinnasta), bottom = pohjan tyyppi, kind = järvi/meri
// mx,my = sijainti kartalla (px, 1000x600), mr = vesialueen säde
const LOCATIONS = [
  { name: "kotijarvi", display: "Kotijärvi", icon: "🏡",
    desc: "Rauhallinen matala kotijärvi hiekkapohjineen.",
    price: 0, rareBoost: 0, sizeBoost: 0, fishCount: 16, valueMult: 1.0,
    water: ["#5db4d8", "#1e6e95", "#0a3552"], depth: 235, bottom: "sand", kind: "lake",
    mx: 150, my: 158, mr: 58 },

  { name: "sammakkolampi", display: "Sammakkolampi", icon: "🐸",
    desc: "Pieni matala lampi — vesikasveja ja mutaa.",
    price: 80, rareBoost: 0.25, sizeBoost: 0.15, fishCount: 16, valueMult: 1.08,
    water: ["#7fc89a", "#3f8f63", "#1c4a32"], depth: 195, bottom: "weed", kind: "lake",
    mx: 250, my: 74, mr: 38 },

  { name: "metsalampi", display: "Metsälampi", icon: "🌲",
    desc: "Hämärä metsälampi pehmeällä mutapohjalla.",
    price: 200, rareBoost: 0.5, sizeBoost: 0.3, fishCount: 17, valueMult: 1.16,
    water: ["#4fae8a", "#1f7a5a", "#0a3a2a"], depth: 250, bottom: "mud", kind: "lake",
    mx: 178, my: 322, mr: 52 },

  { name: "virtajoki", display: "Virtajoki", icon: "🛶",
    desc: "Virtaava joki kivisellä sorapohjalla.",
    price: 420, rareBoost: 0.8, sizeBoost: 0.45, fishCount: 17, valueMult: 1.26,
    water: ["#74c6d4", "#2f8fa0", "#12515c"], depth: 275, bottom: "gravel", kind: "lake",
    mx: 338, my: 304, mr: 44 },

  { name: "kirkasjarvi", display: "Kirkasvesijärvi", icon: "💧",
    desc: "Kirkasvetinen järvi vaalealla hiekkapohjalla.",
    price: 750, rareBoost: 1.1, sizeBoost: 0.6, fishCount: 18, valueMult: 1.38,
    water: ["#9fe0e8", "#54b6c4", "#1f6b78"], depth: 300, bottom: "sand", kind: "lake",
    mx: 118, my: 452, mr: 54 },

  { name: "isojarvi", display: "Iso järvi", icon: "🏞️",
    desc: "Laaja syvä järvi sorapohjineen.",
    price: 1300, rareBoost: 1.4, sizeBoost: 0.78, fishCount: 19, valueMult: 1.5,
    water: ["#5aa6c8", "#236a90", "#0c2f48"], depth: 345, bottom: "gravel", kind: "lake",
    mx: 292, my: 468, mr: 78 },

  { name: "koskijarvi", display: "Koskijärvi", icon: "💦",
    desc: "Kuohuva koskijärvi kallioisella pohjalla.",
    price: 2100, rareBoost: 1.8, sizeBoost: 0.95, fishCount: 20, valueMult: 1.65,
    water: ["#6fbfe0", "#2d80aa", "#103e5a"], depth: 315, bottom: "rock", kind: "lake",
    mx: 275, my: 222, mr: 46 },

  { name: "vuoristojarvi", display: "Vuoristojärvi", icon: "🏔️",
    desc: "Kylmä syvä vuoristojärvi kalliopohjalla.",
    price: 3400, rareBoost: 2.2, sizeBoost: 1.15, fishCount: 21, valueMult: 1.8,
    water: ["#8fb8e0", "#4d7eb0", "#21456e"], depth: 330, bottom: "rock", kind: "lake",
    mx: 478, my: 288, mr: 54 },

  { name: "rannikko", display: "Rannikkomeri", icon: "⛵",
    desc: "Suolainen rannikkomeri leveine hiekkapohjineen.",
    price: 5200, rareBoost: 2.6, sizeBoost: 1.35, fishCount: 22, valueMult: 1.95,
    water: ["#4f9fbf", "#1d5f86", "#08283f"], depth: 756, bottom: "sand", kind: "sea",
    mx: 738, my: 152, mr: 46 },

  { name: "saaristo", display: "Saaristomeri", icon: "🏝️",
    desc: "Sokkeloinen saaristomeri värikkäine riuttoineen.",
    price: 7800, rareBoost: 3.0, sizeBoost: 1.55, fishCount: 23, valueMult: 2.15,
    water: ["#56b3c0", "#1f7f93", "#0a3a48"], depth: 635, bottom: "reef", kind: "sea",
    mx: 632, my: 366, mr: 46 },

  { name: "avomeri", display: "Avomeri", icon: "🌊",
    desc: "Aava syvä avomeri — suuria ja harvinaisia otuksia!",
    price: 11500, rareBoost: 3.5, sizeBoost: 1.75, fishCount: 24, valueMult: 2.4,
    water: ["#3f7fb0", "#1a4f7e", "#06203a"], depth: 827, bottom: "sand", kind: "sea",
    mx: 888, my: 256, mr: 48 },

  { name: "syvanmeri", display: "Syvänmeri", icon: "🐙",
    desc: "Pimeä syvänmeri mutaisine pohjamutineen.",
    price: 17000, rareBoost: 4.0, sizeBoost: 2.0, fishCount: 34, valueMult: 2.7,
    water: ["#356a9a", "#173f66", "#05182e"], depth: 1238, bottom: "mud", kind: "sea",
    subMode: true, mx: 882, my: 480, mr: 48 },

  { name: "valtameri", display: "Valtameri", icon: "🐋",
    desc: "Pohjaton valtameri louhikkoisine pohjineen.",
    price: 25000, rareBoost: 4.6, sizeBoost: 2.3, fishCount: 26, valueMult: 3.1,
    water: ["#2f5f8e", "#123a60", "#04162c"], depth: 796, bottom: "rock", kind: "sea",
    mx: 668, my: 522, mr: 48 },

  { name: "syvanne", display: "Meren syvänne", icon: "🦑",
    desc: "Maailman syvin pimeä syvänne — hohtavia otuksia.",
    price: 42000, rareBoost: 5.5, sizeBoost: 2.8, fishCount: 50, valueMult: 3.8,
    water: ["#27406a", "#101f3e", "#02060f"], depth: 765, bottom: "abyss", kind: "sea",
    subMode: true, mx: 512, my: 552, mr: 46 },
];
let currentLoc = LOCATIONS[0];

function locByName(n) {
  return LOCATIONS.find(l => l.name === n) || LOCATIONS[0];
}
// --- Aika, yö, vuodenajat & lämpötila ---
const DAY_LENGTH = 360; // pelipäivän pituus sekunteina
const SEASON_DAYS = 3;  // päiviä per vuodenaika
const SEASONS = [
  { name: "Kevät", icon: "🌸", base: 8,  tint: "rgba(150,210,130,0.07)" },
  { name: "Kesä",  icon: "☀️", base: 17, tint: null },
  { name: "Syksy", icon: "🍂", base: 7,  tint: "rgba(205,120,40,0.10)" },
  { name: "Talvi", icon: "❄️", base: -4, tint: "rgba(205,225,248,0.14)" },
];
function seasonIndex() { return Math.floor((state.day - 1) / SEASON_DAYS) % 4; }
function curSeason()   { return SEASONS[seasonIndex()]; }
function absTime()    { return state.day * 24 + state.time; }
function nightAmount() {
  const t = state.time;
  if (t >= 20 || t < 6) return 1;    // yö 20:00–06:00
  if (t >= 8 && t < 18) return 0;    // päivä 08:00–18:00
  if (t < 8) return (8 - t) / 2;     // aamuhämärä 06:00–08:00
  return (t - 18) / 2;               // iltahämärä 18:00–20:00
}
function isNight() { const t = state.time; return t >= 20 || t < 6; }
function tempFishMult() {
  const t = state.temp;
  if (t >= 5 && t <= 10) return 1.3;
  const d = t < 5 ? (5 - t) : (t - 10);
  return Math.max(0.45, 1.3 - d * 0.075);
}
function fishCap() {
  const base = currentLoc ? currentLoc.fishCount : 16;
  let mult = 1;
  if (isNight()) mult *= 1.45;        // yöllä enemmän kalaa
  mult *= tempFishMult();             // lämpötilan vaikutus
  return Math.max(6, Math.round(base * mult));
}
function advanceTime(dt) {
  state.time += dt * (24 / DAY_LENGTH);
  while (state.time >= 24) {
    state.time -= 24;
    const prevSeason = seasonIndex();
    state.day++;
    if (state.atCottage) {
      state.cottageDays[state.atCottage] = (state.cottageDays[state.atCottage] || 0) + 1;
    }
    state.dayTempOffset = -3 + Math.random() * 6;
    if (seasonIndex() !== prevSeason) {
      const s = curSeason();
      floatText(W / 2, WATER_Y + 70, s.icon + " " + s.name + " alkoi!", "#ffd84a");
    }
  }
  state.temp = curSeason().base
    + 5 * Math.sin((state.time - 9) / 24 * Math.PI * 2)
    + state.dayTempOffset;
}
function setLocation(name) {
  currentLoc = locByName(name);
  state.locationName = currentLoc.name;
  if (locationNameEl) locationNameEl.textContent = currentLoc.icon + " " + currentLoc.display;
}

// =========================================================
// Upgrades (sisältää veneet)
// =========================================================
const UPGRADES = {
  rod:  { name: "Vapa",   desc: "+20 % kelausvoima, -6 % kalan vetovoima", maxLvl: 10, basePrice: 40 },
  line: { name: "Siima",  desc: "+35 syvyyttä, -4 % kalan vetovoima",       maxLvl: 10, basePrice: 60 },
  lure: { name: "Syötti", desc: "Houkuttelee kalat suoraan koukkuun",       maxLvl: 10, basePrice: 80 },
  boat: { name: "Vene",   desc: "Selvästi nopeampi + napakampi kiihdytys (taso 10 = ei liu'u)", maxLvl: 10, basePrice: 150 },
  net:  { name: "Kalaverkko", desc: "Laske verkko — kerää jopa 10 parasta kalaa päivässä", maxLvl: 1, basePrice: 2500 },
  sub:  { name: "Sukellusvene", desc: "Avaa syvänmeret. Parempi taso = enemmän happea", maxLvl: 5, basePrice: 9000, needs: null },
  harpoon: { name: "Harppuuna", desc: "Sukellusveneen ase. Taso = nopeus + kantama", maxLvl: 5, basePrice: 1400, needs: "sub" },
  lamp: { name: "Sukelluslamppu", desc: "Valaisee pimeät syvyydet. Taso = laajempi valokeila", maxLvl: 3, basePrice: 3000, needs: "sub" },
  onki: { name: "Onki", desc: "Mökkilaiturin onki. Taso = pidempi nappaushetki", maxLvl: 4, basePrice: 300 },
  pihdit: { name: "Pihdit", desc: "Kalan irrotukseen mökillä. Taso = napakampi ote", maxLvl: 3, basePrice: 250 },
  otsalamppu: { name: "Otsalamppu", desc: "Yövaruste — näe kalat veden alla ja kalasta atraimella veneestä. Yöllä paina A.", maxLvl: 1, basePrice: 1700 },
};
const BOAT_UPGRADE_KEYS = ["rod", "line", "lure", "boat"];
const BOAT_NAMES = [
  "Soutuvene", "Moottorivene", "Vetouisteluvene", "Kalastusalus",
  "Pikavene", "Rannikkokutteri", "Troolari", "Hinaaja",
  "Risteilijä", "Tutkimusalus", "Lippulaiva",
];

// =========================================================
// State
// =========================================================
const state = {
  running: false,
  paused: false,
  money: 0,
  bucket: [],
  upgrades: { rod: 0, line: 0, lure: 0, boat: 0, net: 0, sub: 0, harpoon: 0, lamp: 0, onki: 0, pihdit: 0, otsalamppu: 0 },
  worms: 0,
  unlocked: ["kotijarvi"],
  cottages: [],
  cottageItems: [],        // ostetut mökkiparannukset
  cottageDays: {},         // päiviä vietetty kullakin mökillä
  atrainCharges: 3,        // mökin atrain: 3 ohilaukausta putkeen → atrain hukkuu
  atCottage: null,         // mökin nimi jos pelaaja on mökillä
  cottagePlayer: { x: 360, vx: 0, facing: 1, walkPhase: 0 },
  locationName: "kotijarvi",
  lampPos: { x: -20, y: -4 },
  harpoonPos: { x: 20, y: 8 },
  time: 8,                 // kellonaika tunteina 0-24
  day: 1,                  // pelipäivä
  dayTempOffset: 2,        // päivän lämpötilan satunnaisvaihtelu
  temp: 12,                // nykyinen lämpötila °C
  net: { deployed: false, deployAbs: 0, locName: "" },
  deadTime: 0,
  lastT: 0,
  boatX: W / 2,
  boatVX: 0,
  line: {
    out: false,
    x: 0, y: 0,
    depth: 0,
    descendSpeed: 200,
    catches: [],   // up to MAX_CATCHES hooked fish
    cutTimer: 0,   // seconds while a linecutter has been on the line
  },
  fish: [],
  bubbles: [],
  splashes: [],
  keys: {},
  subMode: false,
  vehicle: "boat",         // "boat" | "sub" — pelaajan valitsema alus
  atrainMode: false,       // yökalastus atraimella veneestä
  atrainGear: { aimX: W / 2, aimY: WATER_Y + 140, spear: null, reload: 0 },
  placing: null,           // "lamp" | "harpoon" | null
  cam: 0,                  // pystysuuntainen kamera (subMode)
  wave: { timer: 0, hit: 0 }, // iso aalto: veneellä syvällä merellä
  sub: {
    x: W / 2, y: WATER_Y, vx: 0, vy: 0,
    oxygen: 40, maxOxygen: 40,
    aimX: W / 2, aimY: WATER_Y + 120,
    harpoon: null,         // { x, y, vx, vy, dist } lentävä harppuuna
    reload: 0,
  },
};
let reelImpulse = 0;
const floatTexts = [];
function floatText(x, y, text, color) {
  floatTexts.push({ x, y, text, color, life: 1.4 });
}

// Cheat codes — type the sequence during gameplay
let cheatBuffer = "";
const CHEATS = {
  fisuu3: () => {
    const real = FISH_TYPES.filter(t => !t.junk && !t.hazard && !t.linecutter);
    for (let i = 0; i < 500; i++) {
      const t = real[Math.floor(Math.random() * real.length)];
      state.bucket.push({ type: t, rotten: false, size: randSize().name });
    }
    floatText(W / 2, WATER_Y + 150, "FISUU3! +500 kalaa ämpäriin", "#00ffe0");
    sfxCatch();
    updateHUD();
    autoSave();
  },
};
function feedCheatKey(ch) {
  if (!ch || ch.length !== 1) return;
  cheatBuffer = (cheatBuffer + ch.toLowerCase()).slice(-32);
  for (const code of Object.keys(CHEATS)) {
    if (cheatBuffer.endsWith(code)) {
      CHEATS[code]();
      cheatBuffer = "";
      return;
    }
  }
}

// =========================================================
// Derived stats from upgrades
// =========================================================
function reelPerTap() { return REEL_PER_TAP_BASE * (1 + 0.20 * state.upgrades.rod); }
function locDepth()    { return currentLoc ? currentLoc.depth : 235; }
function lineFloor()   { return Math.min(locDepth() - 8, H - WATER_Y - 18); }
function escapeDepth() { return Math.min(locDepth(), 470) + 55 + 26 * state.upgrades.line; }
function worldBottom() { return state.subMode ? Math.max(H, WATER_Y + locDepth() + 90) : H; }
function maxCam()      { return Math.max(0, worldBottom() - H); }
function catchPad()    { return 4 + 5 * state.upgrades.lure; }
function lureRange()   { return state.upgrades.lure > 0 ? 70 + state.upgrades.lure * 45 : 0; }
function lureStrength(){ return state.upgrades.lure * 30; } // px/s contribution
function struggleMultiplier() {
  const red = state.upgrades.rod * 0.06 + state.upgrades.line * 0.04;
  return Math.max(0.5, 1 - red);
}
function boatMaxSpeed() { return 240 + 160 * state.upgrades.boat; }
function boatAccel()    { return 550 + 280 * state.upgrades.boat; }
function upgradePrice(key) {
  const u = UPGRADES[key];
  return Math.round(u.basePrice * Math.pow(1.8, state.upgrades[key]));
}
function rodLineMaxed() {
  return state.upgrades.rod >= UPGRADES.rod.maxLvl && state.upgrades.line >= UPGRADES.line.maxLvl;
}
// --- Sukellusvene-tilastot ---
function hasSub()      { return state.upgrades.sub > 0; }
function hasLamp()     { return state.upgrades.lamp > 0; }
function hasHarpoon()  { return state.upgrades.harpoon > 0; }
function hasNet()      { return state.upgrades.net > 0; }
function subOxygenMax(){ return 30 + state.upgrades.sub * 14; }       // s
function subSpeed()    { return 165 + state.upgrades.sub * 27; }      // px/s
function harpoonSpeed(){ return 320 + state.upgrades.harpoon * 95; }  // px/s
function harpoonRange(){ return 230 + state.upgrades.harpoon * 75; }  // px
function harpoonReload(){ return Math.max(0.35, 1.25 - state.upgrades.harpoon * 0.13); } // s
function lampRadius()  { return 86 + state.upgrades.lamp * 46; }
function hasHeadlamp() { return state.upgrades.otsalamppu > 0; }
function hasAtrainTool() { return state.cottageItems.includes("atrain"); }
function atrainSpeed() { return 460; }   // px/s
function atrainRange() { return 380; }   // px
function atrainReload(){ return 0.6; }   // s

// =========================================================
// User / Auth system (paikallinen localStorage-tallennus)
// =========================================================
const USERS_KEY = "fishing_users";
const CURRENT_USER_KEY = "fishing_currentUser";
const GUEST_SAVE_KEY = "fishing_guestSave";
let currentUser = null;

function loadUsers() {
  try { return JSON.parse(localStorage.getItem(USERS_KEY) || "{}"); } catch { return {}; }
}
function saveUsers(u) { localStorage.setItem(USERS_KEY, JSON.stringify(u)); }
function hashPass(p)  { return btoa("salt_v1::" + p); }

function defaultSave() {
  return {
    money: 0,
    upgrades: { rod: 0, line: 0, lure: 0, boat: 0, net: 0, sub: 0, harpoon: 0, lamp: 0, onki: 0, pihdit: 0, otsalamppu: 0 },
    best: 0, bucket: [], unlocked: ["kotijarvi"], location: "kotijarvi",
    lampPos: { x: -20, y: -4 }, harpoonPos: { x: 20, y: 8 }, vehicle: "boat",
    time: 8, day: 1, net: { deployed: false, deployAbs: 0, locName: "" },
    cottages: [], cottageItems: [], cottageDays: {}, atrainCharges: 3, worms: 0,
  };
}
function getCurrentSave() {
  return {
    money: state.money,
    upgrades: { ...state.upgrades },
    best: best,
    bucket: state.bucket.map(b => ({
      name: b.type.name, rotten: !!b.rotten, size: b.size || "medium", locMult: b.locMult || 1,
    })),
    unlocked: [...state.unlocked],
    cottages: [...state.cottages],
    cottageItems: [...state.cottageItems],
    cottageDays: { ...state.cottageDays },
    atrainCharges: state.atrainCharges,
    worms: state.worms,
    atCottage: state.atCottage,
    location: state.locationName,
    lampPos: { ...state.lampPos },
    harpoonPos: { ...state.harpoonPos },
    vehicle: state.vehicle,
    time: state.time,
    day: state.day,
    net: { ...state.net },
  };
}
function applySave(save) {
  const s = save || defaultSave();
  state.money = s.money || 0;
  state.upgrades = {
    rod:  s.upgrades?.rod  || 0,
    line: s.upgrades?.line || 0,
    lure: s.upgrades?.lure || 0,
    boat: s.upgrades?.boat || 0,
    net:  s.upgrades?.net  || 0,
    sub:  s.upgrades?.sub  || 0,
    harpoon: s.upgrades?.harpoon || 0,
    lamp: s.upgrades?.lamp || 0,
    onki: s.upgrades?.onki || 0,
    pihdit: s.upgrades?.pihdit || 0,
    otsalamppu: s.upgrades?.otsalamppu || 0,
  };
  state.atrainMode = false;
  state.atrainGear = { aimX: W / 2, aimY: WATER_Y + 140, spear: null, reload: 0 };
  state.worms = s.worms || 0;
  if (s.lampPos) state.lampPos = { x: s.lampPos.x, y: s.lampPos.y };
  if (s.harpoonPos) state.harpoonPos = { x: s.harpoonPos.x, y: s.harpoonPos.y };
  state.vehicle = (s.vehicle === "sub" && (s.upgrades?.sub || 0) > 0) ? "sub" : "boat";
  state.time = (typeof s.time === "number") ? s.time : 8;
  state.day = s.day || 1;
  state.net = s.net && typeof s.net === "object"
    ? { deployed: !!s.net.deployed, deployAbs: s.net.deployAbs || 0, locName: s.net.locName || "" }
    : { deployed: false, deployAbs: 0, locName: "" };
  state.dayTempOffset = -4 + Math.random() * 12;
  best = s.best || 0;
  bestEl.textContent = best;
  state.bucket = (s.bucket || [])
    .map(b => {
      const type = FISH_TYPES.find(t => t.name === b.name);
      return type ? { type, rotten: !!b.rotten, size: b.size || "medium", locMult: b.locMult || 1 } : null;
    })
    .filter(Boolean);
  // Kalapaikat: kotijärvi on aina avoinna
  const validUnlocked = (s.unlocked || []).filter(n => n !== "kotijarvi" && LOCATIONS.some(l => l.name === n));
  state.unlocked = ["kotijarvi", ...new Set(validUnlocked)];
  state.cottages = (s.cottages || []).filter(n => COTTAGES.some(c => c.name === n));
  state.cottageItems = (s.cottageItems || []).filter(n => COTTAGE_ITEMS.some(c => c.name === n));
  state.cottageDays = (s.cottageDays && typeof s.cottageDays === "object") ? { ...s.cottageDays } : {};
  state.atrainCharges = (typeof s.atrainCharges === "number") ? s.atrainCharges : 3;
  state.atCottage = (s.atCottage && state.cottages.includes(s.atCottage)) ? s.atCottage : null;
  if (state.atCottage) {
    state.cottagePlayer = { x: W * 0.42, vx: 0, facing: 1, walkPhase: 0 };
    ensureCottage3D();
    if (cottage3D) {
      cottage3D.active = true;
      cottage3D.player.position.set(0, 0, 4);
      cottage3D.cf = { phase: "idle", t: 0, msg: "", msgLife: 0 };
      cottage3D.bobber.visible = false;
      cottage3D.fishLine.visible = false;
      cottage3D.doorOpening = false;
      cottage3D.doorOpen = 0;
      cottage3D.atrain.flying = false;
      cottage3D.atrain.reload = 0;
      cottage3D.atrain.spear.visible = false;
      cottage3D.inBoat = false;
      cottage3D.boat.x = COTTAGE_BOAT_DOCK.x;
      cottage3D.boat.z = COTTAGE_BOAT_DOCK.z;
      cottage3D.boat.heading = 0;
      cottage3D.items.vene.position.set(COTTAGE_BOAT_DOCK.x, 0.3, COTTAGE_BOAT_DOCK.z);
      cottage3D.items.vene.rotation.y = 0;
      cottage3D.tool = state.cottageItems.includes("atrain") ? "atrain" : "onki";
      buildCottageWorld(state.atCottage);
      syncCottageItems();
    }
  } else if (cottage3D) {
    cottage3D.active = false;
  }
  syncCottageCanvas();
  const loc = s.location && state.unlocked.includes(s.location) ? s.location : "kotijarvi";
  setLocation(loc);
  state.placing = null;
  state.wave.timer = 0;
  state.wave.hit = 0;
  const useSub = state.vehicle === "sub" && hasSub();
  state.subMode = useSub;
  if (useSub) enterSubMode();
  if (currentLoc.subMode && !useSub) state.wave.timer = 12 + Math.random() * 6;
  updateHUD();
}
function autoSave() {
  const save = getCurrentSave();
  if (currentUser) {
    const users = loadUsers();
    if (!users[currentUser]) return;
    users[currentUser].save = save;
    saveUsers(users);
  } else {
    localStorage.setItem(GUEST_SAVE_KEY, JSON.stringify(save));
  }
}
function setAuthMsg(text, ok) {
  authMsg.textContent = text || "";
  authMsg.className = "auth-msg" + (ok ? " ok" : "");
}
function tryLogin() {
  const u = authUser.value.trim();
  const p = authPass.value;
  if (!u || !p) { setAuthMsg("Anna käyttäjänimi ja salasana."); return; }
  const users = loadUsers();
  if (!users[u]) { setAuthMsg("Tiliä ei löydy."); return; }
  if (users[u].passhash !== hashPass(p)) { setAuthMsg("Väärä salasana."); return; }
  finishLogin(u);
}
function tryRegister() {
  const u = authUser.value.trim();
  const p = authPass.value;
  if (u.length < 2) { setAuthMsg("Käyttäjänimi liian lyhyt."); return; }
  if (p.length < 3) { setAuthMsg("Salasana liian lyhyt."); return; }
  const users = loadUsers();
  if (users[u]) { setAuthMsg("Nimi on varattu."); return; }
  users[u] = { passhash: hashPass(p), save: defaultSave() };
  saveUsers(users);
  setAuthMsg("Tili luotu!", true);
  finishLogin(u);
}
function finishLogin(u) {
  currentUser = u;
  localStorage.setItem(CURRENT_USER_KEY, u);
  const users = loadUsers();
  applySave(users[u].save);
  showGameUI(u);
}
function playAsGuest() {
  currentUser = null;
  localStorage.removeItem(CURRENT_USER_KEY);
  try {
    const g = JSON.parse(localStorage.getItem(GUEST_SAVE_KEY) || "null");
    applySave(g);
  } catch { applySave(null); }
  showGameUI("Vieras");
}
function showGameUI(displayName) {
  authDiv.classList.add("hidden");
  userBadge.style.display = "flex";
  userNameEl.textContent = displayName;
  state.running = true;
  state.paused = false;
  if (state.fish.length === 0) {
    for (let i = 0; i < fishCap(); i++) spawnFish();
  }
}
function logout() {
  autoSave();
  currentUser = null;
  localStorage.removeItem(CURRENT_USER_KEY);
  state.running = false;
  state.paused = true;
  state.line.out = false;
  state.line.catches = [];
  state.subMode = false;
  state.placing = null;
  authUser.value = "";
  authPass.value = "";
  setAuthMsg("");
  authDiv.classList.remove("hidden");
  userBadge.style.display = "none";
}
function autoLoginFromStorage() {
  const u = localStorage.getItem(CURRENT_USER_KEY);
  if (!u) return false;
  const users = loadUsers();
  if (!users[u]) return false;
  currentUser = u;
  applySave(users[u].save);
  showGameUI(u);
  return true;
}

// =========================================================
// Game actions
// =========================================================
function spawnFish() {
  const t = randType();
  // Roskat, vaarat ja jättiläiset pysyvät vakiokoossa
  const sizeable = !t.junk && !t.hazard && !t.linecutter;
  const sizeClass = sizeable ? randSize() : SIZE_MEDIUM;
  const fromLeft = Math.random() < 0.5;
  let depth;
  if (state.subMode) {
    // Sukellusvenetilassa kalat levittäytyvät koko syvyyteen
    const wd = locDepth();
    if (t.deepOnly) depth = wd * 0.55 + Math.random() * (wd * 0.4);
    else depth = 60 + Math.random() * (wd - 120);
  } else {
    // Veneellä kalat vain siimalla saavutettavaan syvyyteen
    const capDepth = Math.min(t.maxDepth, lineFloor() - 12);
    const lo = Math.min(t.minDepth, capDepth);
    depth = lo + Math.random() * (capDepth - lo);
  }
  const y = WATER_Y + depth;
  const x = fromLeft ? -40 : W + 40;
  const dir = fromLeft ? 1 : -1;
  const speed = t.speed * (0.7 + Math.random() * 0.6);
  state.fish.push({
    type: t, sizeClass, x, y, dir,
    vx: dir * speed,
    bob: Math.random() * Math.PI * 2,
    bobSpeed: 0.04 + Math.random() * 0.03,
    hooked: false,
    gone: false,
  });
}

function updateHUD() {
  moneyEl.textContent = state.money;
  bucketEl.textContent = state.bucket.length;
  if (state.money > best) {
    best = state.money;
  }
  bestEl.textContent = best;
  if (vehTbtnEl) vehTbtnEl.textContent = state.subMode ? "🤿" : "🚤";
  const L = state.line;
  if (L.catches.length && L.catches.some(c => !c.type.junk)) {
    struggleStat.style.display = "flex";
    const esc = escapeDepth();
    const pct = Math.max(0, Math.min(1, 1 - (L.depth - 100) / (esc - 100)));
    struggleFill.style.width = (pct * 100).toFixed(0) + "%";
  } else {
    struggleStat.style.display = "none";
  }
}

function cast() {
  const L = state.line;
  if (!state.running || state.paused || L.out || state.atCottage || state.subMode) return;
  L.out = true;
  L.x = state.boatX;
  L.y = WATER_Y;
  L.depth = 0;
  L.catches = [];
  L.cutTimer = 0;
  reelImpulse = 0;
  splash(state.boatX, WATER_Y);
}

function releaseFish() {
  const L = state.line;
  if (L.catches.length === 0) return;
  for (const f of L.catches) {
    f.hooked = false;
    f.gone = true;
    f.vx = f.dir * (Math.abs(f.vx) + 0.8);
  }
  L.catches = [];
  L.cutTimer = 0;
  floatText(L.x, L.y, "Irrotettu", "#cccccc");
}

function splash(x, y) {
  for (let i = 0; i < 10; i++) {
    state.splashes.push({
      x, y,
      vx: (Math.random() - 0.5) * 4,
      vy: -Math.random() * 4 - 1,
      life: 0.6,
    });
  }
  sfxSplash();
}
function bubble(x, y) {
  state.bubbles.push({
    x, y,
    r: 1 + Math.random() * 3,
    vy: -20 - Math.random() * 30,
    life: 1 + Math.random() * 1.5,
  });
}

function reelTap() {
  if (!state.line.out) return;
  reelImpulse = Math.min(380, reelImpulse + reelPerTap());
  bubble(state.line.x, state.line.y - 4);
  sfxReel();
}

function landCatch() {
  const L = state.line;
  let plastic = false;
  let scored = false;
  for (const c of L.catches) {
    if (c.type.plastic) {
      plastic = true;
    } else if (c.type.hazard) {
      state.money = Math.max(0, state.money - 3);
      floatText(state.boatX, WATER_Y - 10, "-3 mk pisto!", "#ff7777");
    } else if (c.type.junk) {
      floatText(state.boatX, WATER_Y - 10, "Roska", "#cccccc");
    } else {
      const sizeName = c.sizeClass ? c.sizeClass.name : "medium";
      state.bucket.push({ type: c.type, rotten: false, size: sizeName, locMult: currentLoc.valueMult });
      const prefix = sizeName !== "medium" ? c.sizeClass.label + " " : "";
      floatText(state.boatX, WATER_Y - 10, prefix + c.type.display + " → ämpäri", "#ffd84a");
      scored = true;
    }
    c.gone = true;
  }
  if (scored) sfxCatch();
  L.catches = [];
  L.out = false;
  L.cutTimer = 0;
  reelImpulse = 0;
  if (plastic) {
    floatText(state.boatX, WATER_Y - 30, "MUOVIA!", "#ff5252");
    plasticEffect();
  }
  autoSave();
}

function plasticEffect() {
  state.deadTime = DEAD_TIME;
  state.fish = [];
  for (const b of state.bucket) b.rotten = true;
  floatText(W / 2, WATER_Y + 90, "MYRKKY! Kalat kuolevat!", "#ff5252");
  sfxPlastic();
  for (let i = 0; i < 24; i++) {
    state.bubbles.push({
      x: 50 + Math.random() * (W - 100),
      y: WATER_Y + 30 + Math.random() * (H - WATER_Y - 60),
      r: 2 + Math.random() * 3,
      vy: -10 - Math.random() * 20,
      life: 2 + Math.random(),
    });
  }
  autoSave();
}

function escapeFish() {
  const L = state.line;
  if (L.catches.length === 0) return;
  for (const c of L.catches) {
    c.hooked = false;
    c.gone = true;
    c.vx = c.dir * (Math.abs(c.vx) + 1.5);
  }
  floatText(L.x, L.y, "Karkasi!", "#ff7777");
  L.catches = [];
  L.cutTimer = 0;
  sfxEscape();
}

function cutLine() {
  const L = state.line;
  // Lose 1 level from each boat-fishing upgrade (ei sukellusvene-varusteita)
  for (const key of BOAT_UPGRADE_KEYS) {
    state.upgrades[key] = Math.max(0, state.upgrades[key] - 1);
  }
  // Release all catches
  for (const c of L.catches) {
    c.hooked = false;
    c.gone = true;
    c.vx = c.dir * (Math.abs(c.vx) + 2);
  }
  L.catches = [];
  L.cutTimer = 0;
  L.out = false;
  reelImpulse = 0;
  floatText(W / 2, WATER_Y + 130, "SIIMA KATKESI! Päivitykset -1", "#ff3030");
  sfxSnap();
  autoSave();
}

// =========================================================
// Update loop
// =========================================================
function update(dt) {
  if (!state.running || state.paused) return;

  advanceTime(dt);

  if (state.atCottage) {
    if (cottage3D && cottage3D.active) updateCottage3D(dt);
    else updateCottage(dt);
    updateCottageTimePanel();
    return;
  }
  if (state.subMode) { updateSub(dt); return; }

  // Boat
  const accel = boatAccel();
  const maxSpeed = boatMaxSpeed();
  const movingX = state.keys["ArrowLeft"] || state.keys["ArrowRight"];
  if (state.keys["ArrowLeft"]) state.boatVX -= accel * dt;
  if (state.keys["ArrowRight"]) state.boatVX += accel * dt;
  // Korkeampi vene liukuu hieman; taso 10 pysähtyy heti eikä liu'u itsestään
  let friction = 0.86 + 0.006 * state.upgrades.boat;
  if (state.upgrades.boat >= 10 && !movingX) friction = 0.5;
  state.boatVX *= friction;
  if (Math.abs(state.boatVX) > maxSpeed) state.boatVX = Math.sign(state.boatVX) * maxSpeed;
  state.boatX += state.boatVX * dt;
  if (state.boatX < 50) { state.boatX = 50; state.boatVX = 0; }
  if (state.boatX > W - 50) { state.boatX = W - 50; state.boatVX = 0; }

  reelImpulse = Math.max(0, reelImpulse - REEL_DECAY * dt);

  // Iso aalto: veneellä syvällä merellä
  if (currentLoc.subMode) {
    const wv = state.wave;
    if (wv.hit > 0) {
      wv.hit -= dt;
      if (wv.hit <= 0) { boatSink(); return; }
    } else if (wv.timer > 0) {
      wv.timer -= dt;
      if (wv.timer <= 0) {
        wv.hit = 1.4;
        sfxSplash();
        floatText(state.boatX, surfaceY(state.boatX) - 40, "ISO AALTO!", "#ff5252");
      }
    }
  }

  const L = state.line;
  if (L.out) {
    L.x += (state.boatX - L.x) * Math.min(1, dt * 6);

    if (L.catches.length > 0) {
      // Pull-down = sum of all caught fish struggles
      let pullDown = 0;
      for (const c of L.catches) {
        if (c.type.junk) pullDown += c.type.plastic ? 18 : 25;
        else pullDown += c.type.struggle * struggleMultiplier()
                         * (c.sizeClass ? c.sizeClass.struggleMult : 1);
      }
      const netVel = pullDown - reelImpulse;
      L.depth += netVel * dt;

      // Linecutter timer: if any caught fish is a linecutter and we're not maxed
      const hasLinecutter = L.catches.some(c => c.type.linecutter);
      if (hasLinecutter && !rodLineMaxed()) {
        L.cutTimer += dt;
        if (L.cutTimer >= LINECUT_TIME) {
          cutLine();
          return; // line gone, exit update for this frame
        }
        // Warning text pulse near hook
        if (Math.random() < 0.04) {
          floatText(L.x, L.y - 20, `SIIMA RIKKOUTUU! ${(LINECUT_TIME - L.cutTimer).toFixed(1)}s`, "#ff5252");
        }
      }

      if (L.depth >= escapeDepth()) {
        // Junk falls off, others escape
        const allJunk = L.catches.every(c => c.type.junk);
        if (allJunk) {
          floatText(L.x, L.y, "Putosi", "#cccccc");
          for (const c of L.catches) c.gone = true;
          L.catches = [];
          L.cutTimer = 0;
        } else {
          escapeFish();
        }
      } else if (L.depth <= 0) {
        L.depth = 0;
        landCatch();
      }
    } else {
      // empty line — descend / reel
      const descend = L.descendSpeed * dt;
      const pull = reelImpulse * dt;
      L.depth += descend - pull;
      const floor = lineFloor();
      if (L.depth >= floor) L.depth = floor;
      if (L.depth <= 0) {
        L.depth = 0;
        L.out = false;
      }
    }
    L.y = WATER_Y + L.depth;

    if (Math.random() < 0.3) bubble(L.x + (Math.random() - 0.5) * 4, L.y);

    // Try to hook a fish (up to MAX_CATCHES) — uses lure upgrade for radius
    if (L.catches.length < MAX_CATCHES) {
      const pad = catchPad();
      for (const f of state.fish) {
        if (f.gone || f.hooked) continue;
        if (L.catches.includes(f)) continue;
        const dx = f.x - L.x;
        const dy = f.y - L.y;
        const fsc = f.sizeClass ? f.sizeClass.scale : 1;
        if (Math.abs(dx) < f.type.w * fsc / 2 + pad && Math.abs(dy) < f.type.h * fsc / 2 + pad) {
          L.catches.push(f);
          f.hooked = true;
          if (f.type.hazard) floatText(L.x, L.y, "Meduusa!", "#ff7777");
          if (f.type.linecutter && !rodLineMaxed()) {
            floatText(L.x, L.y - 24, "VAROITUS: jättiläinen!", "#ff5252");
          }
          sfxBite();
          if (L.catches.length >= MAX_CATCHES) break;
        }
      }
    }
  }

  // Fish movement & lure homing
  const lr = lureRange();
  const ls = lureStrength();
  const lureActive = lr > 0 && L.out;
  for (const f of state.fish) {
    if (f.hooked && L.catches.includes(f)) {
      // Position around the hook in a small spread
      const idx = L.catches.indexOf(f);
      const total = L.catches.length;
      const angle = (idx / total) * Math.PI * 2;
      const radius = total > 1 ? 12 : 0;
      f.x = L.x + Math.cos(angle) * radius;
      f.y = L.y + Math.sin(angle) * radius;
      continue;
    }
    f.bob += f.bobSpeed;
    f.x += f.vx * dt * 60;
    if (!f.gone) f.y += Math.sin(f.bob) * 0.3;

    // Lure homing — strong at high levels (real fish only)
    if (lureActive && !f.gone && !f.type.junk && !f.type.hazard && !f.type.plastic && !f.type.linecutter) {
      const dx = L.x - f.x;
      const dy = L.y - f.y;
      const d = Math.hypot(dx, dy);
      if (d < lr && d > 4) {
        const fade = 1 - d / lr;
        const k = ls * fade * dt;
        f.x += (dx / d) * k;
        f.y += (dy / d) * k;
        f.dir = dx > 0 ? 1 : -1;
        // High lure level: fish basically magnetised — small extra snap toward hook
        if (state.upgrades.lure >= 3) {
          f.x += (dx / d) * 6 * dt;
          f.y += (dy / d) * 6 * dt;
        }
      }
    }
  }
  state.fish = state.fish.filter(f => {
    if (L.catches.includes(f)) return true;
    if (f.x < -80 || f.x > W + 80) return false;
    return true;
  });

  // Poisoned water: no new spawns
  if (state.deadTime > 0) {
    state.deadTime = Math.max(0, state.deadTime - dt);
  } else {
    while (state.fish.length < fishCap()) spawnFish();
  }

  // Bubbles, splashes, floatText
  for (const b of state.bubbles) { b.y += b.vy * dt; b.life -= dt; }
  state.bubbles = state.bubbles.filter(b => b.life > 0 && b.y > WATER_Y - 4);
  for (const s of state.splashes) { s.vy += 18 * dt; s.x += s.vx; s.y += s.vy; s.life -= dt; }
  state.splashes = state.splashes.filter(s => s.life > 0);
  for (const t of floatTexts) { t.y -= 30 * dt; t.life -= dt; }
  while (floatTexts.length && floatTexts[0].life <= 0) floatTexts.shift();

  if (state.atrainMode) updateAtrain(dt);

  updateHUD();
}

// =========================================================
// Drawing
// =========================================================
const STAR_POS = [
  [70, 38], [150, 70], [230, 30], [310, 88], [400, 50], [470, 24],
  [540, 78], [620, 44], [700, 92], [780, 34], [840, 66], [110, 100],
  [360, 110], [660, 110], [500, 100],
];
function lerpColor(a, b, t) {
  const pa = [parseInt(a.slice(1, 3), 16), parseInt(a.slice(3, 5), 16), parseInt(a.slice(5, 7), 16)];
  const pb = [parseInt(b.slice(1, 3), 16), parseInt(b.slice(3, 5), 16), parseInt(b.slice(5, 7), 16)];
  const c = pa.map((v, i) => Math.round(v + (pb[i] - v) * t));
  return `rgb(${c[0]},${c[1]},${c[2]})`;
}
function drawSky() {
  const n = nightAmount();
  const g = ctx.createLinearGradient(0, 0, 0, WATER_Y);
  g.addColorStop(0, lerpColor("#ffd9a8", "#0a1838", n));
  g.addColorStop(1, lerpColor("#ffb472", "#243a63", n));
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, WATER_Y);

  // tähdet yöllä
  if (n > 0.15) {
    ctx.fillStyle = `rgba(255,255,240,${(n - 0.15) * 1.1})`;
    for (const sp of STAR_POS) {
      const tw = 0.6 + 0.4 * Math.sin(performance.now() / 600 + sp[0]);
      ctx.beginPath();
      ctx.arc(sp[0], sp[1], 1.5 * tw, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // aurinko / kuu
  if (n < 0.6) {
    ctx.globalAlpha = 1 - n / 0.6;
    ctx.fillStyle = "#fff3c0";
    ctx.beginPath();
    ctx.arc(W - 110, 60, 36, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  } else {
    ctx.globalAlpha = (n - 0.6) / 0.4;
    ctx.fillStyle = "#eef0d8";
    ctx.beginPath();
    ctx.arc(W - 110, 56, 30, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = lerpColor("#ffb472", "#243a63", n);
    ctx.beginPath();
    ctx.arc(W - 122, 50, 26, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  ctx.fillStyle = `rgba(255,255,255,${0.7 - n * 0.45})`;
  drawCloud(120, 50, 1);
  drawCloud(360, 80, 0.7);
  drawCloud(650, 40, 1.2);
}
function drawCloud(x, y, s) {
  ctx.beginPath();
  ctx.arc(x, y, 18 * s, 0, Math.PI * 2);
  ctx.arc(x + 22 * s, y - 6 * s, 22 * s, 0, Math.PI * 2);
  ctx.arc(x + 46 * s, y, 18 * s, 0, Math.PI * 2);
  ctx.fill();
}

function drawWater() {
  const wb = worldBottom();
  const g = ctx.createLinearGradient(0, WATER_Y, 0, wb);
  if (state.deadTime > 0) {
    g.addColorStop(0, "#7d8a3a");
    g.addColorStop(0.4, "#4a5a20");
    g.addColorStop(1, "#1a2510");
  } else {
    const wc = (currentLoc && currentLoc.water) || ["#5db4d8", "#1e6e95", "#0a3552"];
    g.addColorStop(0, wc[0]);
    g.addColorStop(0.4, wc[1]);
    g.addColorStop(1, wc[2]);
  }
  ctx.fillStyle = g;
  if (waveAmp() > 0) {
    // Aaltoileva merenpinta
    ctx.beginPath();
    ctx.moveTo(0, surfaceY(0));
    for (let x = 12; x <= W; x += 12) ctx.lineTo(x, surfaceY(x));
    ctx.lineTo(W, wb);
    ctx.lineTo(0, wb);
    ctx.closePath();
    ctx.fill();
    // vaahtoharja
    ctx.strokeStyle = "rgba(255,255,255,0.5)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(0, surfaceY(0));
    for (let x = 12; x <= W; x += 12) ctx.lineTo(x, surfaceY(x));
    ctx.stroke();
  } else {
    ctx.fillRect(0, WATER_Y, W, wb - WATER_Y);
  }

  if (state.deadTime > 0) {
    ctx.save();
    ctx.font = "bold 28px Segoe UI, sans-serif";
    ctx.textAlign = "center";
    ctx.fillStyle = "rgba(0,0,0,0.55)";
    ctx.fillText("MYRKKY " + state.deadTime.toFixed(1) + " s", W / 2 + 2, WATER_Y + 80 + 2);
    ctx.fillStyle = "#ffeb70";
    ctx.fillText("MYRKKY " + state.deadTime.toFixed(1) + " s", W / 2, WATER_Y + 80);
    ctx.restore();
  }

  // Valonsäteet — vain pinnan lähellä (eivät yllä syvyyksiin)
  const rayBot = Math.min(worldBottom(), WATER_Y + 360);
  ctx.save();
  ctx.globalAlpha = 0.08;
  ctx.fillStyle = "#ffffff";
  for (let i = 0; i < 5; i++) {
    const x = (i * 200 + (performance.now() / 80)) % (W + 200) - 100;
    ctx.beginPath();
    ctx.moveTo(x, WATER_Y);
    ctx.lineTo(x + 60, WATER_Y);
    ctx.lineTo(x + 110, rayBot);
    ctx.lineTo(x + 30, rayBot);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
}

// =========================================================
// Seabed — jokaisella kalapaikalla oma pohja ja syvyys
// =========================================================
const BOTTOM_STYLES = {
  sand:   { floor: "#dcc88a", deep: "#a98f4e", edge: "#efe1ad" },
  mud:    { floor: "#5b4a30", deep: "#332817", edge: "#75603e" },
  weed:   { floor: "#4c5a30", deep: "#27331a", edge: "#67793f" },
  gravel: { floor: "#9b9281", deep: "#5f5a4d", edge: "#b6ad99" },
  rock:   { floor: "#7c7f85", deep: "#3f4248", edge: "#9a9da3" },
  reef:   { floor: "#caa07e", deep: "#7c5038", edge: "#e2bd95" },
  abyss:  { floor: "#1c2433", deep: "#05070d", edge: "#33405a" },
};
function hashStr(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
function mulberry32(a) {
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function floorYat(x) {
  const sb = state.seabed;
  return sb.floorY
    + Math.sin(x * 0.013 + sb.seed) * sb.amp
    + Math.sin(x * 0.041 + sb.seed * 1.7) * sb.amp * 0.45;
}
function buildSeabed() {
  const loc = currentLoc;
  const bottom = loc.bottom || "sand";
  const rugged = (bottom === "rock" || bottom === "abyss" || bottom === "reef");
  state.seabed = {
    loc: loc.name,
    floorY: WATER_Y + loc.depth,
    seed: (hashStr(loc.name) % 1000) / 50,
    amp: rugged ? 16 : 9,
    bottom,
    decor: [],
  };
  const rng = mulberry32(hashStr(loc.name) ^ 0x9e37);
  const decor = state.seabed.decor;
  const rx = () => 26 + rng() * (W - 52);
  const add = (n, fn) => { for (let i = 0; i < n; i++) decor.push(fn()); };

  if (bottom === "sand") {
    add(6, () => ({ kind: "shell", x: rx(), size: 6 + rng() * 6 }));
    add(2, () => ({ kind: "star", x: rx(), size: 9 + rng() * 5 }));
    add(10, () => ({ kind: "pebble", x: rx(), size: 3 + rng() * 4, shade: rng() }));
  } else if (bottom === "mud") {
    add(7, () => ({ kind: "mound", x: rx(), w: 40 + rng() * 70, h: 9 + rng() * 14 }));
    add(8, () => ({ kind: "glow", x: rx(), yOff: 4 + rng() * 14, size: 2 + rng() * 2, phase: rng() * 6, hue: 0.6 }));
  } else if (bottom === "weed") {
    add(18, () => ({ kind: "weed", x: rx(), h: 34 + rng() * 78, sway: 0.5 + rng(), phase: rng() * 6, hue: rng() }));
    add(8, () => ({ kind: "pebble", x: rx(), size: 3 + rng() * 5, shade: rng() }));
  } else if (bottom === "gravel") {
    add(58, () => ({ kind: "pebble", x: rx(), size: 3 + rng() * 8, shade: rng() }));
  } else if (bottom === "rock") {
    add(7, () => ({ kind: "boulder", x: rx(), w: 38 + rng() * 70, h: 26 + rng() * 44, shade: rng() }));
    add(16, () => ({ kind: "pebble", x: rx(), size: 3 + rng() * 7, shade: rng() }));
  } else if (bottom === "reef") {
    add(9, () => ({ kind: "coral", x: rx(), size: 22 + rng() * 38, hue: rng(), branches: 3 + (rng() * 3 | 0) }));
    add(6, () => ({ kind: "weed", x: rx(), h: 26 + rng() * 44, sway: 0.6 + rng(), phase: rng() * 6, hue: rng() }));
  } else if (bottom === "abyss") {
    add(7, () => ({ kind: "jrock", x: rx(), w: 32 + rng() * 78, h: 32 + rng() * 64 }));
    add(13, () => ({ kind: "glow", x: rx(), yOff: 10 + rng() * 70, size: 3 + rng() * 5, phase: rng() * 6, hue: rng() }));
  }
}
function drawSeabedItem(d, st) {
  const t = performance.now();
  const baseY = floorYat(d.x);
  ctx.save();
  if (d.kind === "pebble") {
    const c = (88 + d.shade * 76) | 0;
    ctx.fillStyle = `rgb(${c},${c - 6},${c - 16})`;
    ctx.beginPath();
    ctx.ellipse(d.x, baseY - d.size * 0.4, d.size, d.size * 0.7, 0, 0, Math.PI * 2);
    ctx.fill();
  } else if (d.kind === "mound") {
    ctx.fillStyle = st.floor;
    ctx.globalAlpha = 0.8;
    ctx.beginPath();
    ctx.ellipse(d.x, baseY, d.w / 2, d.h, 0, Math.PI, 0);
    ctx.fill();
  } else if (d.kind === "shell") {
    ctx.translate(d.x, baseY - d.size * 0.35);
    ctx.fillStyle = "#f3e6d0";
    ctx.strokeStyle = "#c9a77c";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(0, d.size * 0.5, d.size, Math.PI, Math.PI * 2);
    ctx.closePath();
    ctx.fill(); ctx.stroke();
    ctx.beginPath();
    for (let i = -2; i <= 2; i++) { ctx.moveTo(0, d.size * 0.5); ctx.lineTo(i * d.size * 0.4, d.size * 0.5 - d.size * 0.9); }
    ctx.stroke();
  } else if (d.kind === "star") {
    ctx.translate(d.x, baseY - d.size * 0.3);
    ctx.fillStyle = "#e88f6a";
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
      const r = i % 2 ? d.size * 0.42 : d.size;
      const a = (i / 10) * Math.PI * 2 - Math.PI / 2;
      const px = Math.cos(a) * r, py = Math.sin(a) * r;
      i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
    }
    ctx.closePath(); ctx.fill();
  } else if (d.kind === "weed") {
    const sway = Math.sin(t / 900 + d.phase) * 10 * d.sway;
    ctx.strokeStyle = `hsl(${90 + d.hue * 45},48%,33%)`;
    ctx.lineWidth = 3 + d.h * 0.03;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(d.x, baseY);
    ctx.quadraticCurveTo(d.x + sway * 0.5, baseY - d.h * 0.55, d.x + sway, baseY - d.h);
    ctx.stroke();
  } else if (d.kind === "boulder") {
    const c = (66 + d.shade * 60) | 0;
    ctx.fillStyle = `rgb(${c},${c + 4},${c + 10})`;
    ctx.beginPath();
    ctx.ellipse(d.x, baseY - d.h * 0.35, d.w / 2, d.h * 0.62, 0, Math.PI, Math.PI * 2);
    ctx.lineTo(d.x + d.w / 2, baseY);
    ctx.lineTo(d.x - d.w / 2, baseY);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,0.16)";
    ctx.beginPath();
    ctx.ellipse(d.x - d.w * 0.15, baseY - d.h * 0.55, d.w * 0.22, d.h * 0.18, 0, 0, Math.PI * 2);
    ctx.fill();
  } else if (d.kind === "coral") {
    const hue = d.hue < 0.5 ? 8 + d.hue * 70 : 270 + (d.hue - 0.5) * 90;
    ctx.strokeStyle = `hsl(${hue},66%,60%)`;
    ctx.lineWidth = 4;
    ctx.lineCap = "round";
    for (let b = 0; b < d.branches; b++) {
      const off = (b - (d.branches - 1) / 2) * d.size * 0.42;
      ctx.beginPath();
      ctx.moveTo(d.x + off, baseY);
      ctx.quadraticCurveTo(d.x + off * 1.4, baseY - d.size * 0.6, d.x + off * 1.8, baseY - d.size);
      ctx.stroke();
    }
  } else if (d.kind === "jrock") {
    ctx.fillStyle = "#10151e";
    ctx.strokeStyle = "#2b3850";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(d.x - d.w / 2, baseY);
    ctx.lineTo(d.x - d.w * 0.2, baseY - d.h);
    ctx.lineTo(d.x + d.w * 0.15, baseY - d.h * 0.6);
    ctx.lineTo(d.x + d.w * 0.45, baseY - d.h * 1.05);
    ctx.lineTo(d.x + d.w / 2, baseY);
    ctx.closePath();
    ctx.fill(); ctx.stroke();
  } else if (d.kind === "glow") {
    const y = baseY - d.yOff;
    const pulse = 0.5 + 0.5 * Math.sin(t / 700 + d.phase);
    const hue = d.hue < 0.5 ? 165 + d.hue * 70 : 280;
    const r = d.size * (1.4 + pulse);
    const gg = ctx.createRadialGradient(d.x, y, 0, d.x, y, r);
    gg.addColorStop(0, `hsla(${hue},90%,72%,${0.45 + pulse * 0.4})`);
    gg.addColorStop(1, `hsla(${hue},90%,60%,0)`);
    ctx.fillStyle = gg;
    ctx.beginPath();
    ctx.arc(d.x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}
function drawSeabed() {
  if (!state.seabed || state.seabed.loc !== currentLoc.name) buildSeabed();
  const sb = state.seabed;
  const st = BOTTOM_STYLES[sb.bottom] || BOTTOM_STYLES.sand;
  const step = 14;

  const wb = worldBottom();
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(0, floorYat(0));
  for (let x = step; x <= W; x += step) ctx.lineTo(x, floorYat(x));
  ctx.lineTo(W, wb);
  ctx.lineTo(0, wb);
  ctx.closePath();
  const g = ctx.createLinearGradient(0, sb.floorY - 24, 0, wb);
  g.addColorStop(0, st.floor);
  g.addColorStop(1, st.deep);
  ctx.fillStyle = g;
  ctx.fill();

  // pohjan reunaviiva
  ctx.beginPath();
  ctx.moveTo(0, floorYat(0));
  for (let x = step; x <= W; x += step) ctx.lineTo(x, floorYat(x));
  ctx.strokeStyle = st.edge;
  ctx.lineWidth = 3;
  ctx.globalAlpha = 0.55;
  ctx.stroke();
  ctx.restore();

  // hiekkapohjan aaltokuviot
  if (sb.bottom === "sand") {
    ctx.save();
    ctx.strokeStyle = "rgba(255,255,255,0.16)";
    ctx.lineWidth = 2;
    for (let i = 0; i < 7; i++) {
      const yy = sb.floorY + 16 + i * 17;
      if (yy > wb - 3) break;
      ctx.beginPath();
      for (let x = 0; x <= W; x += 24) {
        const ry = yy + Math.sin(x * 0.05 + i) * 3;
        x ? ctx.lineTo(x, ry) : ctx.moveTo(x, ry);
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  for (const d of sb.decor) drawSeabedItem(d, st);
}

function drawBoat() {
  const x = state.boatX;
  const y = surfaceY(x) - 4 + Math.sin(performance.now() / 600) * 2;
  const lvl = state.upgrades.boat;
  // Visual tier capped at 3 (after that we just add prestige decorations)
  const vlvl = Math.min(lvl, 3);

  // Hull width grows with level (capped)
  const hullW = 50 + vlvl * 10;
  const hullH = 22 + vlvl * 4;

  // Hull
  const hullColors = ["#7a4321", "#4a4a52", "#3a5078", "#2c4a72"];
  ctx.fillStyle = hullColors[vlvl];
  ctx.beginPath();
  ctx.moveTo(x - hullW, y);
  ctx.lineTo(x + hullW, y);
  ctx.lineTo(x + hullW - 14, y + hullH);
  ctx.lineTo(x - hullW + 14, y + hullH);
  ctx.closePath();
  ctx.fill();

  // Deck stripe
  ctx.fillStyle = "#cdd6dc";
  ctx.fillRect(x - hullW, y - 4, hullW * 2, 5);

  if (vlvl === 0) {
    // Sail
    ctx.strokeStyle = "#5a3a1c";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(x, y - 4);
    ctx.lineTo(x, y - 70);
    ctx.stroke();
    ctx.fillStyle = "#f6efe1";
    ctx.beginPath();
    ctx.moveTo(x + 2, y - 68);
    ctx.lineTo(x + 36, y - 28);
    ctx.lineTo(x + 2, y - 22);
    ctx.closePath();
    ctx.fill();
  } else if (vlvl === 1) {
    // Outboard motor
    ctx.fillStyle = "#1a1a1a";
    ctx.fillRect(x + hullW - 10, y - 14, 16, 14);
    ctx.fillStyle = "#cc3322";
    ctx.fillRect(x + hullW - 6, y - 10, 8, 4);
    // small windshield
    ctx.fillStyle = "rgba(180,200,220,0.55)";
    ctx.beginPath();
    ctx.moveTo(x - 14, y - 4);
    ctx.lineTo(x + 14, y - 4);
    ctx.lineTo(x + 8, y - 18);
    ctx.lineTo(x - 8, y - 18);
    ctx.closePath();
    ctx.fill();
  } else if (vlvl === 2) {
    // Trolling boat with cabin
    ctx.fillStyle = "#dfe5ec";
    ctx.fillRect(x - 22, y - 28, 44, 24);
    ctx.fillStyle = "rgba(140,180,220,0.7)";
    ctx.fillRect(x - 18, y - 24, 16, 14);
    ctx.fillRect(x + 2, y - 24, 16, 14);
    // antenna
    ctx.strokeStyle = "#222";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(x + 18, y - 28);
    ctx.lineTo(x + 22, y - 52);
    ctx.stroke();
    // motor
    ctx.fillStyle = "#1a1a1a";
    ctx.fillRect(x + hullW - 8, y - 10, 14, 10);
  } else {
    // Large fishing vessel
    ctx.fillStyle = "#dfe5ec";
    ctx.fillRect(x - 28, y - 36, 56, 32);
    ctx.fillStyle = "rgba(140,180,220,0.7)";
    ctx.fillRect(x - 24, y - 32, 20, 18);
    ctx.fillRect(x + 4, y - 32, 20, 18);
    // mast with radar
    ctx.strokeStyle = "#1a1a1a";
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(x, y - 36);
    ctx.lineTo(x, y - 70);
    ctx.stroke();
    ctx.fillStyle = "#444";
    ctx.fillRect(x - 10, y - 72, 20, 4);
    // smokestack
    ctx.fillStyle = "#a32525";
    ctx.fillRect(x + 16, y - 50, 8, 18);
    // exhaust
    ctx.fillStyle = "rgba(220,220,220,0.6)";
    ctx.beginPath();
    ctx.arc(x + 20, y - 56, 6, 0, Math.PI * 2);
    ctx.arc(x + 24, y - 62, 8, 0, Math.PI * 2);
    ctx.fill();
  }

  // Prestige decorations for boat levels 4+
  if (lvl >= 4) {
    // flag
    const flagFlap = Math.sin(performance.now() / 200) * 3;
    ctx.fillStyle = lvl >= 8 ? "#f5c542" : "#cc3322";
    ctx.beginPath();
    ctx.moveTo(x, y - 70);
    ctx.lineTo(x + 18 + flagFlap, y - 66);
    ctx.lineTo(x + 18 + flagFlap, y - 58);
    ctx.lineTo(x, y - 62);
    ctx.closePath();
    ctx.fill();
  }
  if (lvl >= 6) {
    // running lights
    const blink = (Math.floor(performance.now() / 400) % 2) === 0;
    ctx.fillStyle = blink ? "#ff5252" : "#5cff5c";
    ctx.beginPath(); ctx.arc(x - 30, y - 6, 2.5, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = blink ? "#5cff5c" : "#ff5252";
    ctx.beginPath(); ctx.arc(x + 30, y - 6, 2.5, 0, Math.PI * 2); ctx.fill();
  }
  if (lvl >= 9) {
    // gold trim
    ctx.strokeStyle = "#f5c542";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x - hullW, y);
    ctx.lineTo(x + hullW, y);
    ctx.stroke();
  }
  if (lvl >= 10) {
    // aura
    ctx.save();
    const auraR = 70 + Math.sin(performance.now() / 300) * 5;
    const grad = ctx.createRadialGradient(x, y - 20, 10, x, y - 20, auraR);
    grad.addColorStop(0, "rgba(245,197,66,0.0)");
    grad.addColorStop(0.7, "rgba(245,197,66,0.15)");
    grad.addColorStop(1, "rgba(245,197,66,0)");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(x, y - 20, auraR, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Fisher
  const fisherX = x - hullW + 28;
  ctx.fillStyle = "#ffd5a8";
  ctx.beginPath();
  ctx.arc(fisherX, y - 4, 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#cc3322";
  ctx.fillRect(fisherX - 5, y - 2, 10, 12);

  const rodTipX = x - hullW - 10;
  const rodTipY = state.line.out ? y - 2 : y - 30;

  if (state.atrainMode) {
    // otsalamppu päässä
    const g = state.atrainGear;
    ctx.fillStyle = "#3a3a3a";
    ctx.fillRect(fisherX - 5, y - 11, 10, 3);
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.fillStyle = "rgba(255,244,180,0.9)";
    ctx.beginPath(); ctx.arc(fisherX, y - 9, 2.6, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    // atrain kädessä, osoittaa tähtäimeen
    const ang = Math.atan2(g.aimY - (y - 4), g.aimX - fisherX);
    drawAtrainSpear(fisherX + Math.cos(ang) * 14, y - 4 + Math.sin(ang) * 14, ang, 24);
  } else {
    // Rod — color reflects rod upgrade level
    const rodColors = ["#222", "#3a3a3a", "#5a3a1c", "#7a5a2c", "#b48a3a", "#f5c542",
                       "#c0e0f0", "#80f8ff", "#ff9eff", "#ffd84a", "#ffffff"];
    ctx.strokeStyle = rodColors[Math.min(state.upgrades.rod, rodColors.length - 1)];
    ctx.lineWidth = 2 + Math.min(state.upgrades.rod, 8) * 0.3;
    ctx.beginPath();
    ctx.moveTo(fisherX, y - 4);
    ctx.lineTo(rodTipX, rodTipY);
    ctx.stroke();
  }

  return { rodTipX, rodTipY };
}
function drawAtrainSpear(x, y, ang, len) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(ang);
  // varsi
  ctx.strokeStyle = "#8a5a30";
  ctx.lineWidth = 3.4;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(-len, 0);
  ctx.lineTo(len * 0.45, 0);
  ctx.stroke();
  // sidonta
  ctx.strokeStyle = "#2a2c2e";
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(len * 0.32, 0);
  ctx.lineTo(len * 0.45, 0);
  ctx.stroke();
  // kolme piikkiä
  ctx.strokeStyle = "#d4dae2";
  ctx.lineWidth = 2.4;
  for (const off of [-5.5, 0, 5.5]) {
    ctx.beginPath();
    ctx.moveTo(len * 0.4, off * 0.45);
    ctx.lineTo(len * 0.45 + 12, off);
    ctx.stroke();
  }
  ctx.lineCap = "butt";
  ctx.restore();
}

function drawLine(rodTip) {
  const L = state.line;
  if (!L.out) return;
  const tense = L.catches.length && L.catches.some(c => !c.type.junk);
  // Stress flash when cutter approaches snap
  const aboutToSnap = L.cutTimer > 0 && L.catches.some(c => c.type.linecutter);
  let stroke = "rgba(255,255,255,0.6)";
  if (tense) stroke = "rgba(255,230,180,0.85)";
  if (aboutToSnap) {
    const pulse = Math.sin(performance.now() / 60) * 0.3 + 0.7;
    stroke = `rgba(255, ${Math.floor(80 * pulse)}, ${Math.floor(80 * pulse)}, 0.95)`;
  }
  ctx.strokeStyle = stroke;
  ctx.lineWidth = aboutToSnap ? 2 : tense ? 1.4 : 1;
  ctx.beginPath();
  ctx.moveTo(rodTip.rodTipX, rodTip.rodTipY);
  if (tense) {
    const mx = (rodTip.rodTipX + L.x) / 2 + Math.sin(performance.now() / 60) * 4;
    const my = (rodTip.rodTipY + L.y) / 2 + 6;
    ctx.quadraticCurveTo(mx, my, L.x, L.y);
  } else {
    ctx.lineTo(L.x, L.y);
  }
  ctx.stroke();

  // Lure attraction ring
  const lr = lureRange();
  if (lr > 0 && L.catches.length < MAX_CATCHES) {
    ctx.strokeStyle = "rgba(245,197,66,0.18)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(L.x, L.y, lr, 0, Math.PI * 2);
    ctx.stroke();
  }

  // Lure visualisation
  const r = 4 + state.upgrades.lure * 1.2;
  ctx.strokeStyle = "#ddd";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(L.x, L.y + r, r, Math.PI * 0.1, Math.PI * 1.1, false);
  ctx.stroke();
  if (state.upgrades.lure > 0) {
    ctx.fillStyle = "rgba(245,197,66,0.4)";
    ctx.beginPath();
    ctx.arc(L.x, L.y + 2, r + 2, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawFish(f) {
  const t = f.type;
  const sc = f.sizeClass ? f.sizeClass.scale : 1;
  ctx.save();
  ctx.translate(f.x, f.y);
  ctx.scale(f.dir * sc, sc);

  if (t.name === "boot") {
    ctx.fillStyle = t.color;
    ctx.fillRect(-14, -8, 18, 16);
    ctx.fillRect(-4, 0, 16, 8);
    ctx.fillStyle = "#3a2515";
    ctx.fillRect(-14, 6, 26, 4);
    ctx.restore();
    return;
  }
  if (t.plastic) {
    ctx.fillStyle = "rgba(225,235,255,0.78)";
    ctx.strokeStyle = "rgba(150,170,200,0.9)";
    ctx.lineWidth = 1;
    const wob = Math.sin(f.bob) * 2;
    ctx.beginPath();
    ctx.moveTo(-13, -10);
    ctx.lineTo(13, -10);
    ctx.quadraticCurveTo(17 + wob, 4, 14, 12);
    ctx.quadraticCurveTo(0, 18 + wob, -14, 12);
    ctx.quadraticCurveTo(-17 - wob, 4, -13, -10);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(-10, -10); ctx.lineTo(-7, -15); ctx.lineTo(-3, -10);
    ctx.moveTo(3, -10);   ctx.lineTo(7, -15);  ctx.lineTo(10, -10);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(-6, -2); ctx.lineTo(-3, 6);
    ctx.moveTo(2, 0);   ctx.lineTo(5, 8);
    ctx.stroke();
    ctx.restore();
    return;
  }
  if (t.name === "ankerias") {
    ctx.fillStyle = t.color;
    ctx.beginPath();
    const segs = 14;
    for (let i = 0; i <= segs; i++) {
      const x = t.w / 2 - (i / segs) * t.w;
      const y = -t.h / 2 + Math.sin(i * 0.7 + f.bob * 3) * 3;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    for (let i = segs; i >= 0; i--) {
      const x = t.w / 2 - (i / segs) * t.w;
      const y = t.h / 2 + Math.sin(i * 0.7 + f.bob * 3) * 3;
      ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#fff";
    ctx.beginPath(); ctx.arc(t.w / 3, -1, 1.6, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#000";
    ctx.beginPath(); ctx.arc(t.w / 3 + 0.4, -1, 0.9, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    return;
  }
  if (t.name === "hai") {
    ctx.fillStyle = t.color;
    ctx.beginPath();
    ctx.ellipse(0, 0, t.w / 2, t.h / 2, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(-t.w / 2, 0);
    ctx.lineTo(-t.w / 2 - 14, -t.h / 2 - 6);
    ctx.lineTo(-t.w / 2 - 14, t.h / 2 + 6);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(-4, -t.h / 2);
    ctx.lineTo(2, -t.h / 2 - 18);
    ctx.lineTo(10, -t.h / 2);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#c2cad2";
    ctx.beginPath();
    ctx.ellipse(0, t.h / 4, t.w / 3, t.h / 3, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#3a4452";
    ctx.lineWidth = 1;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.arc(t.w / 4 - i * 4, 0, 4, -0.6, 0.6);
      ctx.stroke();
    }
    ctx.strokeStyle = "#fff";
    ctx.beginPath();
    ctx.moveTo(t.w / 2 - 10, 6); ctx.lineTo(t.w / 2 - 2, 6);
    ctx.stroke();
    ctx.fillStyle = "#000";
    ctx.beginPath(); ctx.arc(t.w / 3, -4, 2, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    return;
  }
  if (t.name === "sampi") {
    ctx.fillStyle = t.color;
    ctx.beginPath();
    ctx.ellipse(0, 0, t.w / 2, t.h / 2, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(-t.w / 2, 0);
    ctx.lineTo(-t.w / 2 - 12, -t.h / 2);
    ctx.lineTo(-t.w / 2 - 12, t.h / 2);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#1a2025";
    for (let i = -3; i <= 3; i++) {
      const sx = i * 10;
      ctx.beginPath();
      ctx.moveTo(sx - 3, -t.h / 2 + 1);
      ctx.lineTo(sx, -t.h / 2 - 4);
      ctx.lineTo(sx + 3, -t.h / 2 + 1);
      ctx.closePath();
      ctx.fill();
    }
    ctx.fillStyle = "#fff";
    ctx.beginPath(); ctx.arc(t.w / 3, -t.h / 4, 2.5, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#000";
    ctx.beginPath(); ctx.arc(t.w / 3 + 0.5, -t.h / 4, 1.2, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    return;
  }
  if (t.name === "jelly") {
    ctx.fillStyle = t.color;
    ctx.beginPath();
    ctx.arc(0, -2, 12, Math.PI, 0);
    ctx.lineTo(10, 4);
    ctx.lineTo(-10, 4);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = t.color;
    ctx.lineWidth = 1.5;
    for (let i = -2; i <= 2; i++) {
      ctx.beginPath();
      ctx.moveTo(i * 4, 4);
      const wob = Math.sin(f.bob + i) * 3;
      ctx.quadraticCurveTo(i * 4 + wob, 12, i * 4, 18);
      ctx.stroke();
    }
    ctx.restore();
    return;
  }
  if (t.name === "mursu") {
    // Walrus: chubby brown body with tusks
    ctx.fillStyle = t.color;
    ctx.beginPath();
    ctx.ellipse(0, 4, t.w / 2, t.h / 2 - 2, 0, 0, Math.PI * 2);
    ctx.fill();
    // belly
    ctx.fillStyle = "#b89a78";
    ctx.beginPath();
    ctx.ellipse(0, 16, t.w / 3, 10, 0, 0, Math.PI * 2);
    ctx.fill();
    // head
    ctx.fillStyle = t.color;
    ctx.beginPath();
    ctx.arc(t.w / 2 - 5, -2, 16, 0, Math.PI * 2);
    ctx.fill();
    // tusks
    ctx.fillStyle = "#f5efd8";
    ctx.beginPath();
    ctx.moveTo(t.w / 2 + 6, 6); ctx.lineTo(t.w / 2 + 4, 18); ctx.lineTo(t.w / 2 + 9, 17); ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(t.w / 2 + 12, 6); ctx.lineTo(t.w / 2 + 12, 18); ctx.lineTo(t.w / 2 + 16, 17); ctx.closePath();
    ctx.fill();
    // whisker dots
    ctx.fillStyle = "#3a2a15";
    for (let i = 0; i < 3; i++) {
      ctx.beginPath(); ctx.arc(t.w / 2 + 4, 2 + i * 3, 0.8, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(t.w / 2 + 8, 3 + i * 3, 0.8, 0, Math.PI * 2); ctx.fill();
    }
    // eye
    ctx.fillStyle = "#000";
    ctx.beginPath(); ctx.arc(t.w / 2 - 4, -6, 2, 0, Math.PI * 2); ctx.fill();
    // flippers
    ctx.fillStyle = "#6a4a30";
    ctx.beginPath();
    ctx.ellipse(-t.w / 4, 22, 14, 6, 0.3, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    return;
  }
  if (t.name === "delfiini") {
    // Dolphin
    ctx.fillStyle = t.color;
    ctx.beginPath();
    ctx.ellipse(0, 0, t.w / 2, t.h / 2, 0, 0, Math.PI * 2);
    ctx.fill();
    // snout
    ctx.beginPath();
    ctx.moveTo(t.w / 2 - 6, -2);
    ctx.quadraticCurveTo(t.w / 2 + 18, 0, t.w / 2 + 4, 6);
    ctx.lineTo(t.w / 2 - 6, 4);
    ctx.closePath();
    ctx.fill();
    // tail flukes
    ctx.beginPath();
    ctx.moveTo(-t.w / 2, 0);
    ctx.lineTo(-t.w / 2 - 16, -t.h / 2 - 4);
    ctx.lineTo(-t.w / 2 - 8, 0);
    ctx.lineTo(-t.w / 2 - 16, t.h / 2 + 4);
    ctx.closePath();
    ctx.fill();
    // dorsal fin
    ctx.beginPath();
    ctx.moveTo(-2, -t.h / 2);
    ctx.quadraticCurveTo(2, -t.h / 2 - 14, 12, -t.h / 2 + 1);
    ctx.closePath();
    ctx.fill();
    // pectoral fin
    ctx.fillStyle = "#4a6e8a";
    ctx.beginPath();
    ctx.ellipse(6, t.h / 3, 10, 4, -0.4, 0, Math.PI * 2);
    ctx.fill();
    // belly (light)
    ctx.fillStyle = "#d6e2ec";
    ctx.beginPath();
    ctx.ellipse(0, t.h / 4, t.w / 2.5, t.h / 4, 0, 0, Math.PI * 2);
    ctx.fill();
    // smile
    ctx.strokeStyle = "#2a3a4a";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(t.w / 2 - 2, 3, 5, 0, Math.PI / 2);
    ctx.stroke();
    // eye
    ctx.fillStyle = "#000";
    ctx.beginPath(); ctx.arc(t.w / 2 - 8, -4, 1.6, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    return;
  }
  if (t.name === "valas") {
    // Whale: massive dark body
    ctx.fillStyle = t.color;
    ctx.beginPath();
    ctx.ellipse(0, 0, t.w / 2, t.h / 2, 0, 0, Math.PI * 2);
    ctx.fill();
    // tail flukes
    ctx.beginPath();
    ctx.moveTo(-t.w / 2, 0);
    ctx.lineTo(-t.w / 2 - 24, -t.h / 2 - 8);
    ctx.lineTo(-t.w / 2 - 12, 0);
    ctx.lineTo(-t.w / 2 - 24, t.h / 2 + 8);
    ctx.closePath();
    ctx.fill();
    // ridges on top
    ctx.strokeStyle = "#222a30";
    ctx.lineWidth = 1;
    for (let i = -2; i <= 2; i++) {
      ctx.beginPath();
      ctx.moveTo(i * 12, -t.h / 2 + 2);
      ctx.lineTo(i * 12 + 4, -t.h / 2 - 2);
      ctx.stroke();
    }
    // belly grooves
    ctx.strokeStyle = "#6a7888";
    for (let i = -4; i <= 4; i++) {
      ctx.beginPath();
      ctx.moveTo(i * 6, t.h / 4);
      ctx.lineTo(i * 6, t.h / 2 + 4);
      ctx.stroke();
    }
    // belly (light underbelly)
    ctx.fillStyle = "#aabac8";
    ctx.beginPath();
    ctx.ellipse(0, t.h / 4, t.w / 2.2, t.h / 3.5, 0, 0, Math.PI * 2);
    ctx.fill();
    // blowhole spout
    if (Math.sin(performance.now() / 600) > 0.85) {
      ctx.fillStyle = "rgba(220,235,255,0.7)";
      ctx.beginPath();
      ctx.arc(-10, -t.h / 2 - 10, 6, 0, Math.PI * 2);
      ctx.arc(-6, -t.h / 2 - 18, 8, 0, Math.PI * 2);
      ctx.fill();
    }
    // eye
    ctx.fillStyle = "#000";
    ctx.beginPath(); ctx.arc(t.w / 2 - 18, 0, 2.2, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    return;
  }
  if (t.name === "kraken") {
    // tentacles
    ctx.fillStyle = "#4a2240";
    ctx.strokeStyle = "#4a2240";
    ctx.lineWidth = 9;
    ctx.lineCap = "round";
    for (let i = 0; i < 6; i++) {
      const baseX = -t.w / 2 + 6 + i * (t.w / 7);
      const wav = Math.sin(f.bob * 2 + i) * 12;
      ctx.beginPath();
      ctx.moveTo(baseX, t.h / 2 - 6);
      ctx.quadraticCurveTo(baseX + wav, t.h / 2 + 18, baseX + wav * 1.6, t.h / 2 + 40);
      ctx.stroke();
    }
    // mantle/head
    const kg = ctx.createRadialGradient(-6, -8, 4, 0, 0, t.w / 2);
    kg.addColorStop(0, "#7a3a64");
    kg.addColorStop(1, "#3c1c34");
    ctx.fillStyle = kg;
    ctx.beginPath();
    ctx.ellipse(0, -2, t.w / 2, t.h / 2, 0, 0, Math.PI * 2);
    ctx.fill();
    // suckers
    ctx.fillStyle = "#9a5a84";
    for (let i = 0; i < 5; i++) {
      ctx.beginPath();
      ctx.arc(-t.w / 3 + i * (t.w / 6), t.h / 4, 3, 0, Math.PI * 2);
      ctx.fill();
    }
    // eyes (glowing)
    for (const ex of [-13, 15]) {
      ctx.fillStyle = "#ffe24a";
      ctx.beginPath(); ctx.arc(ex, -8, 9, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#1a0a14";
      ctx.beginPath(); ctx.arc(ex + 2, -8, 4, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
    return;
  }

  // Generic fish
  ctx.fillStyle = t.color;
  ctx.beginPath();
  ctx.ellipse(0, 0, t.w / 2, t.h / 2, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-t.w / 2, 0);
  ctx.lineTo(-t.w / 2 - 8, -t.h / 2);
  ctx.lineTo(-t.w / 2 - 8, t.h / 2);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,0.4)";
  ctx.beginPath();
  ctx.ellipse(0, t.h / 4, t.w / 3, t.h / 4, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#fff";
  ctx.beginPath();
  ctx.arc(t.w / 3, -t.h / 6, 2.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#000";
  ctx.beginPath();
  ctx.arc(t.w / 3 + 0.5, -t.h / 6, 1.3, 0, Math.PI * 2);
  ctx.fill();
  if (t.name === "gold") {
    ctx.strokeStyle = "rgba(255,255,255,0.6)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.ellipse(0, 0, t.w / 2 + 2, t.h / 2 + 2, 0, 0, Math.PI * 2);
    ctx.stroke();
  }
  if (t.name === "giant") {
    ctx.strokeStyle = "#3a2a15";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(t.w / 2 - 4, 4);
    ctx.quadraticCurveTo(t.w / 2 + 10, 8, t.w / 2 + 14, 14);
    ctx.moveTo(t.w / 2 - 4, 6);
    ctx.quadraticCurveTo(t.w / 2 + 8, 12, t.w / 2 + 10, 18);
    ctx.stroke();
  }

  ctx.restore();
}

function drawBubbles() {
  ctx.strokeStyle = "rgba(255,255,255,0.6)";
  ctx.lineWidth = 1;
  for (const b of state.bubbles) {
    ctx.globalAlpha = Math.min(1, b.life);
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
}
function drawSplashes() {
  ctx.fillStyle = "rgba(255,255,255,0.8)";
  for (const s of state.splashes) {
    ctx.globalAlpha = Math.max(0, s.life);
    ctx.fillRect(s.x, s.y, 2, 2);
  }
  ctx.globalAlpha = 1;
}
function drawFloatTexts() {
  ctx.font = "bold 18px Segoe UI, sans-serif";
  ctx.textAlign = "center";
  for (const t of floatTexts) {
    ctx.globalAlpha = Math.min(1, t.life);
    ctx.fillStyle = "rgba(0,0,0,0.5)";
    ctx.fillText(t.text, t.x + 1, t.y + 1);
    ctx.fillStyle = t.color;
    ctx.fillText(t.text, t.x, t.y);
  }
  ctx.globalAlpha = 1;
}

function drawPauseOverlay() {
  // Only show pause overlay if paused AND shop closed AND game running
  if (!state.paused || !state.running) return;
  if (!shop.classList.contains("hidden")) return;
  ctx.save();
  ctx.fillStyle = "rgba(0,0,0,0.55)";
  ctx.fillRect(0, 0, W, H);
  ctx.textAlign = "center";
  ctx.fillStyle = "#fff";
  ctx.font = "bold 64px Segoe UI, sans-serif";
  ctx.fillText("TAUKO", W / 2, H / 2 - 10);
  ctx.font = "16px Segoe UI, sans-serif";
  ctx.fillStyle = "#cdd6dc";
  ctx.fillText("Paina ESC jatkaaksesi", W / 2, H / 2 + 24);
  ctx.restore();
}

function render() {
  if (state.atCottage) {
    if (cottage3D && cottage3D.active) { renderCottage3D(); return; }
    ctx.clearRect(0, 0, W, H);
    renderCottage();
    return;
  }
  ctx.clearRect(0, 0, W, H);
  if (state.subMode) {
    // Maailma piirretään kameran mukaan (pystyvieritys)
    ctx.save();
    ctx.translate(0, -state.cam);
    drawSky();
    drawWater();
    drawSeabed();
    drawNet();
    for (const f of state.fish) drawFish(f);
    drawSubmarine();
    drawBubbles();
    drawSplashes();
    ctx.restore();
    // Pimeys (ruutukoordinaatit)
    drawDepthDarkness();
    // Harppuuna + tekstit pimeyden päälle
    ctx.save();
    ctx.translate(0, -state.cam);
    drawHarpoon();
    drawFloatTexts();
    ctx.restore();
    drawSubHud();
    drawNightTint();
    drawSeasonTint();
    drawTimePanel();
    drawPauseOverlay();
    return;
  }
  drawSky();
  drawWater();
  drawSeabed();
  drawNet();
  const rodTip = drawBoat();
  for (const f of state.fish) drawFish(f);
  drawLine(rodTip);
  drawBubbles();
  drawSplashes();
  if (state.atrainMode) drawAtrain();
  drawNightTint();
  drawSeasonTint();
  drawFloatTexts();
  drawWaveWarning();
  drawAtrainHint();
  drawTimePanel();
  drawPauseOverlay();
}
function drawNightTint() {
  const n = nightAmount();
  if (n < 0.04) return;
  ctx.save();
  ctx.fillStyle = `rgba(6,14,38,${n * 0.4})`;
  ctx.fillRect(0, 0, W, H);
  ctx.restore();
}
function drawSeasonTint() {
  const tint = curSeason().tint;
  if (!tint) return;
  ctx.save();
  ctx.fillStyle = tint;
  ctx.fillRect(0, 0, W, H);
  ctx.restore();
}
function drawTimePanel() {
  const pw = 158, px = W - pw - 10, py = 10, ph = 84;
  const hh = Math.floor(state.time);
  const mm = Math.floor((state.time - hh) * 60);
  const clock = (hh < 10 ? "0" : "") + hh + ":" + (mm < 10 ? "0" : "") + mm;
  const sea = curSeason();
  ctx.save();
  ctx.fillStyle = "rgba(8,16,30,0.7)";
  ctx.strokeStyle = "rgba(255,255,255,0.18)";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(px, py, pw, ph, 9);
  else ctx.rect(px, py, pw, ph);
  ctx.fill();
  ctx.stroke();
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 15px Segoe UI, sans-serif";
  ctx.fillText("📅 Päivä " + state.day, px + 12, py + 15);
  ctx.font = "bold 14px Segoe UI, sans-serif";
  ctx.fillText(sea.icon + " " + sea.name, px + 12, py + 34);
  ctx.fillText((isNight() ? "🌙 " : "☀️ ") + clock, px + 12, py + 52);
  const t = Math.round(state.temp);
  const good = t >= 5 && t <= 10;
  ctx.fillStyle = good ? "#7ad0a0" : "#ffce6a";
  ctx.fillText("🌡️ " + t + " °C" + (good ? " ✓" : ""), px + 12, py + 70);
  ctx.restore();
}
function drawNet() {
  if (!state.net.deployed || state.net.locName !== state.locationName) return;
  const c = ctx;
  const nx = W * 0.82;
  const top = surfaceY(nx);
  const netW = 148, netH = 138, bot = top + netH;
  const halfT = netW / 2, halfB = netW * 0.33;
  const t = performance.now();
  const sway = Math.sin(t / 780) * 8;
  c.save();
  // kohot pinnalla
  c.fillStyle = "#dd6a3c";
  for (let i = 0; i <= 4; i++) {
    const fx = nx - halfT + i * (netW / 4);
    c.beginPath();
    c.arc(fx, surfaceY(fx) - 1, 5, 0, Math.PI * 2);
    c.fill();
  }
  const tlx = nx - halfT, trx = nx + halfT;
  const blx = nx - halfB + sway, brx = nx + halfB + sway;
  // verkkokuvio leikattuna puolisuunnikkaaseen
  c.save();
  c.beginPath();
  c.moveTo(tlx, top); c.lineTo(trx, top); c.lineTo(brx, bot); c.lineTo(blx, bot);
  c.closePath();
  c.clip();
  c.strokeStyle = "rgba(238,243,248,0.5)";
  c.lineWidth = 1.1;
  for (let d = -netH; d < netW + netH; d += 17) {
    c.beginPath(); c.moveTo(tlx + d, top); c.lineTo(tlx + d + netH * 1.1, bot); c.stroke();
    c.beginPath(); c.moveTo(tlx + d, top); c.lineTo(tlx + d - netH * 1.1, bot); c.stroke();
  }
  // saaliskalat verkossa
  const got = Math.min(10, Math.floor((absTime() - state.net.deployAbs) / 2.2));
  c.fillStyle = "#bcd27a";
  for (let i = 0; i < Math.min(got, 9); i++) {
    const col = i % 3, row = (i / 3) | 0;
    const fx = nx - halfB + 18 + col * (halfB * 0.85) + sway;
    const fy = bot - 22 - row * 30;
    c.save();
    c.translate(fx, fy);
    c.rotate(Math.sin(t / 520 + i) * 0.35);
    c.beginPath(); c.ellipse(0, 0, 9, 4.5, 0, 0, Math.PI * 2); c.fill();
    c.beginPath(); c.moveTo(-9, 0); c.lineTo(-14, -4); c.lineTo(-14, 4); c.closePath(); c.fill();
    c.restore();
  }
  c.restore();
  // reunaköysi + painot
  c.strokeStyle = "rgba(246,249,251,0.8)";
  c.lineWidth = 1.8;
  c.beginPath();
  c.moveTo(tlx, top); c.lineTo(trx, top); c.lineTo(brx, bot); c.lineTo(blx, bot);
  c.closePath();
  c.stroke();
  c.fillStyle = "#3a4654";
  c.beginPath(); c.arc(blx, bot, 4.5, 0, Math.PI * 2); c.fill();
  c.beginPath(); c.arc(brx, bot, 4.5, 0, Math.PI * 2); c.fill();
  c.restore();
}
function drawWaveWarning() {
  if (!currentLoc.subMode || state.subMode) return;
  const wv = state.wave;
  if (wv.hit > 0) {
    const a = 0.22 + 0.22 * Math.sin(performance.now() / 70);
    ctx.save();
    ctx.fillStyle = `rgba(140,24,24,${a})`;
    ctx.fillRect(0, 0, W, H);
    ctx.restore();
  } else if (wv.timer > 0 && wv.timer < 4.2) {
    const a = 0.55 + 0.45 * Math.sin(performance.now() / 110);
    ctx.save();
    ctx.fillStyle = "rgba(190,36,36,0.82)";
    ctx.fillRect(0, 0, W, 46);
    ctx.fillStyle = `rgba(255,255,255,${a})`;
    ctx.font = "bold 21px Segoe UI, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("⚠ ISO AALTO LÄHESTYY — PAKENE KARTALLA (M)!", W / 2, 23);
    ctx.restore();
  }
}

// =========================================================
// Sukellusvene-tila (subMode)
// =========================================================
const darkCanvas = document.createElement("canvas");
darkCanvas.width = W;
darkCanvas.height = H;
const darkCtx = darkCanvas.getContext("2d");

function clampv(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v; }
function isSea() { return !!(currentLoc && currentLoc.kind === "sea"); }
function waveAmp() {
  if (!isSea()) return 0;
  let a = currentLoc.subMode ? 15 : 8;
  if (state.wave && state.wave.hit > 0) a += 75 * Math.min(1, state.wave.hit);
  return a;
}
function surfaceY(x) {
  const amp = waveAmp();
  if (amp === 0) return WATER_Y;
  const t = performance.now() / 1000;
  return WATER_Y + Math.sin(x * 0.018 + t * 1.6) * amp + Math.sin(x * 0.043 - t * 1.1) * amp * 0.4;
}

function enterSubMode() {
  state.subMode = true;
  state.placing = null;
  state.atrainMode = false;
  state.atrainGear.spear = null;
  state.cam = 0;
  const s = state.sub;
  s.x = W / 2; s.y = WATER_Y + 6; s.vx = 0; s.vy = 0;
  s.maxOxygen = subOxygenMax();
  s.oxygen = s.maxOxygen;
  s.aimX = W / 2; s.aimY = WATER_Y + 150;
  s.harpoon = null; s.reload = 0;
}
function renderVehicleRow() {
  if (!vehicleRowEl) return;
  if (!hasSub()) {
    vehicleRowEl.innerHTML =
      `<span class="veh-info">🚤 Käytössä: <b>Laiva</b> — osta sukellusvene, niin voit vaihtaa alusta.</span>`;
    return;
  }
  const cur = state.subMode ? "🤿 Sukellusvene" : "🚤 Laiva";
  const toLabel = state.subMode ? "🚤 Laivaan" : "🤿 Sukellusveneeseen";
  vehicleRowEl.innerHTML =
    `<span class="veh-info">Alus käytössä: <b>${cur}</b></span>` +
    `<button class="loc-btn" id="shopVehBtn">Vaihda ${toLabel}</button>`;
  document.getElementById("shopVehBtn").addEventListener("click", () => {
    switchVehicle();
    renderShop();
  });
}

// --- Kalaverkko ---
function netPickFish(loc) {
  const cands = FISH_TYPES.filter(t => !t.junk && !t.hazard && !t.linecutter && !t.deepOnly);
  let total = 0;
  const ws = cands.map(t => {
    const w = (t.priceMax || 1) * (1 + (loc.rareBoost || 0) * 0.3);
    total += w;
    return w;
  });
  let r = Math.random() * total;
  for (let i = 0; i < cands.length; i++) {
    r -= ws[i];
    if (r <= 0) return cands[i];
  }
  return cands[0];
}
function deployNet() {
  if (!hasNet() || state.net.deployed) return;
  state.net.deployed = true;
  state.net.deployAbs = absTime();
  state.net.locName = state.locationName;
  autoSave();
}
function liftNet() {
  if (!state.net.deployed) return;
  const hrs = absTime() - state.net.deployAbs;
  const n = Math.min(10, Math.floor(hrs / 2.2));
  const loc = locByName(state.net.locName);
  for (let i = 0; i < n; i++) {
    const t = netPickFish(loc);
    const sr = Math.random();
    const size = sr < 0.5 ? "large" : (sr < 0.85 ? "medium" : "small");
    state.bucket.push({ type: t, rotten: false, size, locMult: loc.valueMult });
  }
  state.net.deployed = false;
  if (n > 0) sfxCatch();
  floatText(W / 2, WATER_Y + 96,
    n > 0 ? "Verkko nostettu: " + n + " kalaa ämpäriin" : "Verkko oli vielä tyhjä", "#ffd84a");
  updateHUD();
  autoSave();
}
function renderNetRow() {
  if (!netRowEl) return;
  if (!hasNet()) {
    netRowEl.innerHTML =
      `<span class="veh-info">🪤 Osta kalaverkko, niin voit kerätä kaloja päivän aikana.</span>`;
    return;
  }
  if (!state.net.deployed) {
    netRowEl.innerHTML =
      `<span class="veh-info">🪤 Kalaverkko valmiina</span>` +
      `<button class="loc-btn" id="shopNetBtn">Laske verkko</button>`;
    document.getElementById("shopNetBtn").addEventListener("click", () => {
      deployNet();
      renderShop();
    });
  } else {
    const hrs = absTime() - state.net.deployAbs;
    const got = Math.min(10, Math.floor(hrs / 2.2));
    const loc = locByName(state.net.locName);
    netRowEl.innerHTML =
      `<span class="veh-info">🪤 Verkko: <b>${loc.display}</b> · ${got}/10 kalaa</span>` +
      `<button class="loc-btn" id="shopNetBtn">Nosta verkko</button>`;
    document.getElementById("shopNetBtn").addEventListener("click", () => {
      liftNet();
      renderShop();
    });
  }
}
function switchVehicle() {
  if (!state.running || state.atCottage) return;
  if (!hasSub()) {
    floatText(W / 2, WATER_Y + 96, "Osta sukellusvene kaupasta (K)", "#ff9090");
    return;
  }
  // Veden alla sukellusveneestä ei voi vaihtaa veneeseen
  if (state.subMode && state.vehicle === "sub" && state.sub.y > WATER_Y + 40) {
    floatText(state.sub.x, state.sub.y - 54, "Nouse ensin pintaan!", "#ff9090");
    return;
  }
  state.vehicle = state.vehicle === "sub" ? "boat" : "sub";
  const useSub = state.vehicle === "sub";
  state.subMode = useSub;
  resetScene();
  if (useSub) enterSubMode();
  if (currentLoc.subMode && !useSub) state.wave.timer = 12 + Math.random() * 6;
  floatText(W / 2, WATER_Y + 96,
    useSub ? "Sukellusvene käyttöön" : "Laiva käyttöön", "#ffd84a");
  updateHUD();
  autoSave();
}
function subDeath() {
  state.upgrades.sub = 0;
  state.vehicle = "boat";
  state.subMode = false;
  state.placing = null;
  sfxSnap();
  setLocation("kotijarvi");
  resetScene();
  floatText(W / 2, WATER_Y + 90, "HAPPI LOPPUI!", "#ff3030");
  floatText(W / 2, WATER_Y + 122, "Sukellusvene menetetty — osta uusi.", "#ff7777");
  updateHUD();
  autoSave();
}
// Editori kiertää: pois -> lamppu -> harppuuna -> pois (ohittaa ei-omistetut)
function cycleEditor() {
  const haveLamp = hasLamp(), haveHarp = hasHarpoon();
  if (!haveLamp && !haveHarp) {
    floatText(state.sub.x, state.sub.y - 44, "Osta lamppu tai harppuuna kaupasta", "#ff9090");
    state.placing = null;
    return;
  }
  const seq = [null];
  if (haveLamp) seq.push("lamp");
  if (haveHarp) seq.push("harpoon");
  const idx = seq.indexOf(state.placing);
  state.placing = seq[(idx + 1) % seq.length];
}
function placeAtAim() {
  if (!state.placing) return;
  const p = state.placing === "lamp" ? state.lampPos : state.harpoonPos;
  p.x = clampv(state.sub.aimX - state.sub.x, -48, 48);
  p.y = clampv(state.sub.aimY - state.sub.y, -32, 34);
}
function harpoonOrigin() {
  const s = state.sub;
  return { x: s.x + state.harpoonPos.x, y: s.y + state.harpoonPos.y };
}
function fireHarpoon() {
  const s = state.sub;
  if (!hasHarpoon()) {
    floatText(s.x, s.y - 40, "Tarvitset harppuunan!", "#ff9090");
    return;
  }
  if (s.harpoon || s.reload > 0 || state.placing) return;
  const o = harpoonOrigin();
  let dx = s.aimX - o.x, dy = s.aimY - o.y;
  const d = Math.hypot(dx, dy) || 1;
  const spd = harpoonSpeed();
  s.harpoon = { x: o.x, y: o.y, vx: dx / d * spd, vy: dy / d * spd, dist: 0, ox: o.x, oy: o.y };
  sfxReel();
}
function updateHarpoon(dt) {
  const s = state.sub, h = s.harpoon;
  if (!h) return;
  h.x += h.vx * dt;
  h.y += h.vy * dt;
  h.dist += Math.hypot(h.vx, h.vy) * dt;
  for (const f of state.fish) {
    if (f.gone) continue;
    const sc = f.sizeClass ? f.sizeClass.scale : 1;
    if (Math.abs(f.x - h.x) < f.type.w * sc / 2 + 7 &&
        Math.abs(f.y - h.y) < f.type.h * sc / 2 + 7) {
      harpoonCatch(f);
      s.harpoon = null;
      s.reload = harpoonReload();
      return;
    }
  }
  if (h.dist > harpoonRange() || h.x < -30 || h.x > W + 30 ||
      h.y < WATER_Y - 30 || h.y > worldBottom() + 30) {
    s.harpoon = null;
    s.reload = harpoonReload() * 0.55;
  }
}
function harpoonCatch(f) {
  f.gone = true;
  const tp = f.type;
  for (let i = 0; i < 8; i++) bubble(f.x + (Math.random() - 0.5) * 30, f.y + (Math.random() - 0.5) * 20);
  if (tp.plastic) {
    floatText(f.x, f.y, "MUOVIA!", "#ff5252");
    plasticEffect();
    return;
  }
  if (tp.junk) { floatText(f.x, f.y, "Roska", "#cccccc"); return; }
  if (tp.hazard) {
    state.money = Math.max(0, state.money - 3);
    floatText(f.x, f.y, "-3 mk pisto!", "#ff7777");
    updateHUD();
    return;
  }
  const sizeName = f.sizeClass ? f.sizeClass.name : "medium";
  state.bucket.push({ type: tp, rotten: false, size: sizeName, locMult: currentLoc.valueMult });
  const prefix = sizeName !== "medium" ? f.sizeClass.label + " " : "";
  floatText(f.x, f.y - 6, prefix + tp.display + " → ämpäri", "#ffd84a");
  sfxCatch();
  updateHUD();
  autoSave();
}

// =========================================================
// Atrain-yökalastus — keihäskalastus veneestä yöllä otsalampun kanssa
// =========================================================
function atrainOrigin() {
  const x = state.boatX;
  const vlvl = Math.min(state.upgrades.boat, 3);
  const hullW = 50 + vlvl * 10;
  const by = surfaceY(x) - 4 + Math.sin(performance.now() / 600) * 2;
  return { x: x - hullW + 28, y: by - 5 };
}
function toggleAtrainMode() {
  if (!state.running || state.paused) return;
  if (state.atrainMode) { state.atrainMode = false; return; }
  if (state.subMode || state.atCottage) return;
  if (state.line.out) {
    floatText(state.boatX, WATER_Y + 40, "Kelaa siima ensin (S)", "#ff9090");
    return;
  }
  if (currentLoc.subMode) {
    floatText(state.boatX, WATER_Y + 40, "Syvänmeri — käytä sukellusvenettä", "#ff9090");
    return;
  }
  if (!isNight()) {
    floatText(state.boatX, WATER_Y + 40, "Atraimella voi kalastaa vain yöllä", "#ff9090");
    return;
  }
  if (!hasAtrainTool()) {
    floatText(state.boatX, WATER_Y + 40, "Osta atrain mökin sisältä!", "#ff9090");
    return;
  }
  if (!hasHeadlamp()) {
    floatText(state.boatX, WATER_Y + 40, "Osta otsalamppu kaupasta (K)!", "#ff9090");
    return;
  }
  state.atrainMode = true;
  state.atrainGear.spear = null;
  state.atrainGear.reload = 0;
  floatText(state.boatX, WATER_Y - 20, "🔱 Atrain kädessä — tähtää ja heitä!", "#9fe6ff");
}
function fireAtrain() {
  const g = state.atrainGear;
  if (g.spear || g.reload > 0) return;
  const o = atrainOrigin();
  let dx = g.aimX - o.x, dy = g.aimY - o.y;
  const d = Math.hypot(dx, dy) || 1;
  const spd = atrainSpeed();
  g.spear = {
    x: o.x, y: o.y, vx: dx / d * spd, vy: dy / d * spd,
    dist: 0, ox: o.x, oy: o.y, fish: null, returning: false,
  };
  sfxReel();
}
function updateAtrain(dt) {
  const g = state.atrainGear;
  const sp = g.spear;
  if (!isNight() && !sp) {
    state.atrainMode = false;
    floatText(state.boatX, WATER_Y - 20, "Tuli päivä — atrain pois kädestä", "#ffd84a");
    return;
  }
  if (g.reload > 0) g.reload -= dt;
  if (!sp) return;
  // kala kiinni — vedetään atrain ja kala takaisin veneeseen
  if (sp.returning) {
    const o = atrainOrigin();
    const dx = o.x - sp.x, dy = o.y - sp.y;
    const d = Math.hypot(dx, dy) || 1;
    const step = atrainSpeed() * 0.8 * dt;
    sp.vx = dx; sp.vy = dy;
    if (d <= step + 6) {
      // saapui veneeseen — kala ämpäriin
      if (sp.fish) { sp.fish.x = o.x; sp.fish.y = o.y; harpoonCatch(sp.fish); }
      g.spear = null;
      g.reload = atrainReload();
      return;
    }
    sp.x += dx / d * step;
    sp.y += dy / d * step;
    if (sp.fish) { sp.fish.x = sp.x; sp.fish.y = sp.y; }
    return;
  }
  // atrain lentää
  sp.x += sp.vx * dt;
  sp.y += sp.vy * dt;
  sp.dist += Math.hypot(sp.vx, sp.vy) * dt;
  for (const f of state.fish) {
    if (f.gone) continue;
    const sc = f.sizeClass ? f.sizeClass.scale : 1;
    if (Math.abs(f.x - sp.x) < f.type.w * sc / 2 + 8 &&
        Math.abs(f.y - sp.y) < f.type.h * sc / 2 + 8) {
      // osuma — kala kiinni atraimeen, irrota normaalilogiikasta
      const idx = state.fish.indexOf(f);
      if (idx >= 0) state.fish.splice(idx, 1);
      f.hooked = false;
      sp.fish = f;
      sp.returning = true;
      sfxBite();
      return;
    }
  }
  if (sp.dist > atrainRange() || sp.x < -30 || sp.x > W + 30 ||
      sp.y < WATER_Y - 30 || sp.y > H + 30) {
    g.spear = null;
    g.reload = atrainReload() * 0.5;
  }
}

function updateSub(dt) {
  const s = state.sub;

  // Lampun / harppuunan paikan asettelu
  if (state.placing) {
    const p = state.placing === "lamp" ? state.lampPos : state.harpoonPos;
    const mv = 95 * dt;
    if (state.keys["ArrowLeft"] || state.keys["KeyA"]) p.x -= mv;
    if (state.keys["ArrowRight"] || state.keys["KeyD"]) p.x += mv;
    if (state.keys["ArrowUp"] || state.keys["KeyW"]) p.y -= mv;
    if (state.keys["ArrowDown"] || state.keys["KeyS"]) p.y += mv;
    p.x = clampv(p.x, -48, 48);
    p.y = clampv(p.y, -32, 34);
    updateHUD();
    return;
  }

  // Liike (2D)
  const acc = 920;
  if (state.keys["ArrowLeft"] || state.keys["KeyA"]) s.vx -= acc * dt;
  if (state.keys["ArrowRight"] || state.keys["KeyD"]) s.vx += acc * dt;
  if (state.keys["ArrowUp"] || state.keys["KeyW"]) s.vy -= acc * dt;
  if (state.keys["ArrowDown"] || state.keys["KeyS"]) s.vy += acc * dt;
  s.vx *= 0.86; s.vy *= 0.87;
  const mx = subSpeed();
  s.vx = clampv(s.vx, -mx, mx);
  s.vy = clampv(s.vy, -mx, mx);
  s.x += s.vx * dt;
  s.y += s.vy * dt;
  const topY = WATER_Y + 2;
  const botY = WATER_Y + locDepth() - 26;
  if (s.x < 44) { s.x = 44; s.vx = 0; }
  if (s.x > W - 44) { s.x = W - 44; s.vx = 0; }
  if (s.y < topY) { s.y = topY; s.vy = 0; }
  if (s.y > botY) { s.y = botY; s.vy = 0; }

  // Kamera seuraa sukellusvenettä pystysuunnassa
  const camTarget = clampv(s.y - H * 0.52, 0, maxCam());
  state.cam += (camTarget - state.cam) * Math.min(1, dt * 6);

  // Happi
  const atSurface = s.y < WATER_Y + 34;
  if (atSurface) {
    s.oxygen = Math.min(s.maxOxygen, s.oxygen + dt * 9);
  } else {
    s.oxygen -= dt;
    if (s.oxygen <= 0) { subDeath(); return; }
  }

  if (s.reload > 0) s.reload = Math.max(0, s.reload - dt);
  updateHarpoon(dt);

  // Kuplat sukellusveneestä
  if (Math.random() < 0.5) bubble(s.x - 30 + (Math.random() - 0.5) * 12, s.y - 6);

  // Kalat liikkuvat
  for (const f of state.fish) {
    f.bob += f.bobSpeed;
    f.x += f.vx * dt * 60;
    if (!f.gone) f.y += Math.sin(f.bob) * 0.3;
  }
  state.fish = state.fish.filter(f => !f.gone && f.x > -90 && f.x < W + 90);
  if (state.deadTime > 0) {
    state.deadTime = Math.max(0, state.deadTime - dt);
  } else {
    while (state.fish.length < fishCap()) spawnFish();
  }

  for (const b of state.bubbles) { b.y += b.vy * dt; b.life -= dt; }
  state.bubbles = state.bubbles.filter(b => b.life > 0 && b.y > WATER_Y - 4);
  for (const sp of state.splashes) { sp.vy += 18 * dt; sp.x += sp.vx; sp.y += sp.vy; sp.life -= dt; }
  state.splashes = state.splashes.filter(sp => sp.life > 0);
  for (const ft of floatTexts) { ft.y -= 30 * dt; ft.life -= dt; }
  while (floatTexts.length && floatTexts[0].life <= 0) floatTexts.shift();

  updateHUD();
}

function drawSubmarine() {
  const s = state.sub;
  ctx.save();
  ctx.translate(s.x, s.y);

  // propelli (perä, vasemmalla)
  ctx.save();
  ctx.translate(-40, 0);
  ctx.rotate(performance.now() / 80);
  ctx.fillStyle = "#3a4654";
  for (let i = 0; i < 3; i++) {
    ctx.rotate((Math.PI * 2) / 3);
    ctx.beginPath();
    ctx.ellipse(0, -9, 4, 9, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
  ctx.fillStyle = "#566374";
  ctx.fillRect(-44, -3, 8, 6);

  // peräevä
  ctx.fillStyle = "#c98f1e";
  ctx.beginPath();
  ctx.moveTo(-30, -10); ctx.lineTo(-44, -22); ctx.lineTo(-30, -2);
  ctx.closePath(); ctx.fill();

  // runko
  const bg = ctx.createLinearGradient(0, -22, 0, 22);
  bg.addColorStop(0, "#f4c843");
  bg.addColorStop(0.5, "#e0a82e");
  bg.addColorStop(1, "#a87c1c");
  ctx.fillStyle = bg;
  ctx.beginPath();
  ctx.ellipse(0, 0, 38, 22, 0, 0, Math.PI * 2);
  ctx.fill();

  // torni
  ctx.fillStyle = "#d8a72e";
  ctx.beginPath();
  ctx.moveTo(-12, -20); ctx.lineTo(-8, -34); ctx.lineTo(8, -34); ctx.lineTo(12, -20);
  ctx.closePath(); ctx.fill();
  ctx.strokeStyle = "#7c5a14"; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(2, -34); ctx.lineTo(2, -44); ctx.stroke();
  ctx.fillStyle = "#7c5a14";
  ctx.fillRect(2, -46, 9, 4);

  // ikkuna (keula, oikealla)
  ctx.fillStyle = "#1a2530";
  ctx.beginPath(); ctx.arc(22, 0, 12, 0, Math.PI * 2); ctx.fill();
  const wgl = ctx.createRadialGradient(19, -3, 1, 22, 0, 12);
  wgl.addColorStop(0, "#cfeeff");
  wgl.addColorStop(1, "#4f93b8");
  ctx.fillStyle = wgl;
  ctx.beginPath(); ctx.arc(22, 0, 9, 0, Math.PI * 2); ctx.fill();

  // pienet ikkunat
  ctx.fillStyle = "#9fd8ee";
  for (let i = 0; i < 3; i++) {
    ctx.beginPath(); ctx.arc(-2 - i * 12, 2, 3.4, 0, Math.PI * 2); ctx.fill();
  }

  // alaevä
  ctx.fillStyle = "#c98f1e";
  ctx.beginPath();
  ctx.ellipse(-6, 21, 14, 6, 0, 0, Math.PI);
  ctx.fill();

  // harppuunatykki
  if (hasHarpoon()) {
    const hp = state.harpoonPos;
    ctx.save();
    ctx.translate(hp.x, hp.y);
    let ang = Math.atan2(s.aimY - (s.y + hp.y), s.aimX - (s.x + hp.x));
    ctx.rotate(ang);
    ctx.fillStyle = "#445063";
    ctx.fillRect(-5, -5, 22, 10);
    ctx.fillStyle = "#6b7889";
    ctx.fillRect(10, -3, 12, 6);
    ctx.restore();
  }

  // lamppu
  if (hasLamp()) {
    const lp = state.lampPos;
    ctx.save();
    ctx.translate(lp.x, lp.y);
    ctx.fillStyle = "#33404e";
    ctx.fillRect(-7, -7, 14, 14);
    ctx.fillStyle = "#fff0b0";
    ctx.beginPath(); ctx.arc(0, 0, 6, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "rgba(255,240,160,0.5)";
    ctx.beginPath(); ctx.arc(0, 0, 11, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  ctx.restore();

  // asettelutila: korosta liikuteltava osa
  if (state.placing) {
    const p = state.placing === "lamp" ? state.lampPos : state.harpoonPos;
    ctx.save();
    ctx.strokeStyle = "#ffd95e";
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 4]);
    ctx.beginPath();
    ctx.arc(s.x + p.x, s.y + p.y, 16, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
}

function drawHarpoon() {
  const s = state.sub;
  const o = harpoonOrigin();
  if (s.harpoon) {
    const h = s.harpoon;
    // köysi
    ctx.strokeStyle = "rgba(220,220,200,0.6)";
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(o.x, o.y); ctx.lineTo(h.x, h.y); ctx.stroke();
    // keihäs
    const ang = Math.atan2(h.vy, h.vx);
    ctx.save();
    ctx.translate(h.x, h.y);
    ctx.rotate(ang);
    ctx.strokeStyle = "#d8dde4"; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(-16, 0); ctx.lineTo(8, 0); ctx.stroke();
    ctx.fillStyle = "#eef2f6";
    ctx.beginPath();
    ctx.moveTo(16, 0); ctx.lineTo(6, -5); ctx.lineTo(6, 5);
    ctx.closePath(); ctx.fill();
    ctx.restore();
  } else if (hasHarpoon() && s.reload <= 0 && !state.placing) {
    // tähtäysviiva
    ctx.save();
    ctx.strokeStyle = "rgba(255,120,120,0.5)";
    ctx.lineWidth = 1.5;
    ctx.setLineDash([6, 6]);
    let dx = s.aimX - o.x, dy = s.aimY - o.y;
    const d = Math.hypot(dx, dy) || 1;
    const rng = harpoonRange();
    ctx.beginPath();
    ctx.moveTo(o.x, o.y);
    ctx.lineTo(o.x + dx / d * rng, o.y + dy / d * rng);
    ctx.stroke();
    ctx.setLineDash([]);
    // tähtäin
    ctx.strokeStyle = "#ff7070";
    ctx.beginPath(); ctx.arc(s.aimX, s.aimY, 9, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(s.aimX - 13, s.aimY); ctx.lineTo(s.aimX + 13, s.aimY);
    ctx.moveTo(s.aimX, s.aimY - 13); ctx.lineTo(s.aimX, s.aimY + 13);
    ctx.stroke();
    ctx.restore();
  }
}

function radialHole(c, x, y, r) {
  const g = c.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, "rgba(0,0,0,1)");
  g.addColorStop(0.55, "rgba(0,0,0,0.9)");
  g.addColorStop(1, "rgba(0,0,0,0)");
  c.fillStyle = g;
  c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill();
}
function drawAtrain() {
  const o = atrainOrigin();
  const g = state.atrainGear;
  let dx = g.aimX - o.x, dy = g.aimY - o.y;
  const d = Math.hypot(dx, dy) || 1;
  const ux = dx / d, uy = dy / d;
  const px = -uy, py = ux;
  const reach = Math.min(atrainRange() + 60, d + 150);
  const wNear = 16, wFar = 96;
  const conePts = [
    [o.x + px * wNear, o.y + py * wNear],
    [o.x + ux * reach + px * wFar, o.y + uy * reach + py * wFar],
    [o.x + ux * reach - px * wFar, o.y + uy * reach - py * wFar],
    [o.x - px * wNear, o.y - py * wNear],
  ];
  // pimeys veden ylle, valokeila puhkaistaan
  darkCtx.clearRect(0, 0, W, H);
  darkCtx.globalAlpha = 0.9;
  darkCtx.fillStyle = "#02040c";
  darkCtx.fillRect(0, WATER_Y, W, H - WATER_Y);
  darkCtx.globalAlpha = 1;
  darkCtx.globalCompositeOperation = "destination-out";
  const hole = darkCtx.createLinearGradient(o.x, o.y, o.x + ux * reach, o.y + uy * reach);
  hole.addColorStop(0, "rgba(0,0,0,1)");
  hole.addColorStop(0.65, "rgba(0,0,0,0.9)");
  hole.addColorStop(1, "rgba(0,0,0,0)");
  darkCtx.fillStyle = hole;
  darkCtx.beginPath();
  darkCtx.moveTo(conePts[0][0], conePts[0][1]);
  for (let i = 1; i < conePts.length; i++) darkCtx.lineTo(conePts[i][0], conePts[i][1]);
  darkCtx.closePath();
  darkCtx.fill();
  radialHole(darkCtx, o.x, o.y, 46);
  darkCtx.globalCompositeOperation = "source-over";
  ctx.drawImage(darkCanvas, 0, 0);
  // lämmin valohehku
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  const glow = ctx.createLinearGradient(o.x, o.y, o.x + ux * reach, o.y + uy * reach);
  glow.addColorStop(0, "rgba(255,240,170,0.26)");
  glow.addColorStop(1, "rgba(255,240,170,0)");
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.moveTo(conePts[0][0], conePts[0][1]);
  for (let i = 1; i < conePts.length; i++) ctx.lineTo(conePts[i][0], conePts[i][1]);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
  // heitetty atrain tai tähtäys
  if (g.spear) {
    const sp = g.spear;
    ctx.strokeStyle = "rgba(230,230,210,0.6)";
    ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.moveTo(o.x, o.y); ctx.lineTo(sp.x, sp.y); ctx.stroke();
    if (sp.fish) { sp.fish.x = sp.x; sp.fish.y = sp.y; drawFish(sp.fish); }
    drawAtrainSpear(sp.x, sp.y, Math.atan2(sp.vy, sp.vx), 18);
  } else {
    ctx.save();
    const ready = g.reload <= 0;
    ctx.strokeStyle = ready ? "rgba(150,230,255,0.6)" : "rgba(255,170,90,0.45)";
    ctx.lineWidth = 1.5;
    ctx.setLineDash([6, 6]);
    ctx.beginPath();
    ctx.moveTo(o.x, o.y);
    ctx.lineTo(o.x + ux * Math.min(atrainRange(), d), o.y + uy * Math.min(atrainRange(), d));
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.strokeStyle = ready ? "#9fe6ff" : "#ffae66";
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(g.aimX, g.aimY, 9, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(g.aimX - 13, g.aimY); ctx.lineTo(g.aimX + 13, g.aimY);
    ctx.moveTo(g.aimX, g.aimY - 13); ctx.lineTo(g.aimX, g.aimY + 13);
    ctx.stroke();
    ctx.restore();
  }
}
function drawAtrainHint() {
  if (state.subMode || state.atCottage) return;
  let msg = "";
  if (state.atrainMode) {
    msg = "🔱 Tähtää hiirellä · klikkaa / VÄLI = heitä atrain · A = lopeta";
  } else if (isNight() && !currentLoc.subMode && hasAtrainTool() && hasHeadlamp() && !state.line.out) {
    msg = "🔱 Yö — paina A ja kalasta atraimella";
  } else {
    return;
  }
  ctx.save();
  ctx.font = "bold 14px Segoe UI, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  const w = ctx.measureText(msg).width + 26;
  ctx.fillStyle = "rgba(8,16,30,0.78)";
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(W / 2 - w / 2, H - 42, w, 26, 8);
  else ctx.rect(W / 2 - w / 2, H - 42, w, 26);
  ctx.fill();
  ctx.fillStyle = state.atrainMode ? "#9fe6ff" : "#ffd84a";
  ctx.fillText(msg, W / 2, H - 28);
  ctx.restore();
}
function drawDepthDarkness() {
  const s = state.sub;
  const depth = s.y - WATER_Y;
  const dark = clampv((depth - 60) / 820, 0, 0.95);
  if (dark < 0.03) return;

  // Veden yläreuna ruudulla (pinta saattaa olla ruudun yläpuolella)
  const topScreen = clampv(WATER_Y - state.cam, 0, H);
  // Sukellusveneen ja lampun ruutukoordinaatit
  const subSY = s.y - state.cam;

  darkCtx.clearRect(0, 0, W, H);
  darkCtx.globalAlpha = dark;
  darkCtx.fillStyle = "#020610";
  darkCtx.fillRect(0, topScreen, W, H - topScreen);
  darkCtx.globalAlpha = 1;

  darkCtx.globalCompositeOperation = "destination-out";
  radialHole(darkCtx, s.x, subSY, 52);
  if (hasLamp()) {
    radialHole(darkCtx, s.x + state.lampPos.x, subSY + state.lampPos.y, lampRadius());
  }
  darkCtx.globalCompositeOperation = "source-over";
  ctx.drawImage(darkCanvas, 0, 0);

  // lampun lämmin hehku
  if (hasLamp()) {
    const lx = s.x + state.lampPos.x, ly = subSY + state.lampPos.y;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const wg = ctx.createRadialGradient(lx, ly, 0, lx, ly, lampRadius() * 0.9);
    wg.addColorStop(0, "rgba(255,235,150,0.32)");
    wg.addColorStop(1, "rgba(255,235,150,0)");
    ctx.fillStyle = wg;
    ctx.beginPath(); ctx.arc(lx, ly, lampRadius() * 0.9, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }
}

function drawSubHud() {
  const s = state.sub;
  // happimittari
  const bw = 260, bh = 20, bx = (W - bw) / 2, by = 16;
  ctx.save();
  ctx.fillStyle = "rgba(0,0,0,0.55)";
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(bx - 4, by - 4, bw + 8, bh + 8, 8);
  else ctx.rect(bx - 4, by - 4, bw + 8, bh + 8);
  ctx.fill();
  const oxr = clampv(s.oxygen / s.maxOxygen, 0, 1);
  ctx.fillStyle = oxr > 0.3 ? "#5fd0e8" : "#ff5a5a";
  ctx.fillRect(bx, by, bw * oxr, bh);
  ctx.strokeStyle = "rgba(255,255,255,0.4)";
  ctx.lineWidth = 1.5;
  ctx.strokeRect(bx, by, bw, bh);
  ctx.fillStyle = "#fff";
  ctx.font = "bold 13px Segoe UI, sans-serif";
  ctx.textAlign = "center"; ctx.textBaseline = "middle";
  ctx.fillText("HAPPI  " + Math.ceil(s.oxygen) + " s", W / 2, by + bh / 2);
  ctx.restore();

  // syvyys
  ctx.save();
  ctx.fillStyle = "rgba(255,255,255,0.85)";
  ctx.font = "bold 13px Segoe UI, sans-serif";
  ctx.textAlign = "left"; ctx.textBaseline = "top";
  ctx.fillText("Syvyys " + Math.round(s.y - WATER_Y) + " m", 16, 16);
  ctx.fillText(state.subMode ? "Nuolet: ohjaa · hiiri+klik: harppuuna · E: editori (lamppu & harppuuna)" : "", 16, H - 24);
  if (s.reload > 0 && hasHarpoon()) {
    ctx.fillStyle = "#ffce6a";
    ctx.fillText("Ladataan…", 16, 36);
  }
  ctx.restore();

  // editori-vihje
  if (state.placing) {
    ctx.save();
    ctx.fillStyle = "rgba(0,0,0,0.74)";
    ctx.fillRect(W / 2 - 280, H - 70, 560, 46);
    ctx.strokeStyle = "#ffd95e";
    ctx.lineWidth = 2;
    ctx.strokeRect(W / 2 - 280, H - 70, 560, 46);
    ctx.fillStyle = "#ffd95e";
    ctx.font = "bold 15px Segoe UI, sans-serif";
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    const lbl = state.placing === "lamp" ? "🔧 LAMPUN EDITORI" : "🔧 HARPPUUNAN EDITORI";
    ctx.fillText(lbl + " — klikkaa paikka tai siirrä nuolilla · E = vaihda · Esc = valmis",
      W / 2, H - 47);
    ctx.restore();
  }

  // hapen loppumisvaroitus
  if (s.oxygen < 7 && s.y >= WATER_Y + 34) {
    const a = 0.3 + 0.3 * Math.sin(performance.now() / 120);
    ctx.save();
    ctx.fillStyle = `rgba(180,0,0,${a})`;
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = "#fff";
    ctx.font = "bold 26px Segoe UI, sans-serif";
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText("⚠ HAPPI VÄHISSÄ — NOUSE PINNALLE!", W / 2, 70);
    ctx.restore();
  }
}

// =========================================================
// Shop
// =========================================================
function togglePause() {
  if (!state.running) return;
  // Don't pause while shop or map is open (those already pause)
  if (!shop.classList.contains("hidden")) return;
  if (!mapEl.classList.contains("hidden")) return;
  state.paused = !state.paused;
}

function toggleShop() {
  const willOpen = shop.classList.contains("hidden");
  if (willOpen && !mapEl.classList.contains("hidden")) mapEl.classList.add("hidden");
  shop.classList.toggle("hidden");
  state.paused = willOpen && state.running;
  if (willOpen) renderShop();
  else auctionResult.textContent = "";
}

function renderShop() {
  // Bucket list
  shopBucketCount.textContent = state.bucket.length;
  if (state.bucket.length === 0) {
    bucketListEl.innerHTML = "<em>Ämpäri on tyhjä.</em>";
  } else {
    const groups = {};
    for (const b of state.bucket) {
      const size = b.size || "medium";
      const key = b.type.name + "_" + size + (b.rotten ? "_rot" : "");
      if (!groups[key]) groups[key] = { type: b.type, size, rotten: b.rotten, count: 0 };
      groups[key].count++;
    }
    const sizeOrder = { small: 0, medium: 1, large: 2 };
    const rows = Object.values(groups)
      .sort((a, b) => a.type.display.localeCompare(b.type.display)
                      || sizeOrder[a.size] - sizeOrder[b.size])
      .map(g => {
        const scz = sizeByName(g.size);
        const lo = Math.round(g.type.priceMin * scz.valueMult);
        const hi = Math.round(g.type.priceMax * scz.valueMult);
        const price = g.rotten ? "MÄTÄ – 0 mk" : `${lo}–${hi} mk / kpl`;
        const cls = g.rotten ? "row rotten" : "row";
        return `<div class="${cls}"><span>${scz.label} ${g.type.display} ×${g.count}${g.rotten ? " 🤢" : ""}</span><span>${price}</span></div>`;
      }).join("");
    bucketListEl.innerHTML = rows;
  }
  auctionBtn.disabled = state.bucket.length === 0;

  // Upgrades
  shopMoneyEl.textContent = state.money;
  upgradeListEl.innerHTML = "";
  for (const key of Object.keys(UPGRADES)) {
    const u = UPGRADES[key];
    const lvl = state.upgrades[key];
    const maxed = lvl >= u.maxLvl;
    const price = maxed ? 0 : upgradePrice(key);
    const locked = u.needs && state.upgrades[u.needs] <= 0;
    const can = !maxed && !locked && state.money >= price;
    const div = document.createElement("div");
    div.className = "upgrade";
    let extraDesc = "";
    if (key === "boat") extraDesc = ` <em>(${BOAT_NAMES[lvl]})</em>`;
    if (key === "sub" && lvl > 0) extraDesc = ` <em>(${30 + lvl * 14} s happea)</em>`;
    let btnLabel;
    if (maxed) btnLabel = "MAX";
    else if (locked) btnLabel = "🔒 Vaatii sukellusveneen";
    else btnLabel = `Osta · ${price} mk`;
    div.innerHTML = `
      <div class="info">
        <div class="title">${u.name}${extraDesc} <span style="opacity:0.6">(Lvl ${lvl}/${u.maxLvl})</span></div>
        <div class="desc">${u.desc}</div>
      </div>
      <button class="upgrade-btn" ${can ? "" : "disabled"}>
        ${btnLabel}
      </button>`;
    div.querySelector("button").addEventListener("click", () => buyUpgrade(key));
    upgradeListEl.appendChild(div);
  }
  renderVehicleRow();
  renderNetRow();
  renderWormRow();
}
const WORM_BATCH = 10, WORM_PRICE = 120;
function buyWorms() {
  if (state.money < WORM_PRICE) return;
  state.money -= WORM_PRICE;
  state.worms += WORM_BATCH;
  updateHUD();
  renderShop();
  autoSave();
}
function renderWormRow() {
  if (!wormRowEl) return;
  const can = state.money >= WORM_PRICE;
  wormRowEl.innerHTML =
    `<span class="veh-info">🪱 Madot (mökkionkeen): <b>${state.worms}</b></span>` +
    `<button class="loc-btn" id="shopWormBtn" ${can ? "" : "disabled"}>Osta ${WORM_BATCH} matoa · ${WORM_PRICE} mk</button>`;
  if (can) document.getElementById("shopWormBtn").addEventListener("click", buyWorms);
}

function buyUpgrade(key) {
  const u = UPGRADES[key];
  const lvl = state.upgrades[key];
  if (lvl >= u.maxLvl) return;
  if (u.needs && state.upgrades[u.needs] <= 0) return;
  const price = upgradePrice(key);
  if (state.money < price) return;
  state.money -= price;
  state.upgrades[key] = lvl + 1;
  if (key === "sub" && state.subMode) state.sub.maxOxygen = subOxygenMax();
  updateHUD();
  renderShop();
  autoSave();
}

function auctionAll() {
  if (state.bucket.length === 0) return;
  let total = 0;
  let rottenCount = 0;
  for (const b of state.bucket) {
    if (b.rotten) { rottenCount++; continue; }
    const scz = sizeByName(b.size);
    let price = (b.type.priceMin + Math.random() * (b.type.priceMax - b.type.priceMin))
                * scz.valueMult * (b.locMult || 1);
    if (Math.random() < 0.08) price *= 1.6;
    total += Math.max(1, Math.round(price));
  }
  state.bucket = [];
  state.money += total;
  let msg = `Vasara putosi! Saatu yhteensä <b>${total} mk</b>.`;
  if (rottenCount > 0) msg += ` <span style="color:#aaa">(${rottenCount} mätää heitettiin pois)</span>`;
  auctionResult.innerHTML = msg;
  updateHUD();
  renderShop();
  sfxAuction();
  autoSave();
}

// =========================================================
// Map — piirretty seikkailukartta (canvas)
// =========================================================
let mapSelection = null;
let mapHover = null;
let mapRaf = 0;
let mapScene = null;

// Rantaviiva: maa vasemmalla, meri oikealla
const COAST = [
  { x: 602, y: -30 }, { x: 590, y: 64 }, { x: 618, y: 134 }, { x: 560, y: 204 },
  { x: 594, y: 274 }, { x: 520, y: 334 }, { x: 552, y: 404 }, { x: 470, y: 452 },
  { x: 430, y: 512 }, { x: 372, y: 560 }, { x: 296, y: 632 },
];
const MOUNTAINS = [
  { x: 400, base: 206, w: 130, h: 96 },
  { x: 578, base: 204, w: 142, h: 122 },
  { x: 492, base: 214, w: 172, h: 160 },
];
const FOREST_CLUSTERS = [
  { x: 95, y: 300, r: 54, n: 15 },
  { x: 215, y: 238, r: 58, n: 19 },
  { x: 360, y: 448, r: 56, n: 17 },
  { x: 150, y: 560, r: 62, n: 16 },
  { x: 472, y: 396, r: 44, n: 12 },
];
const RIVERS = [
  [{ x: 470, y: 216 }, { x: 420, y: 262 }, { x: 372, y: 300 }, { x: 338, y: 308 },
   { x: 392, y: 362 }, { x: 486, y: 404 }, { x: 582, y: 426 }],
  [{ x: 300, y: 478 }, { x: 378, y: 500 }, { x: 460, y: 520 }, { x: 538, y: 540 }],
];
const MAP_ISLANDS = [
  { x: 596, y: 332, r: 17 }, { x: 668, y: 392, r: 14 },
  { x: 614, y: 408, r: 10 }, { x: 686, y: 344, r: 12 },
];
// Ostettavat kesämökit kartalla
const COTTAGES = [
  { name: "jarvimokki", display: "Järvimökki", price: 600,
    desc: "Punainen hirsimökki tyynen järven rannalla.", mx: 212, my: 170,
    tempOffset: 0, climate: "Leuto järvi-ilmasto" },
  { name: "metsamokki", display: "Metsämökki", price: 2400,
    desc: "Tumma A-mökki syvällä havumetsässä.", mx: 70, my: 360,
    tempOffset: -6, climate: "Viileä varjoisa metsä" },
  { name: "rantamokki", display: "Rantamökki", price: 6000,
    desc: "Vaalea huvila aurinkoisella hiekkarannalla.", mx: 406, my: 516,
    tempOffset: 9, climate: "Lämmin aurinkoranta" },
];
// Mökkiparannukset — ostetaan mökin sisältä
const COTTAGE_ITEMS = [
  { name: "vene",   display: "🛶 Soutuvene", price: 2500, desc: "Vene mökin laiturin viereen.", place: "house" },
  { name: "atrain", display: "🔱 Atrain", price: 2000, desc: "Kalastuskeihäs — onkii ilman matoja, nopeammat nykäisyt ja isompia kaloja.", place: "house" },
  { name: "kukat",  display: "🌷 Kukkapenkit", price: 600, desc: "Kauniit kukkapenkit pihalle.", place: "house" },
  { name: "sauna",  display: "🧖 Sauna",     price: 4500, desc: "Oma rantasauna — sisältä voi ostaa grillin.", place: "house" },
  { name: "valot",  display: "🏮 Pihavalot", price: 1800, desc: "Lyhdyt jotka valaisevat pihan yöllä.", place: "house" },
  { name: "grilli", display: "🍖 Grilli",    price: 700,  desc: "Grillipaikka mökkipihalle.", place: "sauna" },
];

function toggleMap() {
  if (!state.running) return;
  const willOpen = mapEl.classList.contains("hidden");
  if (willOpen && !shop.classList.contains("hidden")) shop.classList.add("hidden");
  mapEl.classList.toggle("hidden");
  state.paused = willOpen && state.running;
  if (willOpen) {
    mapSelection = state.locationName;
    mapHover = null;
    renderMap();
    if (!mapRaf) mapLoop();
  } else if (mapRaf) {
    cancelAnimationFrame(mapRaf);
    mapRaf = 0;
  }
}

function renderMap() {
  if (!mapScene) buildMapScene();
  mapMoneyEl.textContent = state.money;
  renderMapDetail();
}

function mapLoop() {
  if (mapEl.classList.contains("hidden")) { mapRaf = 0; return; }
  drawMapCanvas();
  mapRaf = requestAnimationFrame(mapLoop);
}

function buildMapScene() {
  const rng = mulberry32(20260519);
  const trees = [];
  for (const fc of FOREST_CLUSTERS) {
    for (let i = 0; i < fc.n; i++) {
      const a = rng() * Math.PI * 2;
      const r = Math.sqrt(rng()) * fc.r;
      trees.push({
        x: fc.x + Math.cos(a) * r,
        y: fc.y + Math.sin(a) * r * 0.72,
        s: 0.72 + rng() * 0.6,
        kind: rng() < 0.72 ? 0 : 1,
      });
    }
  }
  trees.sort((a, b) => a.y - b.y);
  const dapple = [];
  for (let i = 0; i < 30; i++) {
    dapple.push({
      x: rng() * 640, y: rng() * MAPH, r: 28 + rng() * 64,
      light: rng() < 0.5, a: 0.05 + rng() * 0.07,
    });
  }
  const sparkle = [];
  for (let i = 0; i < 60; i++) sparkle.push({ x: rng() * MAPW, y: rng() * MAPH, ph: rng() * 6 });
  mapScene = { trees, dapple, sparkle };
}

// --- piirtoapurit ---
function mapCurve(c, pts) {
  c.moveTo(pts[0].x, pts[0].y);
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i], b = pts[i + 1];
    c.quadraticCurveTo(a.x, a.y, (a.x + b.x) / 2, (a.y + b.y) / 2);
  }
  const last = pts[pts.length - 1];
  c.lineTo(last.x, last.y);
}
function closedCurve(c, pts) {
  const n = pts.length;
  c.moveTo((pts[n - 1].x + pts[0].x) / 2, (pts[n - 1].y + pts[0].y) / 2);
  for (let i = 0; i < n; i++) {
    const cur = pts[i], nxt = pts[(i + 1) % n];
    c.quadraticCurveTo(cur.x, cur.y, (cur.x + nxt.x) / 2, (cur.y + nxt.y) / 2);
  }
  c.closePath();
}
function traceLand(c) {
  c.beginPath();
  c.moveTo(-40, -40);
  c.lineTo(COAST[0].x, COAST[0].y);
  for (let i = 0; i < COAST.length - 1; i++) {
    const a = COAST[i], b = COAST[i + 1];
    c.quadraticCurveTo(a.x, a.y, (a.x + b.x) / 2, (a.y + b.y) / 2);
  }
  const last = COAST[COAST.length - 1];
  c.lineTo(last.x, last.y);
  c.lineTo(-40, MAPH + 40);
  c.closePath();
}
function drawMapTree(c, x, y, s, kind) {
  c.fillStyle = "rgba(0,0,0,0.16)";
  c.beginPath(); c.ellipse(x + 3, y + 2, 10 * s, 4 * s, 0, 0, Math.PI * 2); c.fill();
  c.fillStyle = "#5a3f28";
  c.fillRect(x - 2 * s, y - 6 * s, 4 * s, 8 * s);
  if (kind === 0) {
    const cols = ["#33672f", "#3f7a3a", "#4b8c45"];
    for (let i = 0; i < 3; i++) {
      const ty = y - 3 * s - i * 9 * s;
      const tw = (16 - i * 3.4) * s;
      c.fillStyle = cols[i];
      c.beginPath();
      c.moveTo(x, ty - 14 * s);
      c.lineTo(x - tw, ty);
      c.lineTo(x + tw, ty);
      c.closePath(); c.fill();
    }
  } else {
    c.fillStyle = "#3f7a3a";
    c.beginPath(); c.arc(x, y - 12 * s, 11 * s, 0, Math.PI * 2); c.fill();
    c.fillStyle = "rgba(255,255,255,0.16)";
    c.beginPath(); c.arc(x - 3 * s, y - 15 * s, 5 * s, 0, Math.PI * 2); c.fill();
  }
}
function drawMapMountain(c, m) {
  const peakY = m.base - m.h;
  c.fillStyle = "rgba(0,0,0,0.14)";
  c.beginPath(); c.ellipse(m.x + 14, m.base + 5, m.w * 0.55, 15, 0, 0, Math.PI * 2); c.fill();
  c.beginPath();
  c.moveTo(m.x - m.w / 2, m.base);
  c.lineTo(m.x, peakY);
  c.lineTo(m.x + m.w / 2, m.base);
  c.closePath();
  const g = c.createLinearGradient(m.x - m.w / 2, peakY, m.x + m.w / 2, m.base);
  g.addColorStop(0, "#a39d90"); g.addColorStop(0.5, "#827b6e"); g.addColorStop(1, "#605a51");
  c.fillStyle = g; c.fill();
  c.beginPath();
  c.moveTo(m.x, peakY);
  c.lineTo(m.x + m.w / 2, m.base);
  c.lineTo(m.x + m.w * 0.1, m.base);
  c.closePath();
  c.fillStyle = "rgba(0,0,0,0.2)"; c.fill();
  const sy = peakY + m.h * 0.27;
  c.beginPath();
  c.moveTo(m.x, peakY);
  c.lineTo(m.x - m.w * 0.17, sy);
  c.quadraticCurveTo(m.x - m.w * 0.05, sy - 8, m.x, sy - 3);
  c.quadraticCurveTo(m.x + m.w * 0.07, sy - 9, m.x + m.w * 0.18, sy);
  c.closePath();
  c.fillStyle = "#f4f3ee"; c.fill();
}
function drawMapRiver(c, pts) {
  c.save();
  c.lineCap = "round"; c.lineJoin = "round";
  c.beginPath(); mapCurve(c, pts);
  c.lineWidth = 14; c.strokeStyle = "#c7a868"; c.stroke();
  c.beginPath(); mapCurve(c, pts);
  c.lineWidth = 8; c.strokeStyle = "#5fa9cf"; c.stroke();
  c.beginPath(); mapCurve(c, pts);
  c.lineWidth = 3; c.strokeStyle = "rgba(255,255,255,0.3)"; c.stroke();
  c.restore();
}
function drawMapLake(c, loc) {
  const seed = (hashStr(loc.name) % 100) / 16;
  const N = 16, pts = [];
  for (let i = 0; i < N; i++) {
    const a = i / N * Math.PI * 2;
    const rr = 1 + Math.sin(a * 3 + seed) * 0.09 + Math.sin(a * 5 + seed * 2) * 0.05;
    pts.push({ x: loc.mx + Math.cos(a) * loc.mr * rr, y: loc.my + Math.sin(a) * loc.mr * 0.82 * rr });
  }
  c.save();
  c.translate(loc.mx, loc.my); c.scale(1.16, 1.16); c.translate(-loc.mx, -loc.my);
  c.beginPath(); closedCurve(c, pts);
  c.fillStyle = "#e6d29a"; c.fill();
  c.restore();
  c.beginPath(); closedCurve(c, pts);
  const g = c.createRadialGradient(loc.mx - loc.mr * 0.3, loc.my - loc.mr * 0.32, 4, loc.mx, loc.my, loc.mr * 1.25);
  g.addColorStop(0, loc.water[0]); g.addColorStop(0.62, loc.water[1]); g.addColorStop(1, loc.water[2]);
  c.fillStyle = g; c.fill();
  c.lineWidth = 2; c.strokeStyle = "rgba(255,255,255,0.25)"; c.stroke();
  c.save();
  c.beginPath(); closedCurve(c, pts); c.clip();
  c.beginPath();
  c.ellipse(loc.mx - loc.mr * 0.26, loc.my - loc.mr * 0.34, loc.mr * 0.34, loc.mr * 0.15, -0.5, 0, Math.PI * 2);
  c.fillStyle = "rgba(255,255,255,0.22)"; c.fill();
  c.restore();
}
function drawMapShip(c, x, y, s, t) {
  c.save();
  c.translate(x, y);
  c.rotate(Math.sin(t / 700 + x) * 0.09);
  c.scale(s, s);
  c.fillStyle = "rgba(0,0,0,0.18)";
  c.beginPath(); c.ellipse(0, 17, 26, 7, 0, 0, Math.PI * 2); c.fill();
  c.fillStyle = "#7a4a28";
  c.beginPath();
  c.moveTo(-22, 4); c.lineTo(22, 4); c.lineTo(15, 16); c.lineTo(-15, 16);
  c.closePath(); c.fill();
  c.strokeStyle = "#5a3a20"; c.lineWidth = 2.5;
  c.beginPath(); c.moveTo(0, 4); c.lineTo(0, -26); c.stroke();
  c.fillStyle = "#f3ece0";
  c.beginPath(); c.moveTo(2, -24); c.quadraticCurveTo(22, -12, 3, -2); c.closePath(); c.fill();
  c.fillStyle = "#e0d4bd";
  c.beginPath(); c.moveTo(-2, -21); c.quadraticCurveTo(-17, -12, -3, -3); c.closePath(); c.fill();
  c.restore();
}
function drawMapLighthouse(c, x, y) {
  c.save(); c.translate(x, y);
  c.fillStyle = "rgba(0,0,0,0.2)";
  c.beginPath(); c.ellipse(2, 3, 16, 6, 0, 0, Math.PI * 2); c.fill();
  c.beginPath();
  c.moveTo(-9, 2); c.lineTo(-6, -30); c.lineTo(6, -30); c.lineTo(9, 2);
  c.closePath();
  c.fillStyle = "#f0ede6"; c.fill();
  c.fillStyle = "#d8483a";
  c.beginPath(); c.moveTo(-8, -6); c.lineTo(8, -6); c.lineTo(8.6, 2); c.lineTo(-8.6, 2); c.closePath(); c.fill();
  c.beginPath(); c.moveTo(-6.7, -21); c.lineTo(6.7, -21); c.lineTo(7.3, -13); c.lineTo(-7.3, -13); c.closePath(); c.fill();
  c.fillStyle = "#ffd95e"; c.fillRect(-6, -41, 12, 11);
  c.fillStyle = "#3a4654";
  c.beginPath(); c.moveTo(-8, -41); c.lineTo(8, -41); c.lineTo(5, -48); c.lineTo(-5, -48); c.closePath(); c.fill();
  c.restore();
}
function drawMapCabin(c, x, y, s) {
  c.save(); c.translate(x, y); c.scale(s, s);
  c.fillStyle = "rgba(0,0,0,0.16)";
  c.beginPath(); c.ellipse(2, 11, 16, 5, 0, 0, Math.PI * 2); c.fill();
  c.fillStyle = "#9a6038"; c.fillRect(-11, -2, 22, 13);
  c.fillStyle = "#b5482f";
  c.beginPath(); c.moveTo(-14, -2); c.lineTo(0, -16); c.lineTo(14, -2); c.closePath(); c.fill();
  c.fillStyle = "#3a2a1a"; c.fillRect(-3, 3, 6, 8);
  c.restore();
}
function drawMapCompass(c, x, y, r, t) {
  c.save();
  c.translate(x, y);
  c.beginPath(); c.arc(0, 0, r, 0, Math.PI * 2);
  c.fillStyle = "rgba(10,28,42,0.6)"; c.fill();
  c.lineWidth = 3; c.strokeStyle = "#e7d3a0"; c.stroke();
  c.lineWidth = 1; c.strokeStyle = "rgba(231,211,160,0.5)";
  c.beginPath(); c.arc(0, 0, r * 0.78, 0, Math.PI * 2); c.stroke();
  c.rotate(t / 5000);
  c.rotate(Math.PI / 4);
  for (let i = 0; i < 4; i++) {
    c.beginPath();
    c.moveTo(0, -r * 0.52); c.lineTo(r * 0.1, 0); c.lineTo(0, r * 0.1); c.lineTo(-r * 0.1, 0);
    c.closePath();
    c.fillStyle = "#b9c4cf"; c.fill();
    c.rotate(Math.PI / 2);
  }
  c.rotate(-Math.PI / 4);
  for (let i = 0; i < 4; i++) {
    c.beginPath();
    c.moveTo(0, -r * 0.84); c.lineTo(r * 0.15, 0); c.lineTo(0, r * 0.15); c.lineTo(-r * 0.15, 0);
    c.closePath();
    c.fillStyle = i === 0 ? "#e85b4a" : "#eef3f7"; c.fill();
    c.rotate(Math.PI / 2);
  }
  c.restore();
  c.save();
  c.translate(x, y);
  c.fillStyle = "#fff";
  c.font = "bold 12px Segoe UI, sans-serif";
  c.textAlign = "center"; c.textBaseline = "middle";
  c.fillText("N", 0, -r * 0.6);
  c.restore();
}
function drawMapMarker(c, loc, t) {
  const owned = state.unlocked.includes(loc.name);
  const here = state.locationName === loc.name;
  const sel = mapSelection === loc.name;
  const hov = mapHover === loc.name;
  const x = loc.mx, y = loc.my;
  const R = 21 * (hov ? 1.14 : 1) * (sel ? 1.07 : 1);
  c.save();
  if (here) {
    const pulse = 0.5 + 0.5 * Math.sin(t / 380);
    c.beginPath(); c.arc(x, y, R + 7 + pulse * 7, 0, Math.PI * 2);
    c.fillStyle = `rgba(255,214,90,${0.22 + pulse * 0.22})`; c.fill();
  }
  c.beginPath(); c.ellipse(x, y + R + 3, R * 0.82, R * 0.3, 0, 0, Math.PI * 2);
  c.fillStyle = "rgba(0,0,0,0.32)"; c.fill();
  c.beginPath(); c.arc(x, y, R, 0, Math.PI * 2);
  const wg = c.createRadialGradient(x - R * 0.32, y - R * 0.34, 2, x, y, R);
  wg.addColorStop(0, loc.water[0]); wg.addColorStop(1, loc.water[2]);
  c.fillStyle = wg; c.fill();
  c.lineWidth = 4;
  c.strokeStyle = here ? "#ffd95e" : owned ? "#f0c850" : "#9aa6b4";
  c.stroke();
  if (sel) {
    c.lineWidth = 2; c.strokeStyle = "#ffffff";
    c.beginPath(); c.arc(x, y, R + 5, 0, Math.PI * 2); c.stroke();
  }
  c.font = Math.round(R * 1.15) + "px sans-serif";
  c.textAlign = "center"; c.textBaseline = "middle";
  if (!owned) {
    c.globalAlpha = 0.5;
    c.fillText(loc.icon, x, y + 1);
    c.globalAlpha = 1;
    c.font = Math.round(R * 0.92) + "px sans-serif";
    c.fillText("🔒", x, y + 1);
  } else {
    c.fillText(loc.icon, x, y + 1);
  }
  // banneri
  c.font = "bold 13px Segoe UI, sans-serif";
  const label = loc.display;
  const sub = owned ? null : loc.price + " mk";
  const tw = c.measureText(label).width;
  const subw = sub ? (c.font = "bold 11px Segoe UI, sans-serif", c.measureText(sub).width) : 0;
  c.font = "bold 13px Segoe UI, sans-serif";
  const bw = Math.max(tw, subw) + 18;
  const bh = sub ? 33 : 21;
  const by = (y > MAPH - 96) ? y - R - 7 - bh : y + R + 7;
  c.beginPath();
  if (c.roundRect) c.roundRect(x - bw / 2, by, bw, bh, 7);
  else c.rect(x - bw / 2, by, bw, bh);
  c.fillStyle = sel ? "rgba(40,58,82,0.95)" : "rgba(12,22,34,0.84)";
  c.fill();
  if (sel) { c.lineWidth = 1.5; c.strokeStyle = "#ffd95e"; c.stroke(); }
  c.fillStyle = "#ffffff";
  c.textBaseline = "top";
  c.fillText(label, x, by + 4);
  if (sub) {
    c.font = "bold 11px Segoe UI, sans-serif";
    c.fillStyle = "#ffd95e";
    c.fillText("🔒 " + sub, x, by + 19);
  }
  c.restore();
}
function drawMapCottage(c, cot) {
  const owned = state.cottages.includes(cot.name);
  const sel = mapSelection === cot.name;
  const hov = mapHover === cot.name;
  const s = (hov ? 1.32 : 1.16) * (sel ? 1.06 : 1);
  c.save();
  c.globalAlpha = owned ? 1 : 0.62;
  drawMapCabin(c, cot.mx, cot.my, s);
  c.globalAlpha = 1;
  if (sel) {
    c.strokeStyle = "#ffffff";
    c.lineWidth = 2;
    c.setLineDash([5, 4]);
    c.strokeRect(cot.mx - 20 * s, cot.my - 24 * s, 40 * s, 40 * s);
    c.setLineDash([]);
  }
  // banneri
  c.font = "bold 12px Segoe UI, sans-serif";
  const label = owned ? "🏡 " + cot.display : "🪧 Mökki · " + cot.price + " mk";
  const tw = c.measureText(label).width;
  const bw = tw + 14, by = cot.my + 16 * s;
  c.fillStyle = sel ? "rgba(40,58,82,0.96)" : "rgba(12,22,34,0.86)";
  c.beginPath();
  if (c.roundRect) c.roundRect(cot.mx - bw / 2, by, bw, 19, 6);
  else c.rect(cot.mx - bw / 2, by, bw, 19);
  c.fill();
  if (sel) { c.strokeStyle = "#ffd95e"; c.lineWidth = 1.5; c.stroke(); }
  c.fillStyle = owned ? "#9fe0b0" : "#ffd95e";
  c.textAlign = "center";
  c.textBaseline = "middle";
  c.fillText(label, cot.mx, by + 10);
  c.restore();
}
function drawMapCanvas() {
  if (!mapScene) buildMapScene();
  const c = mapCtx, t = performance.now();

  // --- meri ---
  let g = c.createLinearGradient(0, 0, MAPW, MAPH);
  g.addColorStop(0, "#4a9bc0"); g.addColorStop(0.5, "#256f9c"); g.addColorStop(1, "#0c3a60");
  c.fillStyle = g; c.fillRect(0, 0, MAPW, MAPH);
  c.save();
  c.strokeStyle = "rgba(255,255,255,0.09)"; c.lineWidth = 2;
  for (let i = 0; i < 15; i++) {
    const yy = (i * 44 + (t / 130) % 44);
    c.beginPath();
    for (let x = 0; x <= MAPW; x += 40) {
      const ry = yy + Math.sin(x * 0.02 + i) * 5;
      x ? c.lineTo(x, ry) : c.moveTo(x, ry);
    }
    c.stroke();
  }
  for (const sp of mapScene.sparkle) {
    const a = 0.3 + 0.3 * Math.sin(t / 600 + sp.ph);
    c.fillStyle = `rgba(255,255,255,${a * 0.4})`;
    c.beginPath(); c.arc(sp.x, sp.y, 1.6, 0, Math.PI * 2); c.fill();
  }
  c.restore();

  // --- rantamatalikko + hiekkaranta ---
  c.save();
  c.lineCap = "round"; c.lineJoin = "round";
  c.beginPath();
  c.moveTo(COAST[0].x, COAST[0].y);
  for (let i = 0; i < COAST.length - 1; i++) {
    const a = COAST[i], b = COAST[i + 1];
    c.quadraticCurveTo(a.x, a.y, (a.x + b.x) / 2, (a.y + b.y) / 2);
  }
  c.lineTo(COAST[COAST.length - 1].x, COAST[COAST.length - 1].y);
  c.lineWidth = 52; c.strokeStyle = "rgba(150,222,240,0.55)"; c.stroke();
  c.lineWidth = 24; c.strokeStyle = "#ead7a4"; c.stroke();
  c.restore();

  // --- maa ---
  traceLand(c);
  const lg = c.createRadialGradient(230, 250, 30, 280, 320, 560);
  lg.addColorStop(0, "#9fd178"); lg.addColorStop(0.62, "#74ad55"); lg.addColorStop(1, "#5a9040");
  c.fillStyle = lg; c.fill();

  // maaston laikut
  c.save();
  traceLand(c); c.clip();
  for (const d of mapScene.dapple) {
    c.fillStyle = d.light ? `rgba(255,255,255,${d.a})` : `rgba(20,50,15,${d.a})`;
    c.beginPath(); c.arc(d.x, d.y, d.r, 0, Math.PI * 2); c.fill();
  }
  c.restore();

  // --- joet ---
  for (const r of RIVERS) drawMapRiver(c, r);

  // --- metsät ---
  for (const tr of mapScene.trees) drawMapTree(c, tr.x, tr.y, tr.s, tr.kind);

  // --- vuoret ---
  for (const m of MOUNTAINS) drawMapMountain(c, m);

  // --- järvet ---
  for (const loc of LOCATIONS) if (loc.kind === "lake") drawMapLake(c, loc);

  // --- saaret ---
  for (const is of MAP_ISLANDS) {
    c.fillStyle = "rgba(0,0,0,0.16)";
    c.beginPath(); c.ellipse(is.x + 2, is.y + 3, is.r, is.r * 0.6, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = "#e6d29a";
    c.beginPath(); c.ellipse(is.x, is.y, is.r, is.r * 0.62, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = "#6aa84e";
    c.beginPath(); c.ellipse(is.x, is.y, is.r * 0.66, is.r * 0.4, 0, 0, Math.PI * 2); c.fill();
  }

  // --- koristeet ---
  drawMapLighthouse(c, 566, 250);
  drawMapShip(c, 806, 322, 1.0, t);
  drawMapShip(c, 626, 506, 0.78, t);
  drawMapCompass(c, 916, 506, 52, t);

  // --- kesämökit ---
  for (const cot of COTTAGES) drawMapCottage(c, cot);

  // --- merkit ---
  for (const loc of LOCATIONS) drawMapMarker(c, loc, t);

  // --- reunavinjetti ---
  const vg = c.createRadialGradient(MAPW / 2, MAPH / 2, MAPH * 0.34, MAPW / 2, MAPH / 2, MAPH * 0.82);
  vg.addColorStop(0, "rgba(0,0,0,0)"); vg.addColorStop(1, "rgba(0,0,0,0.34)");
  c.fillStyle = vg; c.fillRect(0, 0, MAPW, MAPH);
}

function mapEventPos(e) {
  const r = mapCanvas.getBoundingClientRect();
  return {
    cx: (e.clientX - r.left) * (MAPW / r.width),
    cy: (e.clientY - r.top) * (MAPH / r.height),
  };
}
function mapHitTest(cx, cy) {
  let best = null, bestD = Infinity;
  for (const loc of LOCATIONS) {
    const dx = cx - loc.mx, dy = cy - loc.my;
    const d = dx * dx + dy * dy;
    if (d < 40 * 40 && d < bestD) { bestD = d; best = loc; }
  }
  // Mökeillä isompi osumaraja — kattaa myös hintakyltin
  for (const cot of COTTAGES) {
    const dx = cx - cot.mx, dy = cy - (cot.my + 10);
    const d = dx * dx + dy * dy;
    if (d < 58 * 58 && d < bestD) { bestD = d; best = cot; }
  }
  return best;
}
mapCanvas.addEventListener("click", (e) => {
  const p = mapEventPos(e);
  const loc = mapHitTest(p.cx, p.cy);
  if (loc) { mapSelection = loc.name; renderMapDetail(); }
});
mapCanvas.addEventListener("mousemove", (e) => {
  const p = mapEventPos(e);
  const loc = mapHitTest(p.cx, p.cy);
  mapHover = loc ? loc.name : null;
  mapCanvas.style.cursor = loc ? "pointer" : "default";
});

function renderCottageDetail(cot) {
  const owned = state.cottages.includes(cot.name);
  const here = state.atCottage === cot.name;
  let btnHtml, action = null;
  if (!owned) {
    if (state.money >= cot.price) {
      btnHtml = `<button class="loc-btn" id="mapActionBtn">Osta mökki · ${cot.price} mk</button>`;
      action = "buy";
    } else {
      btnHtml = `<button class="loc-btn" disabled>Ei rahaa — ${cot.price} mk</button>`;
    }
  } else if (here) {
    btnHtml = `<button class="loc-btn" disabled>Olet mökillä</button>`;
  } else {
    btnHtml = `<button class="loc-btn" id="mapActionBtn">🏡 Mene mökille</button>`;
    action = "go";
  }
  mapDetailEl.innerHTML = `
    <div class="loc-info">
      <div class="loc-title">🏡 ${cot.display}${owned ? "" : " 🔒"}</div>
      <div class="loc-desc">${cot.desc}</div>
      <div class="loc-bonus">${owned ? "Oma kesämökki — käy kävelemässä mökkipihalla." : "Oma kesämökki kartalla."}</div>
    </div>
    ${btnHtml}`;
  const btn = document.getElementById("mapActionBtn");
  if (btn) {
    if (action === "buy") btn.addEventListener("click", () => buyCottage(cot.name));
    else if (action === "go") btn.addEventListener("click", () => goToCottage(cot.name));
  }
}
function buyCottage(name) {
  const cot = COTTAGES.find(c => c.name === name);
  if (!cot || state.cottages.includes(name) || state.money < cot.price) return;
  state.money -= cot.price;
  state.cottages.push(name);
  mapSelection = name;
  updateHUD();
  renderMap();
  sfxCatch();
  autoSave();
}

// =========================================================
// Kesämökki — käveltävä mökkipiha
// =========================================================
function goToCottage(name) {
  if (!state.cottages.includes(name)) return;
  state.atCottage = name;
  state.subMode = false;
  state.placing = null;
  state.line.out = false;
  state.cottagePlayer = { x: W * 0.42, vx: 0, facing: 1, walkPhase: 0 };
  ensureCottage3D();
  if (cottage3D) {
    cottage3D.active = true;
    cottage3D.player.position.set(0, 0, 4);
    cottage3D.player.rotation.y = 0;
    cottage3D.cf = { phase: "idle", t: 0, msg: "🏡 Tervetuloa mökille!", msgLife: 3 };
    cottage3D.bobber.visible = false;
    cottage3D.fishLine.visible = false;
    cottage3D.doorOpening = false;
    cottage3D.doorOpen = 0;
    cottage3D.camYaw = 0;
    cottage3D.camPitch = 0.34;
    cottage3D.atrain.flying = false;
    cottage3D.atrain.reload = 0;
    cottage3D.atrain.spear.visible = false;
    cottage3D.inBoat = false;
    cottage3D.boat.x = COTTAGE_BOAT_DOCK.x;
    cottage3D.boat.z = COTTAGE_BOAT_DOCK.z;
    cottage3D.boat.heading = 0;
    cottage3D.items.vene.position.set(COTTAGE_BOAT_DOCK.x, 0.3, COTTAGE_BOAT_DOCK.z);
    cottage3D.items.vene.rotation.y = 0;
    cottage3D.tool = state.cottageItems.includes("atrain") ? "atrain" : "onki";
    buildCottageWorld(name);
    syncCottageItems();
  }
  syncCottageCanvas();
  updateHUD();
  autoSave();
  toggleMap();
}
function updateCottage(dt) {
  const p = state.cottagePlayer;
  const acc = 850;
  if (state.keys["ArrowLeft"] || state.keys["KeyA"]) p.vx -= acc * dt;
  if (state.keys["ArrowRight"] || state.keys["KeyD"]) p.vx += acc * dt;
  p.vx *= 0.80;
  p.vx = clampv(p.vx, -210, 210);
  p.x += p.vx * dt;
  p.x = clampv(p.x, 46, W - 56);
  if (Math.abs(p.vx) > 14) { p.facing = p.vx > 0 ? 1 : -1; p.walkPhase += dt * 11; }
  else p.walkPhase = 0;
  for (const ft of floatTexts) { ft.y -= 30 * dt; ft.life -= dt; }
  while (floatTexts.length && floatTexts[0].life <= 0) floatTexts.shift();
  updateHUD();
}
function drawCottageTree(c, x, baseY, s) {
  c.fillStyle = "rgba(0,0,0,0.16)";
  c.beginPath(); c.ellipse(x, baseY + 2, 22 * s, 7 * s, 0, 0, Math.PI * 2); c.fill();
  c.fillStyle = "#5a3f28";
  c.fillRect(x - 5 * s, baseY - 26 * s, 10 * s, 28 * s);
  const cols = ["#2f6b30", "#3a7d3a", "#48924a"];
  for (let i = 0; i < 3; i++) {
    const ty = baseY - 18 * s - i * 22 * s;
    const tw = (40 - i * 9) * s;
    c.fillStyle = cols[i];
    c.beginPath();
    c.moveTo(x, ty - 34 * s);
    c.lineTo(x - tw, ty);
    c.lineTo(x + tw, ty);
    c.closePath(); c.fill();
  }
}
function drawCottageCabin(c, x, baseY, s) {
  const w = 200 * s, wallH = 96 * s, t = performance.now();
  c.fillStyle = "rgba(0,0,0,0.18)";
  c.beginPath(); c.ellipse(x, baseY + 6, w * 0.62, 16 * s, 0, 0, Math.PI * 2); c.fill();
  // hirsiseinä
  c.fillStyle = "#9a6a3c";
  c.fillRect(x - w / 2, baseY - wallH, w, wallH);
  c.strokeStyle = "rgba(90,55,25,0.5)";
  c.lineWidth = 2;
  for (let yy = baseY - wallH + 14 * s; yy < baseY; yy += 14 * s) {
    c.beginPath(); c.moveTo(x - w / 2, yy); c.lineTo(x + w / 2, yy); c.stroke();
  }
  // katto
  c.fillStyle = "#7a3528";
  c.beginPath();
  c.moveTo(x - w / 2 - 16 * s, baseY - wallH);
  c.lineTo(x, baseY - wallH - 74 * s);
  c.lineTo(x + w / 2 + 16 * s, baseY - wallH);
  c.closePath(); c.fill();
  // piippu + savu
  c.fillStyle = "#6a6258";
  c.fillRect(x + w * 0.2, baseY - wallH - 64 * s, 18 * s, 40 * s);
  c.fillStyle = "rgba(220,222,228,0.55)";
  for (let i = 0; i < 3; i++) {
    const sy = baseY - wallH - 70 * s - i * 22 * s - ((t / 55) % 22);
    c.beginPath();
    c.arc(x + w * 0.2 + 9 * s + Math.sin(t / 400 + i) * 6, sy, (5 + i * 2) * s, 0, Math.PI * 2);
    c.fill();
  }
  // ovi
  c.fillStyle = "#5a3a22";
  c.fillRect(x - 22 * s, baseY - 56 * s, 44 * s, 56 * s);
  c.fillStyle = "#ffd95e";
  c.beginPath(); c.arc(x + 12 * s, baseY - 28 * s, 3.5 * s, 0, Math.PI * 2); c.fill();
  // ikkuna
  const wx = x - w / 2 + 24 * s, wy = baseY - wallH + 32 * s, ww = 40 * s;
  c.fillStyle = "#bfe6f5";
  c.fillRect(wx, wy, ww, ww);
  c.strokeStyle = "#5a3a22"; c.lineWidth = 3 * s;
  c.strokeRect(wx, wy, ww, ww);
  c.beginPath();
  c.moveTo(wx + ww / 2, wy); c.lineTo(wx + ww / 2, wy + ww);
  c.moveTo(wx, wy + ww / 2); c.lineTo(wx + ww, wy + ww / 2);
  c.stroke();
}
function drawCottagePlayer(c, x, feetY, facing, phase) {
  c.save();
  c.translate(x, feetY);
  c.fillStyle = "rgba(0,0,0,0.22)";
  c.beginPath(); c.ellipse(0, 2, 16, 5, 0, 0, Math.PI * 2); c.fill();
  c.scale(facing, 1);
  const sw = Math.sin(phase) * 7;
  c.lineCap = "round";
  // jalat
  c.strokeStyle = "#2c3e5c"; c.lineWidth = 6;
  c.beginPath(); c.moveTo(-3, -22); c.lineTo(-3 + sw, -1); c.stroke();
  c.beginPath(); c.moveTo(3, -22); c.lineTo(3 - sw, -1); c.stroke();
  // vartalo
  c.fillStyle = "#d8643a";
  c.beginPath();
  if (c.roundRect) c.roundRect(-9, -48, 18, 28, 5);
  else c.rect(-9, -48, 18, 28);
  c.fill();
  // kädet
  c.strokeStyle = "#d8643a"; c.lineWidth = 5;
  c.beginPath(); c.moveTo(-7, -44); c.lineTo(-12 - sw * 0.5, -28); c.stroke();
  c.beginPath(); c.moveTo(7, -44); c.lineTo(12 + sw * 0.5, -28); c.stroke();
  // pää
  c.fillStyle = "#f0c89a";
  c.beginPath(); c.arc(0, -58, 11, 0, Math.PI * 2); c.fill();
  // hattu
  c.fillStyle = "#3a6e3a";
  c.beginPath(); c.arc(0, -61, 12, Math.PI, 0); c.fill();
  c.fillRect(-15, -61, 30, 4);
  // silmä
  c.fillStyle = "#222";
  c.beginPath(); c.arc(5, -58, 1.9, 0, Math.PI * 2); c.fill();
  c.restore();
}
function renderCottage() {
  const c = ctx, n = nightAmount(), t = performance.now();
  const groundY = 410;
  // taivas
  const sky = c.createLinearGradient(0, 0, 0, 300);
  sky.addColorStop(0, lerpColor("#86cdee", "#0a1838", n));
  sky.addColorStop(1, lerpColor("#cfe9f2", "#2a4068", n));
  c.fillStyle = sky;
  c.fillRect(0, 0, W, 300);
  if (n > 0.15) {
    c.fillStyle = `rgba(255,255,240,${(n - 0.15) * 1.1})`;
    for (const sp of STAR_POS) {
      c.beginPath(); c.arc(sp[0], sp[1] * 0.6, 1.4, 0, Math.PI * 2); c.fill();
    }
  }
  if (n < 0.55) { c.fillStyle = "#fff3c0"; c.beginPath(); c.arc(W - 130, 70, 38, 0, Math.PI * 2); c.fill(); }
  else { c.fillStyle = "#eef0d8"; c.beginPath(); c.arc(W - 130, 66, 30, 0, Math.PI * 2); c.fill(); }
  // kaukainen metsä
  c.fillStyle = lerpColor("#3f7a48", "#16263a", n);
  for (let x = -20; x < W + 40; x += 56) {
    c.beginPath();
    c.moveTo(x, 302); c.lineTo(x + 28, 232); c.lineTo(x + 56, 302);
    c.closePath(); c.fill();
  }
  // nurmi
  c.fillStyle = lerpColor("#74b94e", "#1f3520", n * 0.85);
  c.fillRect(0, 282, W, H - 282);
  // järvi (oikea alakulma)
  c.fillStyle = lerpColor("#3f93bf", "#0a2238", n * 0.8);
  c.beginPath();
  c.moveTo(W, 360);
  c.lineTo(W, H);
  c.lineTo(360, H);
  c.quadraticCurveTo(470, groundY + 30, 560, groundY + 8);
  c.quadraticCurveTo(700, groundY - 8, W, 360);
  c.closePath();
  c.fill();
  c.strokeStyle = lerpColor("#e6d6a0", "#3a4a5a", n);
  c.lineWidth = 5;
  c.beginPath();
  c.moveTo(360, H);
  c.quadraticCurveTo(470, groundY + 30, 560, groundY + 8);
  c.quadraticCurveTo(700, groundY - 8, W, 360);
  c.stroke();
  // veden kimallus
  c.strokeStyle = "rgba(255,255,255,0.22)";
  c.lineWidth = 2;
  for (let i = 0; i < 5; i++) {
    const yy = groundY + 44 + i * 32;
    if (yy > H - 6) break;
    c.beginPath();
    let started = false;
    for (let x = 430 + i * 18; x < W; x += 30) {
      const ry = yy + Math.sin(x * 0.05 + t / 600 + i) * 3;
      if (!started) { c.moveTo(x, ry); started = true; } else c.lineTo(x, ry);
    }
    c.stroke();
  }
  // puut
  drawCottageTree(c, 70, groundY - 6, 1.05);
  drawCottageTree(c, 472, groundY - 28, 0.78);
  drawCottageTree(c, 552, 322, 0.66);
  // mökki
  drawCottageCabin(c, 250, groundY, 1);
  // laituri
  c.fillStyle = "#8a5a32";
  for (let i = 0; i < 9; i++) c.fillRect(560 + i * 30, groundY - 6, 26, 12);
  c.fillStyle = "#6a4424";
  c.fillRect(560, groundY - 9, 270, 4);
  c.fillStyle = "#5a3a22";
  for (const px of [596, 686, 800]) c.fillRect(px, groundY + 8, 9, 52);
  // pelaaja
  const p = state.cottagePlayer;
  drawCottagePlayer(c, p.x, groundY, p.facing, p.walkPhase);
  // vihje
  c.fillStyle = "rgba(0,0,0,0.5)";
  c.fillRect(W / 2 - 210, H - 36, 420, 26);
  c.fillStyle = "#fff";
  c.font = "bold 14px Segoe UI, sans-serif";
  c.textAlign = "center"; c.textBaseline = "middle";
  c.fillText("◀ ▶ kävele · M = kartta · K = kauppa", W / 2, H - 23);
  // yleiskerrokset
  drawNightTint();
  drawSeasonTint();
  drawFloatTexts();
  drawTimePanel();
  drawPauseOverlay();
}

// =========================================================
// Kesämökki 3D (Three.js) — laiturilta ongitaan madoilla
// =========================================================
const cottage3dEl = document.getElementById("cottage3d");
const cottageHudEl = document.getElementById("cottageHud");
const cottageTimePanelEl = document.getElementById("cottageTimePanel");
const WORM_FISH = ["small", "muikku", "silakka", "sardiini", "med", "sayne", "siika", "lahna"]
  .map(n => FISH_TYPES.find(t => t.name === n)).filter(Boolean);
let cottage3D = null;
let capsOn = false;

function c3dBox(w, h, d, color) {
  return new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshLambertMaterial({ color }));
}
function makeCabin3D() {
  const g = new THREE.Group();
  const walls = c3dBox(10, 6, 8, 0x9a6a3c);
  walls.position.y = 3; walls.castShadow = true; walls.receiveShadow = true;
  g.add(walls);
  // hirsiraidat
  for (let y = 0.6; y < 6; y += 1.1) {
    const log = c3dBox(10.1, 0.18, 8.1, 0x6f4a26);
    log.position.y = y;
    g.add(log);
  }
  const roof = new THREE.Mesh(new THREE.ConeGeometry(8.7, 4.8, 4),
    new THREE.MeshLambertMaterial({ color: 0x7a3528 }));
  roof.position.y = 8.4; roof.rotation.y = Math.PI / 4; roof.castShadow = true;
  g.add(roof);
  const frame = c3dBox(2.8, 4.1, 0.5, 0x4a2e18);
  frame.position.set(0, 2.05, 4.0);
  g.add(frame);
  // ovi — sarana vasemmassa reunassa
  const doorPivot = new THREE.Group();
  doorPivot.position.set(-1.1, 2.05, 4.18);
  const door = c3dBox(2.2, 3.6, 0.22, 0x7a4a26);
  door.position.set(1.1, 0, 0); door.castShadow = true;
  doorPivot.add(door);
  const knob = new THREE.Mesh(new THREE.SphereGeometry(0.17, 8, 6),
    new THREE.MeshLambertMaterial({ color: 0xffd95e }));
  knob.position.set(1.95, 0, 0.18);
  doorPivot.add(knob);
  g.add(doorPivot);
  for (const wx of [-3.4, 3.4]) {
    const win = c3dBox(2, 2, 0.3, 0xbfe6f5);
    win.position.set(wx, 3.7, 4.06);
    g.add(win);
    const sill = c3dBox(2.3, 0.3, 0.4, 0x4a2e18);
    sill.position.set(wx, 2.6, 4.1);
    g.add(sill);
  }
  const chim = c3dBox(1.3, 3.2, 1.3, 0x6a6258);
  chim.position.set(2.6, 9.2, 0); chim.castShadow = true;
  g.add(chim);
  g.userData.doorPivot = doorPivot;
  return g;
}
function makeRock3D(s) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(s, 6, 5),
    new THREE.MeshLambertMaterial({ color: 0x8a8d92, flatShading: true }));
  m.scale.y = 0.6; m.position.y = s * 0.4;
  m.castShadow = true;
  return m;
}
function makeBush3D() {
  const g = new THREE.Group();
  for (let i = 0; i < 3; i++) {
    const b = new THREE.Mesh(new THREE.SphereGeometry(1 + Math.random() * 0.6, 7, 6),
      new THREE.MeshLambertMaterial({ color: 0x3f8a3a }));
    b.position.set((Math.random() - 0.5) * 2, 0.9, (Math.random() - 0.5) * 2);
    b.castShadow = true;
    g.add(b);
  }
  return g;
}
function makeTree3D(pal) {
  pal = pal || { trunk: 0x5a3f28, cones: [0x2f6b30, 0x3a7d3a, 0x48924a] };
  const g = new THREE.Group();
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.75, 3, 6),
    new THREE.MeshLambertMaterial({ color: pal.trunk }));
  trunk.position.y = 1.5; g.add(trunk);
  for (let i = 0; i < 3; i++) {
    const cone = new THREE.Mesh(new THREE.ConeGeometry(2.7 - i * 0.6, 2.7, 7),
      new THREE.MeshLambertMaterial({ color: pal.cones[i] }));
    cone.position.y = 3.2 + i * 1.8; g.add(cone);
  }
  return g;
}
function makePlayer3D() {
  const g = new THREE.Group();
  const body = new THREE.Group();
  // jalat — saranoitu lonkasta (voi istua)
  const legs = [];
  for (const sx of [-0.5, 0.5]) {
    const hip = new THREE.Group();
    hip.position.set(sx, 2, 0);
    const leg = c3dBox(0.8, 2, 0.8, 0x2c3e5c);
    leg.position.set(0, -1, 0); leg.castShadow = true;
    hip.add(leg);
    const shoe = c3dBox(0.9, 0.5, 1.2, 0x3a2614);
    shoe.position.set(0, -1.75, 0.2); shoe.castShadow = true;
    hip.add(shoe);
    body.add(hip);
    legs.push(hip);
  }
  const torso = c3dBox(2.2, 2.4, 1.3, 0xd8643a); torso.position.y = 3.2; body.add(torso);
  const armL = c3dBox(0.55, 2, 0.6, 0xc85a32); armL.position.set(-1.45, 3.3, 0); body.add(armL);
  const armR = c3dBox(0.55, 2, 0.6, 0xc85a32); armR.position.set(1.45, 3.3, 0); body.add(armR);
  // pää
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.9, 16, 14),
    new THREE.MeshLambertMaterial({ color: 0xf0c89a }));
  head.position.y = 5; body.add(head);
  // hiukset
  const hair = new THREE.Mesh(new THREE.SphereGeometry(0.93, 14, 12),
    new THREE.MeshLambertMaterial({ color: 0x5a3a1c }));
  hair.position.set(0, 5.2, -0.18); hair.scale.set(1, 0.92, 1);
  body.add(hair);
  // hattu
  const brim = new THREE.Mesh(new THREE.CylinderGeometry(1.32, 1.32, 0.16, 16),
    new THREE.MeshLambertMaterial({ color: 0x356135 }));
  brim.position.y = 5.52; body.add(brim);
  const hat = new THREE.Mesh(new THREE.ConeGeometry(1.0, 1.2, 14),
    new THREE.MeshLambertMaterial({ color: 0x3a6e3a }));
  hat.position.y = 6.15; body.add(hat);
  // silmät
  for (const ex of [-0.32, 0.32]) {
    const white = new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 8),
      new THREE.MeshLambertMaterial({ color: 0xffffff }));
    white.position.set(ex, 5.12, 0.72); body.add(white);
    const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 6),
      new THREE.MeshLambertMaterial({ color: 0x1a1a22 }));
    pupil.position.set(ex, 5.12, 0.87); body.add(pupil);
  }
  // nenä
  const nose = new THREE.Mesh(new THREE.SphereGeometry(0.15, 8, 6),
    new THREE.MeshLambertMaterial({ color: 0xe6b488 }));
  nose.position.set(0, 4.86, 0.9); body.add(nose);
  // suu
  const mouth = c3dBox(0.52, 0.14, 0.12, 0x8a3a2a);
  mouth.position.set(0, 4.6, 0.83); body.add(mouth);
  // onki
  const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.13, 8, 6),
    new THREE.MeshLambertMaterial({ color: 0x6a4a28 }));
  rod.position.set(1.5, 5.1, 0.4);
  rod.rotation.x = 0.7;
  body.add(rod);
  const rodTip = new THREE.Object3D();
  rodTip.position.set(0, 4.15, 0);
  rod.add(rodTip);
  // atrain kädessä (näkyy kun atrain ostettu)
  const heldAtrain = new THREE.Group();
  const haShaft = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.12, 5.4, 7),
    new THREE.MeshLambertMaterial({ color: 0x7a5630 }));
  haShaft.castShadow = true;
  heldAtrain.add(haShaft);
  const haBand = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 0.3, 8),
    new THREE.MeshLambertMaterial({ color: 0x2a2c2e }));
  haBand.position.y = 2.3; heldAtrain.add(haBand);
  const haSteel = new THREE.MeshLambertMaterial({ color: 0xc8d0d8 });
  for (const off of [-0.22, 0, 0.22]) {
    const prong = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.7, 5), haSteel);
    prong.position.set(off, 3.05, 0); prong.castShadow = true;
    heldAtrain.add(prong);
  }
  const atrainTip = new THREE.Object3D();
  atrainTip.position.set(0, 3.2, 0);
  heldAtrain.add(atrainTip);
  heldAtrain.position.set(1.7, 3.0, 0.55);
  heldAtrain.rotation.x = 0.5;
  heldAtrain.visible = false;
  body.add(heldAtrain);
  g.add(body);
  g.userData.body = body;
  g.userData.rodTip = rodTip;
  g.userData.rod = rod;
  g.userData.heldAtrain = heldAtrain;
  g.userData.atrainTip = atrainTip;
  g.userData.legs = legs;
  return g;
}
function makeBoat3D() {
  const g = new THREE.Group();
  const RED = 0xb23b2a, CREAM = 0xede3c8, WOOD = 0x8a5a30, DARK = 0x5a3a1c;
  // köli
  const keel = c3dBox(0.5, 0.4, 6.2, DARK); keel.position.y = 0.2; g.add(keel);
  // runko keskiosa
  const hull = c3dBox(2.9, 1.25, 5.0, RED); hull.position.y = 0.95; g.add(hull);
  // keula — terävä kärki vesille (-Z)
  const bow = new THREE.Mesh(new THREE.ConeGeometry(1.55, 2.6, 4),
    new THREE.MeshLambertMaterial({ color: RED }));
  bow.rotation.x = -Math.PI / 2;
  bow.position.set(0, 0.95, -3.35);
  bow.scale.set(1.05, 1, 0.55);
  g.add(bow);
  // perä — peräpeili
  const stern = c3dBox(2.55, 1.25, 0.55, RED); stern.position.set(0, 0.95, 2.55); g.add(stern);
  // partaan kermaraidat
  for (const sx of [-1.46, 1.46]) {
    const rail = c3dBox(0.24, 0.36, 5.7, CREAM);
    rail.position.set(sx, 1.58, 0); g.add(rail);
  }
  const railF = c3dBox(2.9, 0.36, 0.24, CREAM); railF.position.set(0, 1.58, -2.7); g.add(railF);
  const railB = c3dBox(2.9, 0.36, 0.24, CREAM); railB.position.set(0, 1.58, 2.7); g.add(railB);
  // sisälattia
  const floor = c3dBox(2.3, 0.22, 5.0, WOOD); floor.position.y = 1.42; g.add(floor);
  // penkit (tuhdot)
  for (const z of [-1.5, 0.3, 1.9]) {
    const seat = c3dBox(2.35, 0.22, 0.72, WOOD);
    seat.position.set(0, 1.7, z); g.add(seat);
  }
  // hankaintapit
  for (const sx of [-1.46, 1.46]) {
    const lock = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.42, 6),
      new THREE.MeshLambertMaterial({ color: 0x33363a }));
    lock.position.set(sx, 1.85, -0.3); g.add(lock);
  }
  // airot pitkin venettä
  for (const side of [-1, 1]) {
    const oar = new THREE.Group();
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 4.6, 6),
      new THREE.MeshLambertMaterial({ color: WOOD }));
    shaft.rotation.z = Math.PI / 2; oar.add(shaft);
    const blade = c3dBox(0.1, 0.58, 1.15, WOOD);
    blade.position.x = side * 2.5; oar.add(blade);
    oar.position.set(side * 0.15, 1.96, -0.3);
    oar.rotation.y = side * 0.46;
    g.add(oar);
  }
  // köysikiekko keulaan
  const rope = new THREE.Mesh(new THREE.TorusGeometry(0.46, 0.13, 6, 14),
    new THREE.MeshLambertMaterial({ color: 0xc9a063 }));
  rope.rotation.x = Math.PI / 2; rope.position.set(0, 1.55, -2.25); g.add(rope);
  g.traverse(o => { if (o.isMesh) o.castShadow = true; });
  return g;
}
function makeAtrain3D() {
  const g = new THREE.Group();
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.17, 7, 8),
    new THREE.MeshLambertMaterial({ color: 0x7a5630 }));
  shaft.position.y = 3.5; g.add(shaft);
  const steel = new THREE.MeshLambertMaterial({ color: 0xb8c0c8 });
  for (let i = 0; i < 4; i++) {
    const a = (i - 1.5) * 0.34;
    const prong = new THREE.Mesh(new THREE.ConeGeometry(0.1, 1.7, 5), steel);
    prong.position.set(Math.sin(a) * 0.55, 7.7, 0);
    prong.rotation.z = -a;
    g.add(prong);
    const barb = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.4, 4), steel);
    barb.position.set(Math.sin(a) * 0.55, 7.3, 0.16);
    barb.rotation.x = 2.2;
    g.add(barb);
  }
  const band = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.5, 8),
    new THREE.MeshLambertMaterial({ color: 0x2a2c2e }));
  band.position.y = 6.85; g.add(band);
  g.traverse(o => { if (o.isMesh) o.castShadow = true; });
  return g;
}
function makeGrill3D() {
  const g = new THREE.Group();
  const bowl = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 0.7, 0.9, 12),
    new THREE.MeshLambertMaterial({ color: 0x33363a }));
  bowl.position.y = 2.2; g.add(bowl);
  for (let i = 0; i < 3; i++) {
    const a = i / 3 * Math.PI * 2;
    const leg = c3dBox(0.18, 2.2, 0.18, 0x2a2c2e);
    leg.position.set(Math.cos(a) * 0.7, 1.1, Math.sin(a) * 0.7);
    g.add(leg);
  }
  g.traverse(o => { if (o.isMesh) o.castShadow = true; });
  return g;
}
function makeFlowers3D() {
  const g = new THREE.Group();
  const cols = [0xff5b7a, 0xffd23f, 0xff8a3d, 0xc77dff, 0xffffff];
  for (let i = 0; i < 16; i++) {
    const fx = (i % 8) * 1.5 - 5.2, fz = (i < 8 ? 0 : 1.6);
    const stem = c3dBox(0.1, 0.9, 0.1, 0x3a7d3a);
    stem.position.set(fx, 0.45, fz); g.add(stem);
    const bloom = new THREE.Mesh(new THREE.SphereGeometry(0.32, 7, 6),
      new THREE.MeshLambertMaterial({ color: cols[i % cols.length] }));
    bloom.position.set(fx, 1.05, fz); g.add(bloom);
  }
  return g;
}
function makeSauna3D() {
  const g = new THREE.Group();
  const walls = c3dBox(6, 4, 5, 0x6f4a28);
  walls.position.y = 2; walls.castShadow = true; walls.receiveShadow = true;
  g.add(walls);
  const roof = new THREE.Mesh(new THREE.ConeGeometry(5, 2.6, 4),
    new THREE.MeshLambertMaterial({ color: 0x4a3520 }));
  roof.position.y = 5.3; roof.rotation.y = Math.PI / 4; roof.castShadow = true;
  g.add(roof);
  const door = c3dBox(1.4, 2.4, 0.3, 0x3a2614);
  door.position.set(0, 1.2, 2.6); g.add(door);
  return g;
}
function makeLamps3D() {
  const g = new THREE.Group();
  for (const p of [[-9, 30], [-3, 14], [5, 26]]) {
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.22, 4.6, 6),
      new THREE.MeshLambertMaterial({ color: 0x33363a }));
    post.position.set(p[0], 2.3, p[1]); post.castShadow = true; g.add(post);
    const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.5, 8, 7),
      new THREE.MeshBasicMaterial({ color: 0xffe89a }));
    bulb.position.set(p[0], 4.8, p[1]); g.add(bulb);
  }
  return g;
}
// --- A-mökki (metsämökki) — jyrkkä kolmiorunko ---
function makeCabinAframe3D() {
  const g = new THREE.Group();
  const shape = new THREE.Shape();
  shape.moveTo(-5.7, 0); shape.lineTo(5.7, 0); shape.lineTo(0, 9); shape.lineTo(-5.7, 0);
  const geo = new THREE.ExtrudeGeometry(shape, { depth: 9, bevelEnabled: false });
  geo.translate(0, 0, -4.5);
  const gableMat = new THREE.MeshLambertMaterial({ color: 0x4a3420 });
  const roofMat = new THREE.MeshLambertMaterial({ color: 0x2c3b24 });
  const body = new THREE.Mesh(geo, [gableMat, roofMat]);
  body.castShadow = true; body.receiveShadow = true;
  g.add(body);
  // lankkuraidat etupäätyyn
  for (let y = 0.7; y < 8; y += 1.2) {
    const w = 11.4 * (1 - y / 9);
    const plank = c3dBox(w, 0.22, 0.12, 0x3a2916);
    plank.position.set(0, y, 4.52);
    g.add(plank);
  }
  // ovi
  const doorPivot = new THREE.Group();
  doorPivot.position.set(-1.0, 1.6, 4.62);
  const door = c3dBox(2.0, 3.0, 0.2, 0x6a4a26);
  door.position.set(1.0, 0, 0); door.castShadow = true;
  doorPivot.add(door);
  const knob = new THREE.Mesh(new THREE.SphereGeometry(0.15, 8, 6),
    new THREE.MeshLambertMaterial({ color: 0xffd95e }));
  knob.position.set(1.8, 0, 0.16); doorPivot.add(knob);
  g.add(doorPivot);
  // pyöreä ikkuna päädyssä
  const win = new THREE.Mesh(new THREE.CircleGeometry(0.85, 16),
    new THREE.MeshLambertMaterial({ color: 0xbfe6f5 }));
  win.position.set(0, 5.6, 4.53); g.add(win);
  // kiviporras
  const step = c3dBox(2.6, 0.5, 1.2, 0x7d7d7d);
  step.position.set(0, 0.25, 5.4); g.add(step);
  // savupiippu
  const chim = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.5, 2.6, 8),
    new THREE.MeshLambertMaterial({ color: 0x3a3a3a }));
  chim.position.set(1.6, 8.4, -0.5); chim.castShadow = true; g.add(chim);
  g.userData.doorPivot = doorPivot;
  return g;
}
// --- Rantamökki — vaalea matala huvila terassilla ---
function makeCabinBeach3D() {
  const g = new THREE.Group();
  const found = c3dBox(12, 0.6, 9, 0xcdb98a);
  found.position.y = 0.3; found.receiveShadow = true; g.add(found);
  const walls = c3dBox(9.4, 4.2, 7, 0xede0c0);
  walls.position.y = 2.7; walls.castShadow = true; walls.receiveShadow = true; g.add(walls);
  // litteä leveä katto
  const roof = c3dBox(13, 0.5, 10, 0x4f8aa0);
  roof.position.y = 5.05; roof.castShadow = true; g.add(roof);
  const roof2 = c3dBox(10.4, 0.4, 7.6, 0x3f7488);
  roof2.position.y = 5.45; g.add(roof2);
  // isot ikkunat etuseinään
  for (const wx of [-3.1, 3.1]) {
    const win = c3dBox(2.6, 2.4, 0.25, 0x9fe2ef);
    win.position.set(wx, 3.2, 3.55); g.add(win);
    const frame = c3dBox(2.9, 2.7, 0.12, 0xffffff);
    frame.position.set(wx, 3.2, 3.49); g.add(frame);
  }
  // sivuikkunat
  for (const sz of [-1.8, 1.8]) {
    const win = c3dBox(0.25, 2, 2, 0x9fe2ef);
    win.position.set(4.75, 3.1, sz); g.add(win);
  }
  // ovi
  const doorPivot = new THREE.Group();
  doorPivot.position.set(-1.0, 2.3, 3.6);
  const door = c3dBox(2.0, 3.2, 0.22, 0x5f87a0);
  door.position.set(1.0, 0, 0); door.castShadow = true; doorPivot.add(door);
  const knob = new THREE.Mesh(new THREE.SphereGeometry(0.15, 8, 6),
    new THREE.MeshLambertMaterial({ color: 0xf2f2f2 }));
  knob.position.set(1.8, 0, 0.16); doorPivot.add(knob);
  g.add(doorPivot);
  // terassi + kaide
  const porch = c3dBox(9, 0.4, 2, 0xc8a878);
  porch.position.set(0, 0.7, 5.4); porch.receiveShadow = true; g.add(porch);
  for (const rx of [-4.2, 4.2]) {
    const rail = c3dBox(0.2, 1, 2.2, 0xe8dcc0);
    rail.position.set(rx, 1.3, 5.4); g.add(rail);
  }
  const railTop = c3dBox(8.8, 0.18, 0.18, 0xe8dcc0);
  railTop.position.set(0, 1.75, 6.3); g.add(railTop);
  for (let rx = -4; rx <= 4; rx += 1) {
    const sp = c3dBox(0.12, 1, 0.12, 0xe8dcc0);
    sp.position.set(rx, 1.2, 6.3); g.add(sp);
  }
  g.userData.doorPivot = doorPivot;
  return g;
}
function makePalm3D() {
  const g = new THREE.Group();
  const h = 7.2 + Math.random() * 2.2;
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.66, h, 8),
    new THREE.MeshLambertMaterial({ color: 0xa9824c }));
  trunk.position.y = h / 2; trunk.castShadow = true; g.add(trunk);
  const frondMat = new THREE.MeshLambertMaterial({ color: 0x3f9d4a });
  for (let i = 0; i < 7; i++) {
    const a = i / 7 * Math.PI * 2;
    const frond = new THREE.Mesh(new THREE.ConeGeometry(0.6, 4.4, 5), frondMat);
    frond.position.set(Math.cos(a) * 1.7, h + 0.1, Math.sin(a) * 1.7);
    frond.rotation.z = Math.cos(a) * 1.05;
    frond.rotation.x = -Math.sin(a) * 1.05;
    frond.castShadow = true; g.add(frond);
  }
  for (let i = 0; i < 3; i++) {
    const a = i / 3 * Math.PI * 2;
    const co = new THREE.Mesh(new THREE.SphereGeometry(0.42, 7, 6),
      new THREE.MeshLambertMaterial({ color: 0x5a3f24 }));
    co.position.set(Math.cos(a) * 0.6, h - 0.5, Math.sin(a) * 0.6); g.add(co);
  }
  return g;
}
function makeMushroom3D() {
  const g = new THREE.Group();
  const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.24, 0.8, 7),
    new THREE.MeshLambertMaterial({ color: 0xede0c8 }));
  stem.position.y = 0.4; stem.castShadow = true; g.add(stem);
  const cap = new THREE.Mesh(new THREE.SphereGeometry(0.5, 10, 8, 0, Math.PI * 2, 0, Math.PI / 2),
    new THREE.MeshLambertMaterial({ color: 0xb83a2c }));
  cap.position.y = 0.78; cap.castShadow = true; g.add(cap);
  return g;
}
function makeFallenLog3D() {
  const g = new THREE.Group();
  const log = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.78, 6, 9),
    new THREE.MeshLambertMaterial({ color: 0x4a3622 }));
  log.rotation.z = Math.PI / 2; log.position.y = 0.7; log.castShadow = true; g.add(log);
  const moss = new THREE.Mesh(new THREE.BoxGeometry(5.2, 0.3, 1.1),
    new THREE.MeshLambertMaterial({ color: 0x4d7c3a }));
  moss.position.y = 1.32; g.add(moss);
  return g;
}
function makeUmbrella3D() {
  const g = new THREE.Group();
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 5.2, 7),
    new THREE.MeshLambertMaterial({ color: 0xd8d8d8 }));
  pole.position.y = 2.6; pole.castShadow = true; g.add(pole);
  const top = new THREE.Mesh(new THREE.ConeGeometry(3.5, 1.8, 12),
    new THREE.MeshLambertMaterial({ color: 0xff6b6b }));
  top.position.y = 5.1; top.castShadow = true; g.add(top);
  return g;
}
function makeLounger3D() {
  const g = new THREE.Group();
  const mat = new THREE.MeshLambertMaterial({ color: 0xf4f4f4 });
  const seat = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.25, 4), mat);
  seat.position.y = 0.8; seat.castShadow = true; g.add(seat);
  const back = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.25, 2), mat);
  back.position.set(0, 1.35, -1.6); back.rotation.x = -0.6; g.add(back);
  for (const sx of [-0.7, 0.7]) for (const sz of [-1.7, 1.7]) {
    const leg = c3dBox(0.18, 0.8, 0.18, 0xcfcfcf);
    leg.position.set(sx, 0.4, sz); g.add(leg);
  }
  return g;
}
function makeShell3D() {
  const cols = [0xffe2c4, 0xf4c9d4, 0xfff0d0, 0xe8d2b8];
  const m = new THREE.Mesh(new THREE.SphereGeometry(0.4, 9, 6, 0, Math.PI * 2, 0, Math.PI / 2),
    new THREE.MeshLambertMaterial({ color: cols[(Math.random() * cols.length) | 0] }));
  m.position.y = 0.04; m.scale.set(1, 0.5, 1);
  return m;
}
function makeCottageFish3D(color) {
  const g = new THREE.Group();
  const mat = new THREE.MeshLambertMaterial({ color });
  const body = new THREE.Mesh(new THREE.SphereGeometry(0.9, 12, 10), mat);
  body.scale.set(1.7, 0.85, 0.7);
  g.add(body);
  const belly = new THREE.Mesh(new THREE.SphereGeometry(0.78, 10, 8),
    new THREE.MeshLambertMaterial({ color: 0xeae6d8 }));
  belly.scale.set(1.5, 0.4, 0.55); belly.position.y = -0.34;
  g.add(belly);
  const tail = new THREE.Mesh(new THREE.ConeGeometry(0.62, 1.1, 4), mat);
  tail.rotation.z = -Math.PI / 2; tail.position.x = -1.7;
  tail.scale.set(1, 1, 0.35);
  g.add(tail);
  const fin = new THREE.Mesh(new THREE.ConeGeometry(0.4, 0.8, 3), mat);
  fin.position.set(0, 0.6, 0); fin.scale.set(1, 1, 0.3);
  g.add(fin);
  for (const ez of [0.42, -0.42]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 6),
      new THREE.MeshLambertMaterial({ color: 0x141414 }));
    eye.position.set(1.0, 0.22, ez);
    g.add(eye);
  }
  g.traverse(o => { if (o.isMesh) o.castShadow = true; });
  return g;
}
function makeThrownSpear3D() {
  // kärki osoittaa kohti -Z (lookAt-yhteensopiva)
  const g = new THREE.Group();
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, 2.6, 7),
    new THREE.MeshLambertMaterial({ color: 0x7a5630 }));
  shaft.rotation.x = Math.PI / 2;
  g.add(shaft);
  const band = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.3, 8),
    new THREE.MeshLambertMaterial({ color: 0x2a2c2e }));
  band.rotation.x = Math.PI / 2; band.position.z = -1.0;
  g.add(band);
  const steel = new THREE.MeshLambertMaterial({ color: 0xc8d0d8 });
  for (const off of [-0.24, 0, 0.24]) {
    const prong = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.8, 5), steel);
    prong.rotation.x = Math.PI / 2;
    prong.position.set(off, 0, -1.7);
    g.add(prong);
  }
  g.traverse(o => { if (o.isMesh) o.castShadow = true; });
  return g;
}
function ensureCottage3D() {
  if (cottage3D || typeof THREE === "undefined" || !cottage3dEl) return;
  try {
  const cv = cottage3dEl;
  const renderer = new THREE.WebGLRenderer({ canvas: cv, antialias: true });
  renderer.setSize(cv.width, cv.height, false);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x8fd0ee);
  scene.fog = new THREE.Fog(0x8fd0ee, 65, 210);
  const camera = new THREE.PerspectiveCamera(58, cv.width / cv.height, 0.1, 450);

  scene.add(new THREE.AmbientLight(0xffffff, 0.52));
  scene.add(new THREE.HemisphereLight(0xbfe4ff, 0x4a6a3a, 0.5));
  const sun = new THREE.DirectionalLight(0xfff2d8, 0.95);
  sun.position.set(34, 58, 28);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  sun.shadow.camera.left = -75; sun.shadow.camera.right = 75;
  sun.shadow.camera.top = 75; sun.shadow.camera.bottom = -75;
  sun.shadow.camera.near = 1; sun.shadow.camera.far = 180;
  sun.shadow.camera.updateProjectionMatrix();
  scene.add(sun);

  const worldGroup = new THREE.Group();
  scene.add(worldGroup);

  const player = makePlayer3D();
  player.position.set(0, 0, 4);
  player.traverse(o => { if (o.isMesh) o.castShadow = true; });
  scene.add(player);

  const bobber = new THREE.Mesh(new THREE.SphereGeometry(0.5, 12, 10),
    new THREE.MeshLambertMaterial({ color: 0xff5252 }));
  bobber.visible = false;
  scene.add(bobber);

  const lineGeo = new THREE.BufferGeometry();
  lineGeo.setAttribute("position", new THREE.BufferAttribute(new Float32Array(6), 3));
  const fishLine = new THREE.Line(lineGeo, new THREE.LineBasicMaterial({ color: 0xf4f4f4 }));
  fishLine.visible = false;
  scene.add(fishLine);

  // mökkiparannukset (näkyvät kun ostettu)
  const items = {};
  items.vene = makeBoat3D();
  items.vene.position.set(COTTAGE_BOAT_DOCK.x, 0.3, COTTAGE_BOAT_DOCK.z);
  items.atrain = makeAtrain3D();
  items.atrain.position.set(3.0, 0.1, 2.0);
  items.atrain.rotation.set(0.12, 0.5, -0.34);
  items.grilli = makeGrill3D(); items.grilli.position.set(12, 0, 12);
  items.kukat = makeFlowers3D(); items.kukat.position.set(-11, 0, 24);
  items.sauna = makeSauna3D(); items.sauna.position.set(18, 0, 7);
  items.valot = makeLamps3D();
  for (const k in items) { items[k].visible = false; scene.add(items[k]); }

  // uivat kalat (atrainkalastusta varten)
  const fishCols = [0x6f8fa6, 0x8a9a6a, 0xb5763a, 0x6a7d8a, 0x9aa05a, 0x7a6a8a];
  const cFishes = [];
  for (let i = 0; i < 7; i++) {
    const fm = makeCottageFish3D(fishCols[i % fishCols.length]);
    scene.add(fm);
    cFishes.push({
      mesh: fm,
      x: (Math.random() - 0.5) * 84,
      z: -12 - Math.random() * 44,
      y: 0.85 + Math.random() * 0.5,
      dir: Math.random() < 0.5 ? 1 : -1,
      speed: 3 + Math.random() * 3.5,
      t: Math.random() * 6,
      gone: false, respawn: 0,
    });
  }
  const thrownSpear = makeThrownSpear3D();
  thrownSpear.visible = false;
  scene.add(thrownSpear);

  // atraimen tähtäysmerkki vedessä
  const aimMarker = new THREE.Group();
  const aimRing = new THREE.Mesh(new THREE.RingGeometry(0.7, 1.15, 20),
    new THREE.MeshBasicMaterial({ color: 0x9fe6ff, transparent: true, opacity: 0.85, side: THREE.DoubleSide }));
  aimRing.rotation.x = -Math.PI / 2;
  aimMarker.add(aimRing);
  const aimDot = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 6),
    new THREE.MeshBasicMaterial({ color: 0xff5252 }));
  aimMarker.add(aimDot);
  aimMarker.visible = false;
  scene.add(aimMarker);

  camera.position.set(0, 9, 22);

  cottage3D = {
    renderer, scene, camera, sun, worldGroup, water: null,
    player, bobber, fishLine, cabin: null, items,
    fishes: cFishes,
    atrain: { spear: thrownSpear, flying: false, vel: new THREE.Vector3(), dist: 0, reload: 0 },
    aim: new THREE.Vector3(0, 0.85, -32),
    aimMarker,
    ray: new THREE.Raycaster(),
    aimPlane: new THREE.Plane(new THREE.Vector3(0, 1, 0), -0.85),
    tool: "onki",
    inBoat: false,
    boat: { x: COTTAGE_BOAT_DOCK.x, z: COTTAGE_BOAT_DOCK.z, heading: 0 },
    doorPivot: null, doorOpen: 0, doorOpening: false,
    camYaw: 0, camPitch: 0.34,
    active: false, walkPhase: 0,
    daySky: 0x8fd0ee, sunBase: 0.95,
    cf: { phase: "idle", t: 0, msg: "", msgLife: 0 },
  };
  } catch (err) {
    cottage3D = null;
  }
}
function syncCottageItems() {
  if (!cottage3D) return;
  for (const k in cottage3D.items) {
    cottage3D.items[k].visible = state.cottageItems.includes(k);
  }
}
const COTTAGE_STYLE = {
  jarvimokki: {
    sky: 0x8fd0ee, fogNear: 75, fogFar: 250, sunBase: 1.0,
    ground: 0x5fa83f, water: 0x2f86b4, bed: 0x14506e,
    dockWood: 0x8a5a32, pathColor: 0xc9b07a,
  },
  metsamokki: {
    sky: 0x9aa9a0, fogNear: 34, fogFar: 145, sunBase: 0.58,
    ground: 0x35562e, water: 0x274f3e, bed: 0x14301f,
    dockWood: 0x4a3a26, pathColor: 0x6a6358,
  },
  rantamokki: {
    sky: 0xbfeaf4, fogNear: 100, fogFar: 340, sunBase: 1.16,
    ground: 0xe6d29a, water: 0x36c6d4, bed: 0x1f8fa0,
    dockWood: 0xd8c294, pathColor: 0xefe2bc,
  },
};
const JARVI_TREES = [[-38, 36], [33, 32], [-44, 4], [42, 14], [-30, 52], [48, 46], [-50, -8], [52, -4]];
const FOREST_TREES = [
  [-44, 8], [-40, 28], [-46, 46], [-34, 54], [-30, 38], [-24, 52], [-22, 22], [-38, 16],
  [44, 10], [40, 30], [46, 48], [34, 52], [30, 40], [24, 54], [22, 24], [38, 18],
  [-12, 52], [6, 52], [14, 44], [-6, 46], [10, 30], [-30, 4], [28, 8], [-2, 56],
];
function disposeObj3D(o) {
  o.traverse(c => {
    if (c.geometry) c.geometry.dispose();
    if (c.material) {
      if (Array.isArray(c.material)) c.material.forEach(m => m.dispose());
      else c.material.dispose();
    }
  });
}
function addCottageBlades(wg, count, y, c1, c2) {
  const geo = new THREE.ConeGeometry(0.17, 1.2, 4);
  const m1 = new THREE.MeshLambertMaterial({ color: c1 });
  const m2 = new THREE.MeshLambertMaterial({ color: c2 });
  for (let i = 0; i < count; i++) {
    const gx = (Math.random() - 0.5) * 108;
    const gz = 4 + Math.random() * 54;
    if (Math.abs(gx) < 4.5 && gz < 7) continue;
    if (Math.abs(gx + 16) < 8 && Math.abs(gz - 17) < 7) continue;
    const bl = new THREE.Mesh(geo, i % 2 ? m1 : m2);
    bl.position.set(gx, y, gz);
    bl.scale.y = 0.7 + Math.random() * 0.9;
    bl.rotation.y = Math.random() * 3.1;
    bl.rotation.z = (Math.random() - 0.5) * 0.3;
    wg.add(bl);
  }
}
function buildCottageWorld(name) {
  if (!cottage3D) return;
  const C = cottage3D, wg = C.worldGroup;
  while (wg.children.length) { const ch = wg.children.pop(); disposeObj3D(ch); }
  const cfg = COTTAGE_STYLE[name] || COTTAGE_STYLE.jarvimokki;
  C.daySky = cfg.sky; C.sunBase = cfg.sunBase;
  C.scene.background.setHex(cfg.sky);
  C.scene.fog.color.setHex(cfg.sky);
  C.scene.fog.near = cfg.fogNear; C.scene.fog.far = cfg.fogFar;
  C.sun.intensity = cfg.sunBase;

  const ground = new THREE.Mesh(new THREE.PlaneGeometry(520, 520),
    new THREE.MeshLambertMaterial({ color: cfg.ground }));
  ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true;
  wg.add(ground);

  const water = new THREE.Mesh(new THREE.PlaneGeometry(460, 360, 36, 26),
    new THREE.MeshLambertMaterial({ color: cfg.water, transparent: true, opacity: 0.95 }));
  water.rotation.x = -Math.PI / 2; water.position.set(0, 0.62, -180);
  wg.add(water); C.water = water;
  const bed = new THREE.Mesh(new THREE.PlaneGeometry(460, 360),
    new THREE.MeshLambertMaterial({ color: cfg.bed }));
  bed.rotation.x = -Math.PI / 2; bed.position.set(0, -1.2, -180);
  wg.add(bed);

  const path = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 26),
    new THREE.MeshLambertMaterial({ color: cfg.pathColor }));
  path.rotation.x = -Math.PI / 2; path.position.set(-11, 0.05, 11); path.rotation.z = 0.6;
  wg.add(path);

  let cabin;
  if (name === "metsamokki") cabin = makeCabinAframe3D();
  else if (name === "rantamokki") cabin = makeCabinBeach3D();
  else cabin = makeCabin3D();
  cabin.position.set(-16, 0, 17);
  wg.add(cabin);
  C.cabin = cabin; C.doorPivot = cabin.userData.doorPivot;

  const dock = new THREE.Group();
  const dockMat = new THREE.MeshLambertMaterial({ color: cfg.dockWood });
  for (let i = 0; i < 14; i++) {
    const plk = new THREE.Mesh(new THREE.BoxGeometry(5.2, 0.5, 1.5), dockMat);
    plk.position.set(0, 1.3, 5 - i * 1.6);
    plk.castShadow = true; plk.receiveShadow = true;
    dock.add(plk);
  }
  for (let z = 4; z >= -17; z -= 4.5) {
    for (const x of [-2.3, 2.3]) {
      const post = c3dBox(0.6, 3.8, 0.6, 0x5a3a22);
      post.position.set(x, -0.5, z);
      dock.add(post);
    }
  }
  wg.add(dock);

  if (name === "metsamokki") {
    const fpal = { trunk: 0x3a2a1a, cones: [0x1d3a20, 0x244a27, 0x2c5a30] };
    for (const p of FOREST_TREES) {
      const t = makeTree3D(fpal);
      t.position.set(p[0], 0, p[1]);
      t.scale.setScalar(0.9 + Math.random() * 0.5);
      t.traverse(o => { if (o.isMesh) o.castShadow = true; });
      wg.add(t);
    }
    for (const p of [[-9, 30], [13, 33], [-24, 42], [22, 14]]) {
      const lg = makeFallenLog3D();
      lg.position.set(p[0], 0, p[1]); lg.rotation.y = Math.random() * 3;
      wg.add(lg);
    }
    for (let i = 0; i < 26; i++) {
      const ms = makeMushroom3D();
      ms.position.set((Math.random() - 0.5) * 96, 0, 6 + Math.random() * 48);
      wg.add(ms);
    }
    for (const p of [[-14, 26], [16, 40], [-30, 14], [28, 30], [6, 46]]) {
      const r = makeRock3D(1.4 + Math.random() * 1.8);
      r.position.set(p[0], 0, p[1]);
      r.material.color.setHex(0x59614f);
      wg.add(r);
    }
    addCottageBlades(wg, 64, 0.55, 0x2f6a2c, 0x3c7d36);
  } else if (name === "rantamokki") {
    for (const p of [[-34, 30], [34, 22], [-42, 50], [40, 48]]) {
      const pm = makePalm3D();
      pm.position.set(p[0], 0, p[1]);
      wg.add(pm);
    }
    const um = makeUmbrella3D(); um.position.set(13, 0, 33); wg.add(um);
    const lo = makeLounger3D(); lo.position.set(9, 0, 35); lo.rotation.y = -0.3; wg.add(lo);
    const lo2 = makeLounger3D(); lo2.position.set(17, 0, 36); lo2.rotation.y = 0.2; wg.add(lo2);
    for (let i = 0; i < 30; i++) {
      const sh = makeShell3D();
      sh.position.set((Math.random() - 0.5) * 100, 0, 4 + Math.random() * 16);
      sh.rotation.y = Math.random() * 3;
      wg.add(sh);
    }
    for (const p of [[-26, 42], [26, 46], [-10, 52]]) {
      const dn = new THREE.Mesh(new THREE.SphereGeometry(4.4, 12, 8),
        new THREE.MeshLambertMaterial({ color: 0xdcc488 }));
      dn.scale.set(1, 0.28, 1); dn.position.set(p[0], 0, p[1]);
      dn.receiveShadow = true;
      wg.add(dn);
    }
    addCottageBlades(wg, 34, 0.5, 0xcdb878, 0xb8a35e);
  } else {
    for (const p of JARVI_TREES) {
      const t = makeTree3D();
      t.position.set(p[0], 0, p[1]);
      t.traverse(o => { if (o.isMesh) o.castShadow = true; });
      wg.add(t);
    }
    for (const p of [[-8, 30], [13, 27], [-30, 19], [25, -2], [8, 35]]) {
      const r = makeRock3D(1 + Math.random() * 1.5);
      r.position.set(p[0], 0, p[1]);
      wg.add(r);
    }
    for (const p of [[-25, 29], [19, 35], [-6, 41], [31, 21]]) {
      const bu = makeBush3D();
      bu.position.set(p[0], 0, p[1]);
      wg.add(bu);
    }
    addCottageBlades(wg, 140, 0.55, 0x4f9a3a, 0x63b048);
  }
}
function syncCottageCanvas() {
  const at3d = !!(state.atCottage && cottage3D && cottage3D.active);
  canvas.style.display = at3d ? "none" : "";
  cottage3dEl.style.display = at3d ? "" : "none";
  cottageHudEl.style.display = at3d ? "" : "none";
  if (cottageTimePanelEl) cottageTimePanelEl.style.display = state.atCottage ? "" : "none";
}
function updateCottageTimePanel() {
  if (!cottageTimePanelEl || !state.atCottage) return;
  const cot = COTTAGES.find(c => c.name === state.atCottage);
  if (!cot) return;
  const hh = Math.floor(state.time);
  const mm = Math.floor((state.time - hh) * 60);
  const clock = (hh < 10 ? "0" : "") + hh + ":" + (mm < 10 ? "0" : "") + mm;
  const sea = curSeason();
  const days = state.cottageDays[cot.name] || 0;
  const temp = Math.round(state.temp + (cot.tempOffset || 0));
  let tcls = "ct-good";
  if (temp <= 2) tcls = "ct-cold";
  else if (temp >= 20) tcls = "ct-hot";
  cottageTimePanelEl.innerHTML =
    `<div class="ct-title">🏡 ${cot.display}</div>` +
    `<div>📅 Mökillä ${days} ${days === 1 ? "päivä" : "päivää"}</div>` +
    `<div>${sea.icon} ${sea.name}</div>` +
    `<div>${isNight() ? "🌙" : "☀️"} ${clock}</div>` +
    `<div class="${tcls}">🌡️ ${temp} °C</div>`;
}
function cottageMsg(text) {
  if (!cottage3D) return;
  cottage3D.cf.msg = text;
  cottage3D.cf.msgLife = 2.4;
}
function cottageAction() {
  if (!cottage3D) return;
  if (cottage3D.tool === "atrain" && state.cottageItems.includes("atrain")) {
    cottageThrowAtrain();
    return;
  }
  const cf = cottage3D.cf;
  if (cf.phase === "bite") cottageHook();
  else if (cf.phase === "idle") cottageCast();
}
function cottageSelectTool(t) {
  if (!cottage3D) return;
  if (t === "atrain" && !state.cottageItems.includes("atrain")) {
    cottageMsg("Osta atrain mökin sisältä!");
    return;
  }
  if (cottage3D.tool === t) return;
  cottage3D.tool = t;
  cottageMsg(t === "atrain"
    ? "🔱 Atrain kädessä (" + state.atrainCharges + "/3)"
    : "🎣 Onki kädessä");
}
function cottageAtrainMiss() {
  state.atrainCharges = Math.max(0, state.atrainCharges - 1);
  if (state.atrainCharges <= 0) {
    const idx = state.cottageItems.indexOf("atrain");
    if (idx >= 0) state.cottageItems.splice(idx, 1);
    state.atrainCharges = 3;
    syncCottageItems();
    if (cottage3D) cottage3D.tool = "onki";
    cottageMsg("💔 Atrain hukkui! Kolme ohilaukausta putkeen.");
    sfxEscape();
    updateHUD();
    autoSave();
  } else {
    cottageMsg("Ohi! Atrain " + state.atrainCharges + "/3 — osu niin täyttyy");
  }
}
function cottageThrowAtrain() {
  const C = cottage3D, at = C.atrain, pl = C.player;
  if (at.flying) return;
  if (at.reload > 0) return;
  pl.updateMatrixWorld(true);
  const from = new THREE.Vector3();
  pl.userData.atrainTip.getWorldPosition(from);
  const dir = new THREE.Vector3().subVectors(C.aim, from);
  if (dir.lengthSq() < 0.04) return;
  dir.normalize();
  at.spear.position.copy(from);
  at.spear.visible = true;
  at.flying = true;
  at.dist = 0;
  at.vel.copy(dir).multiplyScalar(50);
  at.reload = 0.8;
  sfxReel();
}
function updateCottageAim(nx, ny) {
  const C = cottage3D;
  if (!C) return;
  C.ray.setFromCamera({ x: nx, y: ny }, C.camera);
  const hit = new THREE.Vector3();
  if (C.ray.ray.intersectPlane(C.aimPlane, hit)) {
    hit.x = clampv(hit.x, -92, 92);
    hit.z = clampv(hit.z, -132, -8);
    C.aim.copy(hit);
  }
}
function cottageAtrainCatch(fish) {
  const tp = WORM_FISH[(Math.random() * WORM_FISH.length) | 0];
  const sr = Math.random();
  const size = sr < 0.5 ? "large" : (sr < 0.86 ? "medium" : "small");
  state.bucket.push({ type: tp, rotten: false, size, locMult: 1 });
  fish.gone = true;
  fish.mesh.visible = false;
  fish.respawn = 2.2 + Math.random() * 2.5;
  const refilled = state.atrainCharges < 3;
  state.atrainCharges = 3;
  sfxCatch();
  const pfx = size !== "medium" ? sizeByName(size).label + " " : "";
  cottageMsg("🔱 " + pfx + tp.display + " keihästettiin!" + (refilled ? " Atrain 3/3" : ""));
  updateHUD();
  autoSave();
}
function cottageCast() {
  const C = cottage3D, cf = C.cf, pl = C.player;
  if (state.upgrades.onki < 1) { cottageMsg("Osta onki kaupasta (K)!"); return; }
  if (state.upgrades.pihdit < 1) { cottageMsg("Osta pihdit kaupasta (K)!"); return; }
  if (pl.position.z > -2) { cottageMsg("Kävele laiturin päähän onkimaan"); return; }
  const hasAtrain = state.cottageItems.includes("atrain");
  if (!hasAtrain && state.worms < 1) { cottageMsg("Ei matoja! Osta matoja tai atrain."); return; }
  if (!hasAtrain) state.worms--;
  cf.phase = "casting"; cf.t = 0;
  pl.updateMatrixWorld(true);
  cf.castFrom = new THREE.Vector3();
  pl.userData.rodTip.getWorldPosition(cf.castFrom);
  cf.castTo = new THREE.Vector3(
    pl.position.x + (Math.random() - 0.5) * 7, 0.4,
    pl.position.z - 15 - Math.random() * 9);
  C.bobber.visible = true;
  C.bobber.position.copy(cf.castFrom);
  updateHUD();
  autoSave();
}
function cottageHook() {
  const C = cottage3D, cf = C.cf;
  if (cf.phase !== "bite") return;
  const tp = WORM_FISH[(Math.random() * WORM_FISH.length) | 0];
  const sr = Math.random();
  const atrain = state.cottageItems.includes("atrain");
  const size = atrain
    ? (sr < 0.5 ? "large" : (sr < 0.86 ? "medium" : "small"))
    : (sr < 0.3 ? "large" : (sr < 0.72 ? "medium" : "small"));
  state.bucket.push({ type: tp, rotten: false, size, locMult: 1 });
  cf.phase = "caught"; cf.t = 0;
  sfxCatch();
  const pfx = size !== "medium" ? sizeByName(size).label + " " : "";
  cottageMsg(pfx + tp.display + " saatiin! 🎣");
  updateHUD();
  autoSave();
}
function cottageEscape() {
  const C = cottage3D, cf = C.cf;
  cf.phase = "idle"; cf.t = 0;
  C.bobber.visible = false;
  C.fishLine.visible = false;
  sfxEscape();
  cottageMsg("Kala karkasi ja vei madon!");
}
const CABIN_BOX = { cx: -16, cz: 17, hx: 6.4, hz: 5.4 };
const COTTAGE_BOAT_DOCK = { x: 0, z: -21 };
function nearCottageDoor() {
  if (!cottage3D) return false;
  const pl = cottage3D.player;
  const dx = pl.position.x + 16, dz = pl.position.z - 21.4;
  return (dx * dx + dz * dz) < 30;
}
function updateCottage3D(dt) {
  const C = cottage3D, pl = C.player, cf = C.cf;
  const ownAtrain = state.cottageItems.includes("atrain");
  if (C.tool === "atrain" && !ownAtrain) C.tool = "onki";
  const useAtrain = C.tool === "atrain";
  // varuste kädessä + istuma-asento veneessä
  pl.userData.rod.visible = !useAtrain;
  pl.userData.heldAtrain.visible = useAtrain;
  const sitTarget = C.inBoat ? -1.2 : 0;
  for (const hip of pl.userData.legs) {
    hip.rotation.x += (sitTarget - hip.rotation.x) * Math.min(1, dt * 9);
  }
  // liike — kamerasuhteinen (eteenpäin = ruudun sisään)
  let mx = 0, mz = 0;
  if (state.keys["ArrowLeft"] || state.keys["KeyA"]) mx -= 1;
  if (state.keys["ArrowRight"] || state.keys["KeyD"]) mx += 1;
  if (state.keys["ArrowUp"] || state.keys["KeyW"]) mz -= 1;
  if (state.keys["ArrowDown"] || state.keys["KeyS"]) mz += 1;
  const moving = !!(mx || mz);
  const boatBob = Math.sin(performance.now() / 600) * 0.08;
  if (C.inBoat) {
    // --- veneellä ajo vesillä ---
    const bt = C.boat;
    if (moving) {
      const yaw = C.camYaw;
      const fx = -Math.sin(yaw), fz = -Math.cos(yaw);
      const rx = Math.cos(yaw), rz = -Math.sin(yaw);
      let dx = rx * mx + fx * (-mz);
      let dz = rz * mx + fz * (-mz);
      const l = Math.hypot(dx, dz) || 1;
      dx /= l; dz /= l;
      bt.x += dx * 17 * dt;
      bt.z += dz * 17 * dt;
      bt.heading = Math.atan2(dx, dz);
    }
    bt.x = clampv(bt.x, -94, 94);
    bt.z = clampv(bt.z, -134, -18);
    C.items.vene.position.set(bt.x, 0.3 + boatBob, bt.z);
    C.items.vene.rotation.y = bt.heading + Math.PI;
    pl.position.set(bt.x, 0.3 + boatBob, bt.z);
    pl.rotation.y = bt.heading;
    pl.userData.body.position.y = 0;
  } else {
    // --- kävely ---
    if (moving) {
      const yaw = C.camYaw;
      const fx = -Math.sin(yaw), fz = -Math.cos(yaw);
      const rx = Math.cos(yaw), rz = -Math.sin(yaw);
      let dx = rx * mx + fx * (-mz);
      let dz = rz * mx + fz * (-mz);
      const l = Math.hypot(dx, dz) || 1;
      dx /= l; dz /= l;
      pl.position.x += dx * 14 * dt;
      pl.position.z += dz * 14 * dt;
      pl.rotation.y = Math.atan2(dx, dz);
      C.walkPhase += dt * 9;
    }
    // alueen rajat
    if (pl.position.z < 3) {
      pl.position.x = clampv(pl.position.x, -2, 2);
      pl.position.z = clampv(pl.position.z, -16, 3);
    } else {
      pl.position.x = clampv(pl.position.x, -54, 54);
      pl.position.z = clampv(pl.position.z, 3, 58);
    }
    // törmäys mökkiin — ei voi mennä läpi
    const dcx = pl.position.x - CABIN_BOX.cx, dcz = pl.position.z - CABIN_BOX.cz;
    if (Math.abs(dcx) < CABIN_BOX.hx && Math.abs(dcz) < CABIN_BOX.hz) {
      const ox = CABIN_BOX.hx - Math.abs(dcx);
      const oz = CABIN_BOX.hz - Math.abs(dcz);
      if (ox < oz) pl.position.x = CABIN_BOX.cx + (dcx < 0 ? -1 : 1) * CABIN_BOX.hx;
      else pl.position.z = CABIN_BOX.cz + (dcz < 0 ? -1 : 1) * CABIN_BOX.hz;
    }
    // törmäys saunaan
    if (state.cottageItems.includes("sauna")) {
      const dsx = pl.position.x - 18, dsz = pl.position.z - 7;
      if (Math.abs(dsx) < 4.3 && Math.abs(dsz) < 3.8) {
        const ox = 4.3 - Math.abs(dsx), oz = 3.8 - Math.abs(dsz);
        if (ox < oz) pl.position.x = 18 + (dsx < 0 ? -4.3 : 4.3);
        else pl.position.z = 7 + (dsz < 0 ? -3.8 : 3.8);
      }
    }
    pl.userData.body.position.y = moving ? Math.abs(Math.sin(C.walkPhase)) * 0.32 : 0;
    // laiturilla pelaaja seisoo laiturin tasolla
    const onDock = pl.position.z < 3;
    pl.position.y += ((onDock ? 1.55 : 0) - pl.position.y) * Math.min(1, dt * 8);
  }

  // oven animaatio
  C.doorOpen += ((C.doorOpening ? 1 : 0) - C.doorOpen) * Math.min(1, dt * 6);
  C.doorPivot.rotation.y = -C.doorOpen * 1.95;
  if (!nearCottageDoor() && C.doorOpen < 0.05) C.doorOpening = false;

  // kamera — orbit (CapsLock+hiiri pyörittää camYaw/camPitch)
  const cam = C.camera;
  const dist = 19, cp = C.camPitch;
  const horiz = dist * Math.cos(cp);
  const wantX = pl.position.x + Math.sin(C.camYaw) * horiz;
  const wantY = 2.6 + dist * Math.sin(cp);
  const wantZ = pl.position.z + Math.cos(C.camYaw) * horiz;
  cam.position.x += (wantX - cam.position.x) * Math.min(1, dt * 8);
  cam.position.y += (wantY - cam.position.y) * Math.min(1, dt * 8);
  cam.position.z += (wantZ - cam.position.z) * Math.min(1, dt * 8);
  cam.lookAt(pl.position.x, 2.8, pl.position.z);

  // vesi — loivat aallot (eivät yllä laiturille eivätkä nurmen alle)
  const wtm = performance.now() / 1000;
  const wp = C.water.geometry.attributes.position;
  for (let i = 0; i < wp.count; i++) {
    const vx = wp.getX(i), vy = wp.getY(i);
    wp.setZ(i, Math.sin(vx * 0.07 + wtm * 1.7) * 0.22
             + Math.sin(vy * 0.09 + wtm * 1.2) * 0.16);
  }
  wp.needsUpdate = true;

  // uivat kalat
  for (const f of C.fishes) {
    if (f.gone) {
      f.respawn -= dt;
      if (f.respawn <= 0) {
        f.gone = false;
        f.x = (Math.random() - 0.5) * 84;
        f.z = -12 - Math.random() * 44;
        f.mesh.visible = true;
      }
      continue;
    }
    f.t += dt;
    f.x += f.dir * f.speed * dt;
    if (f.x > 47) { f.x = 47; f.dir = -1; }
    if (f.x < -47) { f.x = -47; f.dir = 1; }
    f.mesh.position.set(f.x, f.y + Math.sin(f.t * 1.7) * 0.16, f.z);
    f.mesh.rotation.y = f.dir > 0 ? 0 : Math.PI;
    f.mesh.rotation.z = Math.sin(f.t * 3.2) * 0.13;
  }
  // atrainheitto — keihäs lentää tähtäyssuuntaan, osuu kalaan matkalla
  const at = C.atrain;
  if (at.reload > 0) at.reload -= dt;
  if (at.flying) {
    at.spear.position.addScaledVector(at.vel, dt);
    at.spear.lookAt(
      at.spear.position.x + at.vel.x,
      at.spear.position.y + at.vel.y,
      at.spear.position.z + at.vel.z);
    at.dist += at.vel.length() * dt;
    let hit = null;
    for (const f of C.fishes) {
      if (f.gone) continue;
      if (at.spear.position.distanceTo(f.mesh.position) < 2.7) { hit = f; break; }
    }
    if (hit) {
      cottageAtrainCatch(hit);
      at.flying = false; at.spear.visible = false; at.reload = 0.85;
    } else if (at.dist > 100 || at.spear.position.y < -2.5) {
      at.flying = false; at.spear.visible = false; at.reload = 0.4;
      cottageAtrainMiss();
    }
  }
  // tähtäysmerkki vedessä
  C.aimMarker.visible = useAtrain && !at.flying;
  if (C.aimMarker.visible) {
    C.aimMarker.position.set(C.aim.x, 0.92 + Math.sin(performance.now() / 300) * 0.05, C.aim.z);
  }

  // onginta — siima lähtee ongen kärjestä
  cf.t += dt;
  if (cf.msgLife > 0) cf.msgLife -= dt;
  pl.updateMatrixWorld(true);
  const tip = new THREE.Vector3();
  pl.userData.rodTip.getWorldPosition(tip);
  const b = C.bobber;
  if (cf.phase === "casting") {
    const k = Math.min(1, cf.t / 0.6);
    b.position.x = cf.castFrom.x + (cf.castTo.x - cf.castFrom.x) * k;
    b.position.z = cf.castFrom.z + (cf.castTo.z - cf.castFrom.z) * k;
    b.position.y = cf.castFrom.y + (cf.castTo.y - cf.castFrom.y) * k + Math.sin(k * Math.PI) * 3.5;
    if (k >= 1) {
      cf.phase = "waiting"; cf.t = 0;
      cf.biteAt = state.cottageItems.includes("atrain")
        ? 1.0 + Math.random() * 2.6
        : 2.5 + Math.random() * 6;
    }
  } else if (cf.phase === "waiting") {
    b.position.y = 0.4 + Math.sin(performance.now() / 500) * 0.12;
    if (cf.t >= cf.biteAt) {
      cf.phase = "bite"; cf.t = 0;
      cf.window = 1.0 + state.upgrades.onki * 0.28 + state.upgrades.pihdit * 0.16;
      sfxBite();
    }
  } else if (cf.phase === "bite") {
    b.position.y = -0.8 + Math.sin(performance.now() / 55) * 0.18;
    if (cf.t >= cf.window) cottageEscape();
  } else if (cf.phase === "caught") {
    b.position.y = 0.5 + Math.sin(performance.now() / 180) * 0.3;
    if (cf.t >= 1.0) { cf.phase = "idle"; b.visible = false; C.fishLine.visible = false; }
  }
  if (b.visible) {
    C.fishLine.visible = true;
    const pos = C.fishLine.geometry.attributes.position;
    pos.setXYZ(0, tip.x, tip.y, tip.z);
    pos.setXYZ(1, b.position.x, b.position.y, b.position.z);
    pos.needsUpdate = true;
  } else {
    C.fishLine.visible = false;
  }

  // HUD
  let hs, cls = "";
  const swap = ownAtrain ? " · 1=onki 2=atrain" : "";
  const atrTag = "🔱 Atrain " + state.atrainCharges + "/3";
  if (cf.phase === "bite") { hs = "‼ NYKÄISY — paina VÄLILYÖNTI nyt!"; cls = "bite"; }
  else if (cf.msgLife > 0) hs = cf.msg;
  else if (C.inBoat) hs = useAtrain
    ? atrTag + " · ohjaa nuolilla · tähtää hiirellä · klik/VÄLI = heitä · E = poistu laiturilla"
    : "🪱 Ohjaa nuolilla · VÄLI = onki · E = poistu laiturin luona" + swap;
  else if (cf.phase === "casting" || cf.phase === "waiting") hs = "🪱 Madot: " + state.worms + " · Onki vedessä…";
  else if (nearCottageBoat()) hs = "🛶 Paina E — nouse veneeseen";
  else if (nearSauna()) hs = "🧖 Paina E — mene saunaan (osta grilli)";
  else if (nearCottageDoor()) hs = "🚪 Paina E — mene mökin sisään ostoksille";
  else if (useAtrain) hs = atrTag + " · tähtää hiirellä · klik/VÄLI = heitä · E = mökkiin/vene" + swap;
  else hs = "🪱 Madot: " + state.worms + " · VÄLI = onki · E = mökkiin/vene" + swap;
  cottageHudEl.innerHTML = cls ? `<span class="${cls}">${hs}</span>` : hs;

  for (const ft of floatTexts) { ft.life -= dt; }
  while (floatTexts.length && floatTexts[0].life <= 0) floatTexts.shift();
  updateHUD();
}
function renderCottage3D() {
  const C = cottage3D;
  const n = nightAmount();
  const base = C.sunBase || 0.95;
  C.sun.intensity = base - n * base * 0.8;
  const sky = new THREE.Color(C.daySky || 0x8fd0ee).lerp(new THREE.Color(0x16284a), n);
  C.scene.background.copy(sky);
  C.scene.fog.color.copy(sky);
  C.renderer.render(C.scene, C.camera);
}
let cottageShopPlace = "house";
function nearSauna() {
  if (!cottage3D || !state.cottageItems.includes("sauna")) return false;
  const pl = cottage3D.player;
  const dx = pl.position.x - 18, dz = pl.position.z - 11;
  return (dx * dx + dz * dz) < 36;
}
function nearCottageBoat() {
  if (!cottage3D || !state.cottageItems.includes("vene")) return false;
  const pl = cottage3D.player, b = cottage3D.boat;
  const dx = pl.position.x - b.x, dz = pl.position.z - b.z;
  return (dx * dx + dz * dz) < 42;
}
function boatNearDock() {
  const b = cottage3D.boat;
  const dx = b.x - COTTAGE_BOAT_DOCK.x, dz = b.z - COTTAGE_BOAT_DOCK.z;
  return (dx * dx + dz * dz) < 130;
}
function toggleCottageBoat() {
  const C = cottage3D;
  if (C.inBoat) {
    if (!boatNearDock()) { cottageMsg("Aja vene takaisin laiturin luo"); return; }
    C.inBoat = false;
    C.boat.x = COTTAGE_BOAT_DOCK.x; C.boat.z = COTTAGE_BOAT_DOCK.z; C.boat.heading = 0;
    C.items.vene.position.set(COTTAGE_BOAT_DOCK.x, 0.3, COTTAGE_BOAT_DOCK.z);
    C.items.vene.rotation.y = 0;
    C.player.position.set(0, 1.55, -15);
    cottageMsg("Nousit laiturille");
    return;
  }
  if (!state.cottageItems.includes("vene")) {
    cottageMsg("Osta soutuvene mökin sisältä!");
    return;
  }
  if (!nearCottageBoat()) { cottageMsg("Kävele veneen luo (laiturin pää)"); return; }
  C.inBoat = true;
  cottageMsg("🛶 Veneessä — ohjaa nuolilla, kalasta vedellä");
}
function cottageEnterHouse() {
  if (!cottage3D) return;
  if (cottage3D.inBoat || nearCottageBoat()) { toggleCottageBoat(); return; }
  if (nearSauna()) { cottageShopPlace = "sauna"; toggleCottageShop(true); return; }
  if (!nearCottageDoor()) { cottageMsg("Mene mökin oven luo (E)"); return; }
  cottageShopPlace = "house";
  cottage3D.doorOpening = true;
  toggleCottageShop(true);
}
function toggleCottageShop(forceOpen) {
  const el = document.getElementById("cottageShop");
  if (!el) return;
  const willOpen = forceOpen !== undefined ? forceOpen : el.classList.contains("hidden");
  el.classList.toggle("hidden", !willOpen);
  state.paused = willOpen && state.running;
  if (willOpen) renderCottageShop();
}
function renderCottageShop() {
  const titleEl = document.getElementById("cottageShopTitle");
  if (titleEl) titleEl.textContent = cottageShopPlace === "sauna" ? "🧖 Sauna" : "🏡 Mökin sisällä";
  const moneyEl2 = document.getElementById("cottageShopMoney");
  if (moneyEl2) moneyEl2.textContent = state.money;
  const list = document.getElementById("cottageItemList");
  if (!list) return;
  list.innerHTML = "";
  for (const it of COTTAGE_ITEMS) {
    if (it.place !== cottageShopPlace) continue;
    const owned = state.cottageItems.includes(it.name);
    const can = !owned && state.money >= it.price;
    const div = document.createElement("div");
    div.className = "upgrade";
    div.innerHTML = `
      <div class="info">
        <div class="title">${it.display}</div>
        <div class="desc">${it.desc}</div>
      </div>
      <button class="upgrade-btn" ${(owned || !can) ? "disabled" : ""}>
        ${owned ? "Ostettu ✓" : "Osta · " + it.price + " mk"}
      </button>`;
    if (!owned && can) {
      div.querySelector("button").addEventListener("click", () => buyCottageItem(it.name));
    }
    list.appendChild(div);
  }
}
function buyCottageItem(name) {
  const it = COTTAGE_ITEMS.find(c => c.name === name);
  if (!it || state.cottageItems.includes(name) || state.money < it.price) return;
  state.money -= it.price;
  state.cottageItems.push(name);
  syncCottageItems();
  sfxCatch();
  updateHUD();
  renderCottageShop();
  autoSave();
}
function renderMapDetail() {
  const cot = COTTAGES.find(c => c.name === mapSelection);
  if (cot) { renderCottageDetail(cot); return; }
  const loc = LOCATIONS.find(l => l.name === mapSelection);
  if (!loc) {
    mapDetailEl.innerHTML = "<em>Valitse paikka kartalta.</em>";
    return;
  }
  const owned = state.unlocked.includes(loc.name);
  const here = state.locationName === loc.name;
  const canBuy = !owned && state.money >= loc.price;

  const bonuses = [`kalan arvo ${Math.round(loc.valueMult * 100)} %`];
  if (loc.rareBoost > 0) bonuses.push("arvokkaampia lajeja");
  if (loc.sizeBoost > 0) bonuses.push("isompia kaloja");

  let btnHtml;
  if (here)       btnHtml = `<button class="loc-btn" disabled>Olet täällä</button>`;
  else if (owned) btnHtml = `<button class="loc-btn" id="mapActionBtn">Matkusta tänne</button>`;
  else            btnHtml = `<button class="loc-btn" id="mapActionBtn" ${canBuy ? "" : "disabled"}>Osta alue · ${loc.price} mk</button>`;

  let warn = "";
  if (loc.subMode) {
    const usingSub = state.vehicle === "sub" && hasSub();
    warn = usingSub
      ? `<div class="loc-warn">🤿 Syvää merta — sukellusvene käytössä, turvallista.</div>`
      : `<div class="loc-warn">⚠️ Syvää merta — veneellä isot aallot voivat upottaa! Vaihda sukellusveneeseen.</div>`;
  }

  mapDetailEl.innerHTML = `
    <div class="loc-info">
      <div class="loc-title">${loc.icon} ${loc.display}${owned ? "" : " 🔒"}</div>
      <div class="loc-desc">${loc.desc}</div>
      <div class="loc-bonus">${bonuses.join(" · ")}</div>
      ${warn}
    </div>
    ${btnHtml}`;

  const actionBtn = document.getElementById("mapActionBtn");
  if (actionBtn) {
    if (owned) actionBtn.addEventListener("click", () => travelTo(loc.name));
    else       actionBtn.addEventListener("click", () => buyLocation(loc.name));
  }
}

function buyLocation(name) {
  const loc = locByName(name);
  if (state.unlocked.includes(name) || state.money < loc.price) return;
  state.money -= loc.price;
  state.unlocked.push(name);
  mapSelection = name;
  updateHUD();
  renderMap();
  sfxCatch();
  autoSave();
}

function travelTo(name) {
  if (!state.unlocked.includes(name)) return;
  if (state.locationName === name && !state.atCottage) return;
  state.atCottage = null;
  if (cottage3D) cottage3D.active = false;
  syncCottageCanvas();
  setLocation(name);
  const useSub = state.vehicle === "sub" && hasSub();
  state.subMode = useSub;
  resetScene();
  if (useSub) enterSubMode();
  if (currentLoc.subMode && !useSub) {
    // Veneellä syvällä merellä — iso aalto voi upottaa
    state.wave.timer = 12 + Math.random() * 6;
    floatText(W / 2, WATER_Y + 140, "Varo isoja aaltoja! Pakene kartalla ajoissa.", "#ff9090");
  }
  floatText(W / 2, WATER_Y + 110, "Saavuit: " + currentLoc.display, "#ffd84a");
  updateHUD();
  autoSave();
  toggleMap();
}
function resetScene() {
  state.line.out = false;
  state.line.catches = [];
  state.line.cutTimer = 0;
  reelImpulse = 0;
  state.fish = [];
  state.deadTime = 0;
  state.sub.harpoon = null;
  state.atrainMode = false;
  state.atrainGear.spear = null;
  state.atrainGear.reload = 0;
  state.placing = null;
  state.wave.timer = 0;
  state.wave.hit = 0;
  for (let i = 0; i < fishCap(); i++) spawnFish();
}
function loseBoatUpgrades(n) {
  for (let i = 0; i < n; i++) {
    let pick = null, hi = 0;
    for (const k of BOAT_UPGRADE_KEYS) {
      if (state.upgrades[k] > hi) { hi = state.upgrades[k]; pick = k; }
    }
    if (!pick) break;
    state.upgrades[pick]--;
  }
}
function boatSink() {
  loseBoatUpgrades(3);
  splash(state.boatX, WATER_Y);
  sfxSnap();
  setLocation("kotijarvi");
  state.subMode = false;
  resetScene();
  floatText(W / 2, WATER_Y + 88, "ISO AALTO UPOTTI VENEEN!", "#ff3030");
  floatText(W / 2, WATER_Y + 120, "Menetit 3 venepäivitystä.", "#ff7777");
  updateHUD();
  autoSave();
}

// =========================================================
// Input
// =========================================================
window.addEventListener("keydown", (e) => {
  // Don't capture keys while user types in auth inputs
  if (document.activeElement && document.activeElement.tagName === "INPUT") {
    if (e.code === "Enter") { e.preventDefault(); tryLogin(); }
    return;
  }
  ensureAudioOnGesture();
  if (e.getModifierState) capsOn = e.getModifierState("CapsLock");
  if (e.code === "KeyS" && e.repeat) { e.preventDefault(); return; }
  state.keys[e.code] = true;
  feedCheatKey(e.key);
  if (state.atCottage) {
    const cShop = document.getElementById("cottageShop");
    if (e.code === "Space") { e.preventDefault(); cottageAction(); }
    if (e.code === "Digit1") { e.preventDefault(); cottageSelectTool("onki"); }
    if (e.code === "Digit2") { e.preventDefault(); cottageSelectTool("atrain"); }
    if (e.code === "KeyE")  { e.preventDefault(); if (cShop && !cShop.classList.contains("hidden")) toggleCottageShop(false); else cottageEnterHouse(); }
    if (e.code === "KeyK")  { e.preventDefault(); toggleShop(); }
    if (e.code === "KeyM")  { e.preventDefault(); toggleMap(); }
    if (e.code === "KeyB")  { e.preventDefault(); toggleMusic(); }
    if (e.code === "Escape") {
      e.preventDefault();
      if (cShop && !cShop.classList.contains("hidden")) toggleCottageShop(false);
      else if (!mapEl.classList.contains("hidden")) toggleMap();
      else if (!shop.classList.contains("hidden")) toggleShop();
      else togglePause();
    }
    return;
  }
  if (state.subMode) {
    if (e.code === "Space") { e.preventDefault(); if (state.placing) placeAtAim(); else fireHarpoon(); }
    if (e.code === "KeyE")  { e.preventDefault(); cycleEditor(); }
    if (e.code === "KeyK")  { e.preventDefault(); toggleShop(); }
    if (e.code === "KeyM")  { e.preventDefault(); toggleMap(); }
    if (e.code === "KeyB")  { e.preventDefault(); toggleMusic(); }
    if (e.code === "Escape") {
      e.preventDefault();
      if (!mapEl.classList.contains("hidden")) toggleMap();
      else if (!shop.classList.contains("hidden")) toggleShop();
      else if (state.placing) state.placing = null;
      else togglePause();
    }
    return;
  }
  if (e.code === "KeyA")  { e.preventDefault(); toggleAtrainMode(); }
  if (e.code === "Space") { e.preventDefault(); if (state.atrainMode) fireAtrain(); else cast(); }
  if (e.code === "KeyS")  { e.preventDefault(); reelTap(); }
  if (e.code === "KeyY")  { e.preventDefault(); releaseFish(); }
  if (e.code === "KeyK")  { e.preventDefault(); toggleShop(); }
  if (e.code === "KeyM")  { e.preventDefault(); toggleMap(); }
  if (e.code === "KeyB")  { e.preventDefault(); toggleMusic(); }
  if (e.code === "Escape") {
    e.preventDefault();
    if (!mapEl.classList.contains("hidden")) toggleMap();
    else if (!shop.classList.contains("hidden")) toggleShop();
    else togglePause();
  }
});
window.addEventListener("keyup", (e) => {
  state.keys[e.code] = false;
  if (e.getModifierState) capsOn = e.getModifierState("CapsLock");
});
if (cottage3dEl) {
  cottage3dEl.addEventListener("mousemove", (e) => {
    if (!cottage3D || !cottage3D.active) return;
    if (capsOn) {
      cottage3D.camYaw -= (e.movementX || 0) * 0.005;
      cottage3D.camPitch = clampv(cottage3D.camPitch - (e.movementY || 0) * 0.004, 0.06, 1.25);
      return;
    }
    const r = cottage3dEl.getBoundingClientRect();
    const nx = ((e.clientX - r.left) / r.width) * 2 - 1;
    const ny = -((e.clientY - r.top) / r.height) * 2 + 1;
    updateCottageAim(nx, ny);
  });
  cottage3dEl.addEventListener("click", () => {
    ensureAudioOnGesture();
    if (!cottage3D || !cottage3D.active || state.paused) return;
    if (cottage3D.tool === "atrain" && state.cottageItems.includes("atrain")) cottageThrowAtrain();
  });
  cottage3dEl.addEventListener("touchmove", (e) => {
    if (!cottage3D || !cottage3D.active || !e.touches.length) return;
    e.preventDefault();
    const r = cottage3dEl.getBoundingClientRect();
    const nx = ((e.touches[0].clientX - r.left) / r.width) * 2 - 1;
    const ny = -((e.touches[0].clientY - r.top) / r.height) * 2 + 1;
    updateCottageAim(nx, ny);
  }, { passive: false });
}
{
  const ccsBtn = document.getElementById("closeCottageShop");
  if (ccsBtn) ccsBtn.addEventListener("click", () => toggleCottageShop(false));
}

canvas.addEventListener("click", () => {
  ensureAudioOnGesture();
  if (!state.running || state.paused) return;
  if (state.subMode) {
    if (state.placing) placeAtAim();
    else fireHarpoon();
    return;
  }
  if (state.atrainMode) { fireAtrain(); return; }
  if (!state.line.out) cast();
  else reelTap();
});
canvas.addEventListener("mousemove", (e) => {
  const r = canvas.getBoundingClientRect();
  const mx = (e.clientX - r.left) * (W / r.width);
  const my = (e.clientY - r.top) * (H / r.height);
  if (state.subMode) {
    state.sub.aimX = mx;
    state.sub.aimY = my + state.cam;
  } else if (state.atrainMode) {
    state.atrainGear.aimX = clampv(mx, 8, W - 8);
    state.atrainGear.aimY = clampv(my, WATER_Y + 6, H - 8);
  }
});

document.getElementById("musicBtn").addEventListener("click", () => {
  ensureAudioOnGesture();
  toggleMusic();
});
document.getElementById("logoutBtn").addEventListener("click", logout);
closeShopBtn.addEventListener("click", toggleShop);
closeMapBtn.addEventListener("click", toggleMap);
auctionBtn.addEventListener("click", auctionAll);

document.getElementById("authLogin").addEventListener("click", tryLogin);
document.getElementById("authRegister").addEventListener("click", tryRegister);
document.getElementById("authGuest").addEventListener("click", playAsGuest);

// Touch / on-screen control buttons (toimii myös hiirellä)
(function setupTouchControls() {
  const TAP_ACTIONS = {
    cast:    () => { if (state.atCottage) cottageAction(); else if (state.subMode) { state.placing ? placeAtAim() : fireHarpoon(); } else if (state.atrainMode) fireAtrain(); else if (state.line.out) reelTap(); else cast(); },
    reel:    () => { if (state.atCottage) cottageAction(); else if (state.subMode) { state.placing ? placeAtAim() : fireHarpoon(); } else if (state.atrainMode) fireAtrain(); else reelTap(); },
    release: () => { if (!state.subMode) releaseFish(); },
    atrain:  () => toggleAtrainMode(),
    shop:    () => toggleShop(),
    map:     () => toggleMap(),
    vehicle: () => switchVehicle(),
    pause:   () => togglePause(),
  };
  document.querySelectorAll(".tbtn").forEach(btn => {
    const hold = btn.dataset.hold;
    const tap  = btn.dataset.tap;
    if (hold) {
      const start = (e) => { e.preventDefault(); state.keys[hold] = true; ensureAudioOnGesture(); };
      const end   = (e) => { if (e) e.preventDefault(); state.keys[hold] = false; };
      btn.addEventListener("touchstart", start, { passive: false });
      btn.addEventListener("touchend",   end,   { passive: false });
      btn.addEventListener("touchcancel", end,  { passive: false });
      btn.addEventListener("mousedown",  start);
      btn.addEventListener("mouseup",    end);
      btn.addEventListener("mouseleave", end);
    } else if (tap) {
      const fn = TAP_ACTIONS[tap];
      if (!fn) return;
      // Use touchstart for instant feedback on phones, click as fallback for desktop
      let usedTouch = false;
      btn.addEventListener("touchstart", (e) => {
        e.preventDefault();
        usedTouch = true;
        ensureAudioOnGesture();
        fn();
      }, { passive: false });
      btn.addEventListener("click", (e) => {
        if (usedTouch) { usedTouch = false; return; }
        ensureAudioOnGesture();
        fn();
      });
    }
  });
})();

// Prevent pinch-zoom on canvas during gameplay
canvas.addEventListener("touchmove", (e) => {
  e.preventDefault();
  if (!e.touches.length) return;
  const r = canvas.getBoundingClientRect();
  const tx = (e.touches[0].clientX - r.left) * (W / r.width);
  const ty = (e.touches[0].clientY - r.top) * (H / r.height);
  if (state.subMode) {
    state.sub.aimX = tx;
    state.sub.aimY = ty + state.cam;
  } else if (state.atrainMode) {
    state.atrainGear.aimX = clampv(tx, 8, W - 8);
    state.atrainGear.aimY = clampv(ty, WATER_Y + 6, H - 8);
  }
}, { passive: false });

// Auto-save every 10s as backup
setInterval(() => { if (state.running) autoSave(); }, 10000);

// =========================================================
// Init
// =========================================================
function loop(t) {
  const dt = state.lastT ? Math.min(0.05, (t - state.lastT) / 1000) : 0;
  state.lastT = t;
  update(dt);
  render();
  requestAnimationFrame(loop);
}

// Pre-spawn empty render
ctx.fillStyle = "#0a1828";
ctx.fillRect(0, 0, W, H);

if (!autoLoginFromStorage()) {
  // Show auth screen, but render game in background
  authDiv.classList.remove("hidden");
}
requestAnimationFrame(loop);
